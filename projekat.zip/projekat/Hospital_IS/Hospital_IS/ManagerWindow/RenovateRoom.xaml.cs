﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for RenovateRoom.xaml
    /// </summary>
    public partial class RenovateRoom : Window
    {
        private Room selectedRoom;
        private Renovation renovation;
        private static Timer timer;
        private RoomController roomController = new RoomController();
        private RenovationController renovateController = new RenovationController();
        private AppointmentController appointmentController = new AppointmentController();

        public RenovateRoom(Room room)
        {
            selectedRoom = RoomFileStorage.Instance.FindById(room.roomName);
         //   timer = new Timer(new TimerCallback(roomController.RenovationTime), null, 1000, 60000);

            InitializeComponent();
            this.DataContext = this;

            txtRoomName.Content = selectedRoom.roomName;
            txtFloor.Content = FloorToString(selectedRoom.floorNumber);
            txtType.Content = RoomTypeToString(selectedRoom.roomType);
            txtAvailability.Content = AvailabilityToString(selectedRoom.isAvailable);
        }

       

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnRenovate_Click(object sender, RoutedEventArgs e)
        {
            DateTime? startDate = dateStartRenovation.SelectedDate;
            DateTime? endDate = dateEndRenovation.SelectedDate;

            if (appointmentController.IsRoomFreeForRenovation(selectedRoom, startDate, endDate))
            {
                if (((DateTime.Compare((DateTime)startDate, DateTime.Today) < 0) && (DateTime.Compare(DateTime.Today, (DateTime)endDate) < 0) || (DateTime.Compare((DateTime)startDate, DateTime.Today) < 0)) && (DateTime.Compare(DateTime.Today, (DateTime)endDate) == 0))
                {
                    selectedRoom.isAvailable = false;
                    roomController.UpdateRoom(selectedRoom);

                    renovation = new Renovation(selectedRoom, startDate, endDate);
                    renovateController.AddRenovation(renovation);
                }
            }
            else
                MessageBox.Show("U tom vremenskom intervalu soba je zauzeta!");

            this.Close();
        }


        public static string FloorToString(int number)
        {
            return number switch
            {
                1 => "Prvi",
                2 => "Drugi",
                3 => "Treci",
                _ => "",
            };
        }

        public string RoomTypeToString(RoomType type)
        {

            return type switch
            {
                RoomType.examinationRoom => "Prijemna ambulanta",
                RoomType.operationRoom => "Operaciona sala",
                RoomType.accommodationRoom => "Stacionar",
                _ => "",
            };

        }

        public string AvailabilityToString(bool dostupna)
        {
            if (dostupna == true)
            {
                return "Dostupna";
            }
            return "Nedostupna";
        }
    }
}
