﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class MedicationDTO
    {
        private MedicationController medicationController = new MedicationController();
        public string id { get; set; }
        public string name { get; set; }
        public string alternative { get; set; }
        public string status { get; set; }

        public MedicationDTO(Medication medication)
        {
            this.id = medication.id;
            this.name = medication.name;
            Medication alternativeMedication = medicationController.GetMedicationById(medication.alternative.id);
            this.alternative = alternativeMedication.name;
            this.status = medication.status switch
            {
                MedicationStatus.approved => "Odobren",
                MedicationStatus.waitingForApproval => "Na cekanju",
                MedicationStatus.denied => "Odbijen",
                _ => "",
            };
        }

    }
}
