using System;

namespace Hospital_IS.Model
{
   public enum Gender
   {
      male,
      female
   }
}