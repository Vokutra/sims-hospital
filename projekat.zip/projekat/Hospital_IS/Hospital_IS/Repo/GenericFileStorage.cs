using Hospital_IS.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Hospital_IS.Repo
{
    public abstract class GenericFileStorage<KeyType, Entity, RepositoryType>
        where RepositoryType : GenericFileStorage<KeyType, Entity, RepositoryType>, new()
    {

        private static RepositoryType _instance = new RepositoryType();
        public static RepositoryType Instance
        {
            get
            {
                return _instance;
            }
        }

        protected abstract string GetPath();

        protected abstract KeyType GetKey(Entity entity);

        protected abstract void RemoveReferences(KeyType key);

        public void Update(Entity entity)
        {
            Dictionary<KeyType, Entity> entities = ReadFile();

            ShouldSerialize(entity);
            KeyType key = GetKey(entity);

            if (!entities.ContainsKey(key))
            {
                return;
            }

            entities[key] = entity;

            WriteFile(entities);

        }

        public void DeleteById(KeyType key)
        {
            Dictionary<KeyType, Entity> entities = ReadFile();

            bool retVal = entities.Remove(key);

            //RemoveReferences(key);

            WriteFile(entities);
        }

        public void DeleteByReference(Entity entity)
        {
            DeleteById(GetKey(entity));
        }

        public Entity FindById(KeyType key)
        {
            Dictionary<KeyType, Entity> entities = ReadFile();
            Entity retVal;

            if (!entities.TryGetValue(key, out retVal))
            {
                return default;
            }

            return retVal;
        }

        public List<Entity> GetEntityList()
        {
            return this.ReadFile().Values.ToList();
        }


        protected abstract void ShouldSerialize(Entity entity);

        protected void WriteFile(Dictionary<KeyType, Entity> entities)
        {
            string path = GetPath();
            string json = JsonConvert.SerializeObject(entities, Formatting.Indented);

            File.WriteAllText(path, json);
        }

        protected Dictionary<KeyType, Entity> ReadFile()
        {
            string path = GetPath();

            if (!File.Exists(path))
            {
                File.Create(path).Close();
                return new Dictionary<KeyType, Entity>();
            }
            FileInfo fi = new FileInfo(path);
            if (fi.Length == 0)
            {
                return new Dictionary<KeyType, Entity>();
            }

            string json = File.ReadAllText(path);

            return JsonConvert.DeserializeObject<Dictionary<KeyType, Entity>>(json);
        }

        public void CreateOrUpdate(Entity Entity)
        {
            Dictionary<KeyType, Entity> entities = ReadFile();
            ShouldSerialize(Entity);
            KeyType key = GetKey(Entity);

            entities[key] = Entity;

            WriteFile(entities);
        }

        //public void CreateOrUpdate(Entity Entity)
        //{
        //    Dictionary<KeyType, Entity> entities = ReadFile();
        //    ShouldSerialize(Entity);
        //    KeyType key = GetKey(Entity);

        //    if (entities.ContainsKey(key))
        //    {
        //        return;
        //    }

        //    entities[key] = Entity;

        //    WriteFile(entities);

        //    return;
        //}

    }
}