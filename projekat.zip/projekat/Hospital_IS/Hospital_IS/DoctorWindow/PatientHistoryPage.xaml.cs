﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for PatientHistoryPage.xaml
    /// </summary>
    public partial class PatientHistoryPage : Page
    {

        public static Doctor loggedDoctor;
        private DoctorController doctorController = new DoctorController();
        private PatientController patientController = new PatientController();
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();
        public BindingList<AppointmentDoctorDTO> appointmentsDTO { get; set; }
        public BindingList<TherapyDTO> therapiesDTO { get; set; }

        public List<Therapy> therapies { get; set; }
        public List<LoggedAppointment> loggedAppointments;
        public Frame mainFrame { get; set; }

        public Patient patient { get; set; }

        public PatientHistoryPage(Patient patient)
        {
            InitializeComponent();

            this.patient = patient;
            appointmentsDTO = new BindingList<AppointmentDoctorDTO>();
            therapiesDTO = new BindingList<TherapyDTO>();
            patientNameTextBlock.Text = patient.name + " " + patient.surname;

            DataContext = this;

            loadAppointments();
            loadTherapies();
        }

        private void loadAppointments()
        {
            loggedAppointments = loggedAppointmentController.GetLoggedAppointmentsByPatient(patient);
            appointmentsDTO.Clear();

            foreach(LoggedAppointment la in loggedAppointments)
            {
                Doctor doctor = doctorController.FindDoctorById(la.doctor.userID);
                if (la.appointmentType == AppointmentType.Examination)
                    appointmentsDTO.Add(new AppointmentDoctorDTO(doctor, la.startTime.ToShortDateString(), la.startTime.ToString("HH:mm"), la.durationInMinutes.ToString() + " min", "Pregled", la.diagnosis, la.id));
                else
                    appointmentsDTO.Add(new AppointmentDoctorDTO(doctor, la.startTime.ToShortDateString(), la.startTime.ToString("HH:mm"), la.durationInMinutes.ToString() + " min", "Operacija", la.diagnosis, la.id));
            }
        }

        private void loadTherapies()
        {
            therapies = patient.therapies;
            therapiesDTO.Clear();

            foreach(Therapy t in therapies)
            {
                therapiesDTO.Add(new TherapyDTO(t));
            }
        }

        private void loggedAppointmentInfoButton_Click(object sender, RoutedEventArgs e)
        {
            AppointmentDoctorDTO a = (AppointmentDoctorDTO)dgAppointments.SelectedItem;

            string appointmentID = a.id;

            MainWindowDoctor.GetInstance().MainFrame.Content = new LoggedAppointmentInfoPage(appointmentID, "PatientHistoryPage");
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }
    }
}
