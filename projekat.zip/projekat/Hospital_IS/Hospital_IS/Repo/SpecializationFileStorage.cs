﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class SpecializationFileStorage : GenericFileStorage<string, Specialization, SpecializationFileStorage>
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        protected override string GetKey(Specialization entity)
        {
            return entity.Id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\specializations.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Specialization entity)
        {
            entity.Serialize = true;
        }
    }
}
