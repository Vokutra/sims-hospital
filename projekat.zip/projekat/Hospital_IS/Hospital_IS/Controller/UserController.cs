using System;

namespace Hospital_IS.Controller
{
   public class UserController
   {
      public Model.UserAccount LogIn(String username, String password)
      {
         throw new NotImplementedException();
      }
      
      public Boolean IsUsernameUnique(String username)
      {
         throw new NotImplementedException();
      }
      
      public void ChangePassword(String username, String password)
      {
         throw new NotImplementedException();
      }
      
      public Model.UserAccount BlockUser(String username)
      {
         throw new NotImplementedException();
      }
      
      public Service.UserService userService;
   
   }
}