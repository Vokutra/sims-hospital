using System;

namespace Hospital_IS.Model
{
   public enum RoomType
   {
      operationRoom,
      examinationRoom,
      accommodationRoom
   }
}