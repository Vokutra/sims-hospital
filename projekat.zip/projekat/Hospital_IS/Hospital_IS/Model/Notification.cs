﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Notification
    {
        [DataMember]
        public string senderId { get; set; }
        [DataMember]
        public string receiverId { get; set; }
        [DataMember]
        public string title { get; set; }
        [DataMember]
        public string message { get; set; }
        [DataMember]
        public DateTime sentTime { get; set; }
        [DataMember]
        public bool isRead { get; set; }
        [DataMember]
        public string id { get; set; }

        public Notification(string senderId, string receiverId, string title, string message, DateTime sentTime, bool isRead)
        {
            this.senderId = senderId;
            this.receiverId = receiverId;
            this.title = title;
            this.message = message;
            this.sentTime = sentTime;
            this.isRead = isRead;
            this.id = this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }
    }
}
