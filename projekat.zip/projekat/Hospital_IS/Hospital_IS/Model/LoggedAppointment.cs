﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class LoggedAppointment
    {
        [DataMember]
        public DateTime startTime { get; set; }
        [DataMember]
        public int durationInMinutes { get; set; }
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public Patient patient { get; set; }
        [DataMember]
        public Doctor doctor { get; set; }
        [DataMember]
        public AppointmentType appointmentType { get; set; }
        [DataMember]
        public Room room { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public string diagnosis { get; set; }
        [DataMember]
        public bool serialize { get; set; }

        public LoggedAppointment(DateTime startTime, int durationInMinutes, string id, Patient patient, Doctor doctor, AppointmentType appointmentType, Room room, string description, string diagnosis)
        {
            this.startTime = startTime;
            this.durationInMinutes = durationInMinutes;
            this.id = id;
            this.patient = patient;
            this.doctor = doctor;
            this.appointmentType = appointmentType;
            this.room = room;
            this.description = description;
            this.diagnosis = diagnosis;
        }

        public LoggedAppointment(Appointment a, string description, string diagnosis)
        {
            this.startTime = a.startTime;
            this.durationInMinutes = a.durationInMinutes;
            this.id = a.id;
            this.patient = a.patient;
            this.doctor = a.doctor;
            this.appointmentType = a.appointmentType;
            this.room = a.room;
            this.description = description;
            this.diagnosis = diagnosis;
        }

        public LoggedAppointment()
        {

        }

        public bool ShouldSerializestartTime()
        {
            return serialize;
        }

        public bool ShouldSerializedurationInMinutes()
        {
            return serialize;
        }

        public bool ShouldSerializepatient()
        {
            return serialize;
        }

        public bool ShouldSerializedoctor()
        {
            return serialize;
        }

        public bool ShouldSerializeappointmentType()
        {
            return serialize;
        }

        public bool ShouldSerializeroom()
        {
            return serialize;
        }

        public bool ShouldSerializedescription()
        {
            return serialize;
        }

        public bool ShouldSerializediagnosis()
        {
            return serialize;
        }
    }
}
