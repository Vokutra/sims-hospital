﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class DoctorsShift
    {
        [DataMember]
        public DateTime startDate { get; set; }
        [DataMember]
        public DateTime endDate { get; set; }
        [DataMember]
        public Shift shift { get; set; }
        [DataMember]
        public Doctor doctor { get; set; }
        [DataMember]
        public String id { get; set; }
        public bool serialize { get; set; }

        public DoctorsShift(DateTime startDate, DateTime endDate, Shift shift, Doctor doctor)
        {
            this.startDate = startDate;
            this.endDate = endDate;
            this.shift = shift;
            this.doctor = doctor;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }


    }
}
