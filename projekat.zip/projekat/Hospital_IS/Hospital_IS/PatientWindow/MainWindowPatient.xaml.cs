﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for MainWindowPatient.xaml
    /// </summary>
    public partial class MainWindowPatient : Window
    {
        private NotificationController notificationController = new NotificationController();
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();
        private HospitalSurveyController hospitalSurveyController = new HospitalSurveyController();
        private DoctorController doctorController = new DoctorController();
        private static MainWindowPatient instance = null;
        public static MainWindowPatient getInstance()
        {
            if (instance == null)
            {
                instance = new MainWindowPatient();
            }
            return instance;
        }

        public MainWindowPatient()
        {
            InitializeComponent();
            SetContent(new StartPage());
        }

        public void SetContent(Page page)
        {
            PatientWindowContent.Content = page;
        }

        private void btnStartPage_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new StartPage());
        }

        private void btnMakeAppointment_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new MakeAppointment());
        }

        private void btnScheduledAppointments_Click(object sender, RoutedEventArgs e)
        {
            SetContent(ScheduledAppointments.getInstance());
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            new LoginPatient().Show();
            ScheduledAppointments.SetInstanceToNull();
            instance = null;
            this.Close();
        }

        private void btnNotifications_Click(object sender, RoutedEventArgs e)
        {
            Notifications notificationsPage = new Notifications();
            foreach (Notification notification in notificationController.GetNotificationsForUser(LoginPatient.patient.userID))
            {
                Notifications.notificationsDTO.Insert(0, new NotificationDTO(notification.title, notification.sentTime.ToString("MM / dd / yyyy h: mm tt"), notification.id));
            }
            SetContent(notificationsPage);
        }

        public void SetNotificationButton(object state)
        {
            if (notificationController.AreAllNotificationsRead())
            {
                App.Current.Dispatcher.Invoke((Action)delegate
                {
                    btnNotifications.Content = FindResource("whiteBell");
                });
            }
            else
            {
                App.Current.Dispatcher.Invoke((Action)delegate
                {
                    btnNotifications.Content = FindResource("goldBell");
                });
            }
        }

        public void SetBtnRateHospitalStatus(object state)
        {
            if (hospitalSurveyController.IsHospitalSurveyActive(LoginPatient.patient))
            {
                App.Current.Dispatcher.Invoke((Action)delegate
                {
                    btnRateHospital.IsEnabled = true;
                });
            }
            else
            {
                App.Current.Dispatcher.Invoke((Action)delegate
                {
                    btnRateHospital.IsEnabled = false;
                });
            }
        }

        private void btnRateHospital_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new HospitalSurveyPage());
        }

        private void btnHistoryOfExams_Click(object sender, RoutedEventArgs e)
        {
            HistoryOfExams historyOfExams = new HistoryOfExams();
            List<LoggedAppointment> performedExams = loggedAppointmentController.GetLoggedAppointmentsByPatient(LoginPatient.patient);
            foreach (LoggedAppointment loggedAppointment in performedExams.AsEnumerable().Reverse())
            {
                HistoryOfExams.pastExams.Add(new AppointmentDTO(loggedAppointment.startTime.ToShortDateString(), loggedAppointment.startTime.ToString("HH:mm"), doctorController.FindDoctorById(loggedAppointment.doctor.userID).ToString(), loggedAppointment.id));
            }

            SetContent(historyOfExams);
        }
    }
}
