﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface IRoomService
    {
        public Room GetRoomByName(string roomName);
     
        public List<Room> GetAllRooms();
        
        public List<string> GetAllRoomNames();
      
        public List<Room> GetRoomsByType(RoomType roomType);
    
        public List<Room> GetAvailableRooms(RoomType type);
      
        public void AddRoom(Room room);
        
        public void UpdateRoom(Room room);
      
        public void DeleteRoom(Room room);

        public void TakeRoom(Room room);

        public void FreeRoom(Room room);
      
    }
}
