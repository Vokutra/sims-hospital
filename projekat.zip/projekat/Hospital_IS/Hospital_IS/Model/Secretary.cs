using Newtonsoft.Json;
using System;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Secretary : UserAccount
    {
        [JsonConstructor]
        public Secretary(string username, string password, DateTime doB, string phoneNum, string email, string userID, Address address, string name, string surname)
        {
            this.username = username;
            this.password = password;
            this.doB = doB;
            this.phoneNum = phoneNum;
            this.email = email;
            this.userID = userID;
            this.address = address;
            this.name = name;
            this.surname = surname;
        }
    }
}