﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for SeparatingRoom.xaml
    /// </summary>
    public partial class SeparateRoom : Window
    {
        private Room selectedRoom;
        private Room secondRoom;
        private RoomController roomController = new RoomController();
        private SeparatingRoom separatingRoom;
        private AppointmentController appointmentController = new AppointmentController();
        private SeparatingRoomController separatingRoomController = new SeparatingRoomController();
        public SeparateRoom(Room room)
        {
            selectedRoom = roomController.getRoomById(room.roomName);
            InitializeComponent();
            this.DataContext = this;
            txtRoomName.Content = selectedRoom.roomName;
            txtFloor.Content = FloorToString(selectedRoom.floorNumber);
            cbType.Text = RoomTypeToString(selectedRoom.roomType);
            txtAvailability.Content = AvailabilityToString(selectedRoom.isAvailable);
            cbNewRoomType.Text = RoomTypeToString(selectedRoom.roomType);
        }

        private void btnSeparate_Click(object sender, RoutedEventArgs e)
        {
            string secondRoomName = txtSecondRoomName.Text;
            DateTime? startDate = dateStartRenovation.SelectedDate;
            DateTime? endDate = dateEndRenovation.SelectedDate;
            RoomType firstRoomType = StringToRoomType(cbType.Text);
            selectedRoom.roomType = firstRoomType;

            RoomType secondRoomType = StringToRoomType(cbNewRoomType.Text);
            secondRoom = new Room(secondRoomType, selectedRoom.floorNumber, true, txtSecondRoomName.Text);

            if (appointmentController.IsRoomFreeForRenovation(selectedRoom, startDate, endDate))
            {
                if ((DateTime.Compare(DateTime.Today, (DateTime)endDate) == 0) || (DateTime.Compare(DateTime.Today, (DateTime)endDate) > 0))
                {
                    separatingRoom = new SeparatingRoom(selectedRoom, secondRoom, startDate, endDate);
                    separatingRoomController.AddSeparatingRoom(separatingRoom);
                    separatingRoomController.SepatareRoom(separatingRoom);

                    RoomsViewModel.rooms.Add(secondRoom);
                }
            }
            else
                MessageBox.Show("U tom vremenskom intervalu soba je zauzeta!");

            this.Close();

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public static string FloorToString(int number)
        {
            return number switch
            {
                1 => "Prvi",
                2 => "Drugi",
                3 => "Treci",
                _ => "",
            };
        }

        public string RoomTypeToString(RoomType type)
        {

            return type switch
            {
                RoomType.examinationRoom => "Prijemna ambulanta",
                RoomType.operationRoom => "Operaciona sala",
                RoomType.accommodationRoom => "Stacionar",
                _ => "",
            };

        }

        public string AvailabilityToString(bool dostupna)
        {
            if (dostupna == true)
            {
                return "Dostupna";
            }
            return "Nedostupna";
        }

        public static RoomType StringToRoomType(string str)
        {

            return str switch
            {
                "Prijemna ambulanta" => RoomType.examinationRoom,
                "Operaciona sala" => RoomType.operationRoom,
                "Stacionar" => RoomType.accommodationRoom,
                _ => RoomType.accommodationRoom,
            };
        }
    }
}
