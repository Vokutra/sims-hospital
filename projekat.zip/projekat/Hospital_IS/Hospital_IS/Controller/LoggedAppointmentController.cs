﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class LoggedAppointmentController
    {
        LoggedAppointmentService loggedAppointmentService = new LoggedAppointmentService();

        public List<LoggedAppointment> GetAllLoggedAppointments()
        {
            return loggedAppointmentService.GetAllLoggedAppointments();
        }

        public List<LoggedAppointment> GetLoggedAppointmentsByPatient(Patient patient)
        {
            return loggedAppointmentService.GetLoggedAppointmentsByPatient(patient);
        }

        public List<LoggedAppointment> GetLoggedAppointmentsByDoctor(Doctor doctor)
        {
            return loggedAppointmentService.GetLoggedAppointmentsByDoctor(doctor);
        }

        public void CreateOrUpdate(LoggedAppointment la)
        {
            loggedAppointmentService.CreateOrUpdate(la);
        }

        public LoggedAppointment GetById(string id)
        {
            return loggedAppointmentService.GetById(id);
        }

    }
}
