﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    
    public partial class RoomInventoryPage : Page
    {
        private RoomInventoryController roomInventoryController = new RoomInventoryController();
        private InventoryContoller inventoryContoller = new InventoryContoller();
       // public static ObservableCollection<RoomInventoryDTO> inventories { get; set; }
        private EditRoom edit;
        private Room selectedRoom;
        private static Timer timer;
        public static BindingList<RoomInventoryDTO> currentInventories { get; set; }

        public RoomInventoryPage(Room room)
        {
            // edit= new EditRoom(room);
            selectedRoom = room;
            timer = new Timer(new TimerCallback(roomInventoryController.RelocateOnDate), null, 1000, 60000);
            currentInventories = new BindingList<RoomInventoryDTO>();
            foreach (RoomInventory r in roomInventoryController.GetInventoriesByRoom(room)) 
            {
                if (DateTime.Compare((DateTime)r.date, DateTime.Today) == -1 || DateTime.Compare(DateTime.Today, (DateTime)r.date) == 0)
                {
                    Inventory inventory = inventoryContoller.GetInventoryById(r.inventory.inventoryID);
                    currentInventories.Add(new RoomInventoryDTO(r.room.roomName, inventory.name, inventory.inventoryID, r.amount,r.inventory.inventoryType , r.date, r.id));
                }
            }
            //inventories = new ObservableCollection<RoomInventoryDTO>(roomInventoryController.GetInventoriesByRoom(room));
           // inventories = new ObservableCollection<RoomInventoryDTO>(currentInventories);
            InitializeComponent();
            DataContext = this;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            edit = new EditRoom(selectedRoom);
            edit.Visibility = Visibility.Visible;
            this.Visibility = Visibility.Hidden;

        }

        private void btnRelocate_Click(object sender, RoutedEventArgs e)
        {
            RoomInventoryDTO SelectedInventory = roomInventoryTable.SelectedItem as RoomInventoryDTO;

            if (SelectedInventory == null)
            {
                MessageBox.Show("Izabrati inventar.");
                return;
            }


            RelocateRoomInventory relocateRoomInventory = new RelocateRoomInventory(SelectedInventory);
            relocateRoomInventory.Show();

        }
    }
}
