﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    class VacationRequestService
    {
        private VacationRequestFileStorage vacationRequestFileStorage = new VacationRequestFileStorage();

        private DoctorFileStorage doctorFileStorage = new DoctorFileStorage();

        public List<VacationRequest> getAllVacationRequests()
        {
            return vacationRequestFileStorage.GetEntityList();
        }

        public VacationRequest GetVacationRequestById(string id)
        {
            return vacationRequestFileStorage.FindById(id);
        }

        public void CreateOrUpdate(VacationRequest vacationRequest)
        {
            vacationRequestFileStorage.CreateOrUpdate(vacationRequest);
        }

        public bool SameSpecialistsAreOnVacationDuringPeriod(Doctor doctor, DateTime startDate, DateTime endDate)
        {
            List<VacationRequest> vacationRequestsInPeriod = GetAllVacationRequestsInPeriod(startDate, endDate);

            return SameSpecialistIsInList(doctor, vacationRequestsInPeriod);
        }

        public List<VacationRequest> GetAllVacationRequestsInPeriod(DateTime startDate, DateTime endDate)
        {
            List<VacationRequest> allVacationRequests = vacationRequestFileStorage.GetEntityList();
            List<VacationRequest> vacationRequestsInPeriod = new List<VacationRequest>();

            foreach(VacationRequest vacationRequest in allVacationRequests)
            {
                if( vacationRequest.StartDate <= startDate && vacationRequest.EndDate >= startDate && vacationRequest.Status != VacationRequestStatus.denied)
                    vacationRequestsInPeriod.Add(vacationRequest);
            
                else if( vacationRequest.StartDate <= endDate && vacationRequest.EndDate >= endDate && vacationRequest.Status != VacationRequestStatus.denied)
                    vacationRequestsInPeriod.Add(vacationRequest);

                else if (vacationRequest.StartDate >= startDate && vacationRequest.EndDate <= endDate && vacationRequest.Status != VacationRequestStatus.denied)
                    vacationRequestsInPeriod.Add(vacationRequest);
            }

            return vacationRequestsInPeriod;
        }

        public bool SameSpecialistIsInList(Doctor doctor, List<VacationRequest> vacationRequests)
        {
            bool flag = false;
            foreach(VacationRequest vacationRequest in vacationRequests)
            {
                Doctor doctorFromRequest = doctorFileStorage.FindById(vacationRequest.Doctor.userID);
                if(doctorFromRequest.specialization.Id == doctor.specialization.Id)
                {
                    flag = true;
                    break;
                }
            }

            return flag;
        }
    }
}
