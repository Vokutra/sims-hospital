﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.SecretaryWindow
{
    /// <summary>
    /// Interaction logic for DoctorAppointments.xaml
    /// </summary>
    public partial class DoctorAppointments : Window
    {
        //private DoctorController doctorController = new DoctorController();
        //private PatientController patientController = new PatientController();
        //private AppointmentController appointmentController = new AppointmentController();
        //private RoomController roomController = new RoomController();
        //public BindingList<AppointmentDoctorDTO> appointmentsDTO { get; set; }

        //public List<Appointment> appointments;
        public DoctorAppointments(Doctor doctor)
        {
            InitializeComponent();

            //appointmentsDTO = new BindingList<AppointmentDoctorDTO>();

            //DataContext = this;
        }
        //private void RemoveAppointmentFromPatient(string appointmentID, Appointment a)
        //{
        //    string patientID = a.patient.userID;
        //    Patient patient = patientController.GetPatientById(patientID);

        //    int index = 0;
        //    foreach (string id in patient.appointmentIDs)
        //    {
        //        if (id.Equals(appointmentID))
        //        {
        //            patient.appointmentIDs.RemoveAt(index);
        //            patientController.CreateOrUpdate(patient);
        //            return;
        //        }
        //        index++;
        //    }
        //}
        //private void btnCancelAppointment_Click(object sender, RoutedEventArgs e)
        //{
        //    if (DoctorsAppointmentsTable.SelectedItem != null)
        //    {
        //        if (MessageBox.Show("Jeste li sigurni da zelite da otkazete odabrani termin?",
        //        "Otkazivanje termina", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
        //        {
        //            AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

        //            Appointment appointment = appointmentController.GetAppointment(a.id);

        //            RemoveAppointmentFromPatient(a.id, appointment);

        //            appointmentController.DeleteAppointment(a.id);

                 

        //            MessageBox.Show("Termin je uspjesno otkazan.");


        //        }
        //    }
        //}

        //private void btnMoveAppointment_Click(object sender, RoutedEventArgs e)
        //{
        //    if (DoctorsAppointmentsTable.SelectedItem != null)
        //    {
        //        AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

        //        string appointmentID = a.id;

        //        EditAppointment ea = new EditAppointment();
        //        ea.Show();
        //        this.Close();
        //    }
        //}

        //private void btnMakeAppointment_Click(object sender, RoutedEventArgs e)
        //{
        //    AddAppointment ap = new AddAppointment();
        //    ap.Show();
        //    this.Close();
        //}

        //private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{

        //}


    }
}
