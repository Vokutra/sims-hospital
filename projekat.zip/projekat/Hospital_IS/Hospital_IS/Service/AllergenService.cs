﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
   public class AllergenService
    {
        private AllergenFileStorage allergenFileStorage = new AllergenFileStorage();
        public List<Allergen> GetAllAllergens()
        {
            return allergenFileStorage.GetEntityList();
        }

        public Model.Allergen GetAllergen(String allergenName)
        {
            return allergenFileStorage.ReadUser(allergenName);
        }

        public Allergen GetAllergenById(string id)
        {
            return allergenFileStorage.FindById(id);
        }

        public void UpdateAllergen(String allergenName)
        {
            throw new NotImplementedException();
        }

        public void UpdateAllergen(Allergen allergen)
        {
            allergenFileStorage.CreateOrUpdate(allergen);
        }

        public void AddAllergen(Model.Allergen allergen)
        {
            allergenFileStorage.CreateOrUpdate(allergen);
        }

        public void DeleteAllergen(Model.Allergen allergen)
        {
            allergenFileStorage.DeleteByReference(allergen);
        }

       
    }
}

