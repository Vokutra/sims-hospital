using System;

namespace Hospital_IS.Model
{
   public enum BloodType
   {
      aPositive,
      aNegative,
      bPositive,
      bNegative,
      oNegative,
      oPositive,
      aBNegative,
      aBPositive
   }
}