﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class MergingRoomsFileStorage : GenericFileStorage<string, MergingRooms, MergingRoomsFileStorage>, IMergingRoomsFileStorage
    {
        protected override string GetKey(MergingRooms entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\mergingRooms.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(MergingRooms entity)
        {
            entity.roomOne.serialize = false;
            entity.roomTwo.serialize = false;
            entity.serialize = true;
        }
    }
}
