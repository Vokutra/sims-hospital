﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.PatientWindow.Toasts;
using System;
using System.ComponentModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for ScheduledAppointments.xaml
    /// </summary>
    public partial class ScheduledAppointments : Page
    {
        private AppointmentController appointmentController = new AppointmentController();
        private PatientController patientController = new PatientController();
        public static BindingList<AppointmentDTO> scheduledAppointmentsDTO { get; set; }

        private static ScheduledAppointments instance = null;
        private Thread thread;
        public static ScheduledAppointments getInstance()
        {
            if (instance == null)
            {
                instance = new ScheduledAppointments();
            }
            return instance;
        }
        public ScheduledAppointments()
        {
            InitializeComponent();
            scheduledAppointmentsDTO = new BindingList<AppointmentDTO>();
            DataContext = this;
        }

        public static void SetInstanceToNull()
        {
            instance = null;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            AppointmentDTO selectedAppointmentDTO = (AppointmentDTO)dgAppointments.SelectedItem;
            Appointment appointment = appointmentController.GetAppointment(selectedAppointmentDTO.id);
            foreach (AppointmentDTO appointmentDTO in scheduledAppointmentsDTO)
            {
                if (appointmentDTO.id.Equals(selectedAppointmentDTO.id))
                {
                    scheduledAppointmentsDTO.Remove(appointmentDTO);
                    LoginPatient.patient.appointmentIDs.Remove(appointmentDTO.id);
                    LoginPatient.patient.datesOfCanceledAppointments.Add(appointment.startTime);
                    LoginPatient.patient.appointmentCancellationTimes.Add(DateTime.Now);
                    patientController.UpdatePatient(LoginPatient.patient);
                    appointmentController.DeleteAppointment(appointment);
                    if (patientController.ShouldBeBanned(LoginPatient.patient))
                    {
                        MainWindowPatient.getInstance().Close();
                    }
                    break;
                }
            }

            thread = new Thread(new ConfirmationToast().ShowConfirmationToast);
            thread.Start("Uspešno ste otkazali pregled");
        }
    }
}
