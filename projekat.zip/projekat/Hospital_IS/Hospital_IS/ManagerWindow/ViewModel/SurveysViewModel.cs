﻿using Hospital_IS.Commands;
using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.View;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Controls;

namespace Hospital_IS.ManagerWindow.ViewModel
{
   
    class SurveysViewModel
    {
        public static BindingList<Medication> medications { get; set; }

        private MedicationController medicationController = new MedicationController();
        public RelayCommand HospitalCommand { get; set; }
        public RelayCommand DoctorsCommand { get; set; }
        public RelayCommand MedicationsCommand { get; set; }

        public SurveysViewModel()
        {
            medications = new BindingList<Medication>(medicationController.GetAllMedications());
           
            HospitalCommand = new RelayCommand(param => ExecuteHospital());
            DoctorsCommand = new RelayCommand(param => ExecuteDoctors());
            MedicationsCommand = new RelayCommand(ExecuteMedications);
        }

        private void ExecuteMedications(object obj)
        {
            //new PrintDialog().PrintVisual(new SurveysView().Report, "SurveysView");
            new PrintDialog().PrintVisual(new PDF().print, "PDF");
        }

        private void ExecuteDoctors()
        {
            DoctorsSurvey doctorsSurvey = new DoctorsSurvey();
            doctorsSurvey.Show();
        }

        private void ExecuteHospital()
        {
            HospitalSurvey hospitalSurvey = new HospitalSurvey();
            hospitalSurvey.Show();
        }
    }
}
