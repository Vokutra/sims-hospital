﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface IInventoryService
    {
        public void AddInventory(Inventory inventory);

        public void DeleteInventory(Inventory inventory);

        public List<Inventory> GetEntityList();

        public void UpdateInventory(Inventory inventory);

        public Inventory GetInventoryById(String id);

        public List<Inventory> GetInventoriesByType(InventoryType type);
  
    }
}
