using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Service
{
    public class PatientService
    {
        private PatientFileStorage patientFileStorage = new PatientFileStorage();
        public List<Patient> GetAllPatients()
        {
            return patientFileStorage.GetEntityList();
        }

        public Patient GetPatient(String username)
        {
            return patientFileStorage.ReadUser(username);
        }

        public Patient GetPatientById(string id)
        {
            return patientFileStorage.FindById(id);
        }

        public void UpdatePatient(String username)
        {
            throw new NotImplementedException();
        }

        public void UpdatePatient(Patient patient)
        {
            patientFileStorage.CreateOrUpdate(patient);
        }

        public void AddPatient(Model.Patient patient)
        {
            patientFileStorage.CreateOrUpdate(patient);
        }

        public void DeletePatient(Model.Patient patient)
        {
            patientFileStorage.DeleteByReference(patient);
        }

        public List<Patient> GetAllBannedPatients()
        {
            throw new NotImplementedException();
        }

        public bool ShouldBeBanned(Patient patient)
        {
            if (patient.appointmentCancellationTimes.Count >= 5)
            {
                TimeSpan timeDifference = patient.appointmentCancellationTimes[patient.appointmentCancellationTimes.Count - 1].Subtract(patient.appointmentCancellationTimes[patient.appointmentCancellationTimes.Count - 5]);
                if (timeDifference.Days <= 30)
                {
                    patient.isBanned = true;
                    UpdatePatient(patient);
                }
            }

            return patient.isBanned;
        }

        public List<Patient> SearchPatientsByNameOrSurname(string searchInput)
        {
            List < Patient > allPatients = patientFileStorage.GetEntityList();
            List<Patient> filteredPatients = new List<Patient>();
            
            foreach(Patient patient in allPatients)
            {
                if (patient.name.ToLower().Contains(searchInput.ToLower()) || patient.surname.ToLower().Contains(searchInput.ToLower()))
                    filteredPatients.Add(patient);
            }

            return filteredPatients;
        }
    }
}