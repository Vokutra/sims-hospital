﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    public class DoctorSurveyService
    {
        private DoctorSurveyFileStorage doctorSurveyFileStorage = new DoctorSurveyFileStorage();
        public void SaveSurvey(DoctorSurvey doctorSurvey)
        {
            doctorSurveyFileStorage.CreateOrUpdate(doctorSurvey);
        }

        public DoctorSurvey GetDoctorSurveyById(string id)
        {
            return doctorSurveyFileStorage.FindById(id);
        }

        public List<DoctorSurvey> GetAllDoctorSurveysByDoctor(Doctor doctor)
        {
            List<DoctorSurvey> doctorSurveys = new List<DoctorSurvey>();
            foreach (DoctorSurvey doctorSurvey in doctorSurveyFileStorage.GetEntityList())
            {
                if (doctorSurvey.doctor.userID.Equals(doctor.userID))
                {
                    doctorSurveys.Add(doctorSurvey);
                }
            }

            return doctorSurveys;
        }

        public List<DoctorSurvey> GetAllDoctorSurveysByGrade(int grade)
        {
            List<DoctorSurvey> doctorSurveys = new List<DoctorSurvey>();
            foreach (DoctorSurvey doctorSurvey in doctorSurveyFileStorage.GetEntityList())
            {
                foreach (int value in doctorSurvey.answers.Values)
                {
                    if (grade == value)
                    {
                        doctorSurveys.Add(doctorSurvey);
                    }
                }
            }

            return doctorSurveys;
        }

        public List<DoctorSurvey> GetGradeFromSurveyByGrade(int grade, DoctorSurvey doctorSurvey)
        {
            List<DoctorSurvey> doctorSurveys = new List<DoctorSurvey>();
            foreach (int value in doctorSurvey.answers.Values)
            {
                if (grade == value)
                {
                    doctorSurveys.Add(doctorSurvey);
                }
            }
            
            return doctorSurveys;
        }
    }
}
