﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Controls;
using Hospital_IS.Controller;
using System.Collections.ObjectModel;
using Hospital_IS.Model;
using Hospital_IS.Repo;

namespace Hospital_IS.SecretaryWindow
{
    /// <summary>
    /// Interaction logic for MainWindowSecretary.xaml
    /// </summary>
    public partial class MainWindowSecretary : Window
    {

            private static MainWindowSecretary instance = new MainWindowSecretary();


            public static MainWindowSecretary Instance
            {
                get
                {
                    return instance;
                }
            }


            public MainWindowSecretary()
            {
                InitializeComponent();
                
            }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Accounts1 accounts = new Accounts1();
            accounts.Show();

            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            LoginSecretary login = new LoginSecretary();
            login.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Appointments appointments = new Appointments();
            appointments.Show();
            this.Close();
        }
    }

}
