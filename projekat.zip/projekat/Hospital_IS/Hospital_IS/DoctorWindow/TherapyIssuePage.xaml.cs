﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for TherapyIssuePage.xaml
    /// </summary>
    public partial class TherapyIssuePage : Page
    {

        public Patient patient { get; set; }
        public BindingList<Therapy> therapies { get; set; }
        public BindingList<TherapyDTO> therapiesDTO { get; set; }

        private PatientController patientController = new PatientController();

        public TherapyIssuePage(Patient patient)
        {
            InitializeComponent();

            this.patient = patient;
            therapies = new BindingList<Therapy>();
            therapiesDTO = new BindingList<TherapyDTO>();
            patientNameTextBlock.Text = "Pacijent: " + patient.name + " " + patient.surname;

            DataContext = this;
        }

        private void addTherapyButton_Click(object sender, RoutedEventArgs e)
        {
            

            Doctor doctor = MainWindowDoctor.GetInstance().getLoggedDoctor();
            DateTime startDate = (DateTime)startDateDatePicker.SelectedDate;
            DateTime endDate = (DateTime)endDateDatePicker.SelectedDate;
            string description = therapyDescriptionTextBox.Text;
            int dailyFrequency = int.Parse(frequency.Text);
            string therapyNameAndDosage = medicationNameTextBox.Text;

            if(startDate <= endDate)
            {
                Therapy therapy = new Therapy(doctor, startDate, endDate, description, dailyFrequency, therapyNameAndDosage);
                TherapyDTO therapyDTO = new TherapyDTO(therapy);
                therapies.Add(therapy);
                therapiesDTO.Add(therapyDTO);
            }

            else
            {
                MessageBox.Show("Pocetni datum mora biti manji ili jednak krajnjem!");
            }
            
        }

        private void removeTherapyButton_Click(object sender, RoutedEventArgs e)
        {
            TherapyDTO therapyDTO = (TherapyDTO)dgTherapies.SelectedItem;
            string idToRemove = therapyDTO.id;

            foreach(TherapyDTO dto in therapiesDTO)
            {
                if (dto.id.Equals(idToRemove))
                {
                    therapiesDTO.Remove(dto);
                    break;
                }                
            }

            foreach(Therapy t in therapies)
            {
                if(t.id.Equals(idToRemove))
                {
                    therapies.Remove(t);
                    break;
                }
            }
        }

        private void issueTherapiesButton_Click(object sender, RoutedEventArgs e)
        {

            foreach(Therapy therapy in therapies)
            {
                patient.therapies.Add(therapy);
            }
            patientController.CreateOrUpdate(patient);

            MainWindowDoctor.GetInstance().MainFrame.Content = new PatientFilePage(patient.userID, "PatientsPage");
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = new PatientFilePage(patient.userID, "PatientsPage");
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

    }
}
