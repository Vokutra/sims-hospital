﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class PatientDTO
    {
        public string name { get; set; }
        public string surname { get; set; }
        public string yearOfBirth { get; set; }
        public string userID { get; set; }

        public PatientDTO(string name, string surname, string yearOfBirth, string userID)
        {
            this.name = name;
            this.surname = surname;
            this.yearOfBirth = yearOfBirth;
            this.userID = userID;
        }
    }
}
