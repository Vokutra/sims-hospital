﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Model
{
    public class Therapy
    {
        public Doctor doctor { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string description { get; set; }
        public int dailyFrequency { get; set; }
        public string medicationNameAndDosage { get; set; }
        public string id { get; set; }

        public Therapy(Doctor doctor, DateTime startDate, DateTime endDate, string description, int dailyFrequency, string medicationNameAndDosage)
        {
            this.doctor = doctor;
            this.startDate = startDate;
            this.endDate = endDate;
            this.description = description;
            this.dailyFrequency = dailyFrequency;
            this.medicationNameAndDosage = medicationNameAndDosage;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }
    }
}
