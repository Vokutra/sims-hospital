using Newtonsoft.Json;
using System;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Manager : UserAccount
    {

        [JsonConstructor]
        public Manager(string name, string lastname, string username, string password, string userID)
        {
            this.name = name;
            this.surname = lastname;
            this.username = username;
            this.password = password;
            this.userID = userID;
        }

    }
}