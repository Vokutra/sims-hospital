﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for NotificationPage.xaml
    /// </summary>
    public partial class NotificationPage : Page
    {
        private NotificationController notificationController = new NotificationController();
        public NotificationPage(string title, string message)
        {
            InitializeComponent();
            txtBoxTitle.Text = title;
            txtBoxMessage.Text = message;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            Notifications notificationsPage = new Notifications();
            foreach (Notification notification in notificationController.GetNotificationsForUser(LoginPatient.patient.userID))
            {
                Notifications.notificationsDTO.Insert(0, new NotificationDTO(notification.title, notification.sentTime.ToString("MM / dd / yyyy h: mm tt"), notification.id));
            }
            MainWindowPatient.getInstance().SetContent(notificationsPage);
        }
    }
}
