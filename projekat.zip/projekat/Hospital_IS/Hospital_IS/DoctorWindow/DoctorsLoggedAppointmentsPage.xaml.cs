﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for DoctorsLoggedAppointmentsPage.xaml
    /// </summary>
    public partial class DoctorsLoggedAppointmentsPage : Page
    {
        public static DoctorsLoggedAppointmentsPage instance;
        public static Doctor loggedDoctor;
        private DoctorController doctorController = new DoctorController();
        private PatientController patientController = new PatientController();
        private AppointmentController appointmentController = new AppointmentController();
        private RoomController roomController = new RoomController();
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();
        public BindingList<AppointmentDoctorDTO> appointmentsDTO { get; set; }

        public List<LoggedAppointment> loggedAppointments;

        public Frame mainFrame { get; set; }
        public DoctorsLoggedAppointmentsPage(Doctor doctor)
        {
            InitializeComponent();

            loggedDoctor = doctor;

            appointmentsDTO = new BindingList<AppointmentDoctorDTO>();

            DataContext = this;
        }

        public static DoctorsLoggedAppointmentsPage GetInstance(Doctor doctor, Frame mainFrame)
        {
            if (instance == null)
            {
                loggedDoctor = doctor;
                instance = new DoctorsLoggedAppointmentsPage(loggedDoctor);
                instance.mainFrame = mainFrame;
                instance.refreshAppointments();
            }

            instance.refreshAppointments();
            return instance;
        }

        public static DoctorsLoggedAppointmentsPage GetInstance()
        {
            //instance.refreshAppointments();
            return instance;
        }

        public void refreshAppointments()
        {

            loggedAppointments = loggedAppointmentController.GetLoggedAppointmentsByDoctor(loggedDoctor);

            appointmentsDTO.Clear();

            foreach (LoggedAppointment la in loggedAppointments)
            {
                if (la.appointmentType == AppointmentType.Examination)
                    appointmentsDTO.Add(new AppointmentDoctorDTO(patientController.GetPatientById(la.patient.userID).ToString(), la.startTime.ToShortDateString(), la.startTime.ToString("HH:mm"), roomController.getRoomById(la.room.roomName).ToString(), "Pregled", la.id, la.durationInMinutes.ToString() + " min"));
                else
                    appointmentsDTO.Add(new AppointmentDoctorDTO(patientController.GetPatientById(la.patient.userID).ToString(), la.startTime.ToShortDateString(), la.startTime.ToString("HH:mm"), roomController.getRoomById(la.room.roomName).ToString(), "Operacija", la.id, la.durationInMinutes.ToString() + " min"));
            }
        }

        private void loggedAppointmentInfoButton_Click(object sender, RoutedEventArgs e)
        {
            AppointmentDoctorDTO a = (AppointmentDoctorDTO)dgAppointments.SelectedItem;

            string appointmentID = a.id;

            DoctorsLoggedAppointmentsPage.GetInstance().mainFrame.Content = new LoggedAppointmentInfoPage(appointmentID, "DoctorsLoggedAppointmentsPage");
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            DoctorsLoggedAppointmentsPage.GetInstance().mainFrame.Content = new DoctorHomePage(loggedDoctor, mainFrame);
        }

        public void setInstanceToNull()
        {
            instance = null;
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }
    }
}
