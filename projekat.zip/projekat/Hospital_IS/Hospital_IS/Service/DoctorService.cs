using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Service
{
    public class DoctorService
    {
        private DoctorFileStorage doctorFileStorage = new DoctorFileStorage();
        private DoctorsShiftFileStorage doctorsShiftFileStorage = new DoctorsShiftFileStorage();
        private DoctorSurveyFileStorage doctorSurveyFileStorage = new DoctorSurveyFileStorage();

        public List<Doctor> GetAllDoctors()
        {
            return doctorFileStorage.GetEntityList();
        }

        public Doctor GetDoctor(String username)
        {
            return doctorFileStorage.ReadUser(username);
        }

        public Doctor FindDoctorById(string id)
        {
            return doctorFileStorage.FindById(id);
        }

        public void UpdateDoctor(String username)
        {
            throw new NotImplementedException();
        }

        public void UpdateDoctor(Doctor doctor)
        {
            doctorFileStorage.Update(doctor);
        }

        public Model.Doctor AddDoctor(Model.Doctor doctor)
        {
            throw new NotImplementedException();
        }

        public Boolean DeleteDoctor(Model.Doctor doctor)
        {
            throw new NotImplementedException();
        }

        public void ModifyAverageGrade(Doctor doctor)
        {
            double sum = 0;
            int counter = 0;
            foreach (DoctorSurvey doctorSurvey in doctorSurveyFileStorage.GetEntityList())
            {
                if (doctorSurvey.doctor.userID.Equals(doctor.userID))
                {
                    sum += doctorSurvey.averageGrade;
                    counter++;
                }
            }

            doctor.averageGrade = sum / counter;
        }

        public Boolean IsOnVacation(Model.Doctor doctor)
        {
            throw new NotImplementedException();
        }

        public List<String> GetAllLicenceNumbers()
        {
            throw new NotImplementedException();
        }

        public List<DoctorsShift> GetAllShiftsByDoctor(Doctor doctor)
        {
            List<DoctorsShift> doctorsShifts = new List<DoctorsShift>();
            foreach (DoctorsShift doctorsShift in doctorsShiftFileStorage.GetEntityList())
            {
                if (doctorsShift.doctor.userID.Equals(doctor.userID))
                    doctorsShifts.Add(doctorsShift);
            }

            return doctorsShifts;    
        }
        public DoctorsShift GetShiftForSpecificDate(Doctor doctor, DateTime day)
        {
            foreach (DoctorsShift doctorsShift in doctorsShiftFileStorage.GetEntityList())
            {
                if (doctorsShift.doctor.userID.Equals(doctor.userID) && doctorsShift.startDate <= day && doctorsShift.endDate >= day)
                {
                    return doctorsShift;
                }
            }
            return null;
        }

        public TimeSpan GetDoctorsStartWork(Doctor doctor, DateTime date)
        {
            List<DoctorsShift> doctorsShifts = GetAllShiftsByDoctor(doctor);
            foreach (DoctorsShift doctorsShift in doctorsShifts)
            {
                if (DateTime.Compare(doctorsShift.startDate, date) != 1 && DateTime.Compare(doctorsShift.endDate, date) != -1)
                {
                    return doctorsShift.shift.startTime;
                }
            }
            return default;
        }

        public TimeSpan GetDoctorsEndWork(Doctor doctor, DateTime date)
        {
            List<DoctorsShift> doctorsShifts = GetAllShiftsByDoctor(doctor);
            foreach (DoctorsShift doctorsShift in doctorsShifts)
            {
                if (DateTime.Compare(doctorsShift.startDate, date) != 1 && DateTime.Compare(doctorsShift.endDate, date) != -1)
                {
                    return doctorsShift.shift.endTime;
                }
            }
            return default;
        }

    }
}