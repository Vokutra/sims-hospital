﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public class InventoryFileStorage : GenericFileStorage<string, Inventory, InventoryFileStorage>, IInventoryFileStorage
    {
        protected override string GetKey(Inventory entity)
        {
            return entity.inventoryID;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\inventory.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Inventory entity)
        {
            entity.serialize = true;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
