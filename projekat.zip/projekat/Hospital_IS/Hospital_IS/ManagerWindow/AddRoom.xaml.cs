﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.View;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    
    public partial class AddRoom : Window
    {
        private Room room;
        private RoomController roomController = new RoomController();
        

        public AddRoom()
        {
            InitializeComponent();
        }


        public static RoomType StringToRoomType(string str)
        {
            
            return str switch
            {
                "Prijemna ambulanta" => RoomType.examinationRoom,
                "Operaciona sala" => RoomType.operationRoom,
                "Stacionar" => RoomType.accommodationRoom,
                _ => RoomType.accommodationRoom,
            };
        }

        public static int StringToFloor(string str)
        {
            return str switch
            {
                "Prvi" => 1,
                "Drugi" => 2,
                "Treci" => 3,
                _ => 1,
            };
        }


        public static bool StringToRoomAvailability(string dostupnost)
        {
            return dostupnost.Equals("Dostupna");
        }



        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            room = new Room();

            room.roomName = txtRoomName.Text;

            room.roomType = StringToRoomType(cbType.Text);
            room.isAvailable = StringToRoomAvailability(cbAvailability.Text);
            room.floorNumber = StringToFloor(cbFloor.Text);

            foreach (var r in roomController.GetAllRooms())
            {
                if (room.roomName == r.roomName)
                {
                    MessageBox.Show("Prostorija sa ovim nazivom vec postoji!");
                    return;
                }
            }

            if (txtRoomName.Text == "" || cbFloor.Text == "" || cbAvailability.Text == "" || cbType.Text == "")
            {
                MessageBox.Show("Sva polja moraju biti popunjena!");
                return;
            }


            roomController.AddRoom(room);
            RoomsViewModel.rooms.Add(room);

            

            //ManagerWindow.Instance.SetContent(new RoomsPage());
            //ManagerWindow.Instance.SetLabel("Prostorije sa dodatom");

            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
