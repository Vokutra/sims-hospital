﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Model
{
    public class Referral
    {
        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
        public Specialization DoctorsSpecialization { get; set; }
        public DateTime ReferralDate { get; set; }
        public string Id { get; set; }

        public Referral(Doctor doctor, Patient patient, Specialization doctorsSpecialization)
        {
            this.Doctor = doctor;
            this.Patient = patient;
            this.DoctorsSpecialization = doctorsSpecialization;
            this.ReferralDate = DateTime.Now;
            this.Id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }


    }
}
