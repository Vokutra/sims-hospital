﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for LogAnAppointmentPage.xaml
    /// </summary>
    public partial class LogAnAppointmentPage : Page
    {

        public Appointment appointment { get; set; }

        private DoctorController doctorController = new DoctorController();
        private PatientController patientController = new PatientController();
        private AppointmentController appointmentController = new AppointmentController();
        private RoomController roomController = new RoomController();
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();

        public Patient patient { get; set; }
        public Doctor doctor { get; set; }

        public string description { get; set; }
        public string diagnosis { get; set; }

        public LogAnAppointmentPage(String appointmentID)
        {
            InitializeComponent();

            appointment = appointmentController.GetAppointment(appointmentID);
            patient = patientController.GetPatientById(appointment.patient.userID);
            doctor = doctorController.FindDoctorById(appointment.doctor.userID);

            initializeLogInfo();

        }

        private void initializeLogInfo()
        {
            patientNameTextBlock.Text = "Pacijent: " + patient.name + " " + patient.surname;
            dateTextBlock.Text = "Datum: " + appointment.startTime.ToShortDateString();
            if(appointment.appointmentType == AppointmentType.Examination)
                appointmentTypeTextBlock.Text = "Tip termina: Pregled";
            else
                appointmentTypeTextBlock.Text = "Tip termina: Operacija";
            appointmentTimeTextBlock.Text = "Vrijeme: " + appointment.startTime.TimeOfDay.ToString();
        }

        private void logAppointment_Button_Click(object sender, RoutedEventArgs e)
        {
            description = descriptionTextBox.Text;
            diagnosis = diagnosisTextBox.Text;
            LoggedAppointment loggedAppointment = new LoggedAppointment(appointment, description, diagnosis);

            RemoveAppointmentFromPatient(appointment.id);
            appointmentController.DeleteAppointment(appointment);
            loggedAppointmentController.CreateOrUpdate(loggedAppointment);

            DoctorAppointmentsPage.GetInstance().refreshAppointments();
            DoctorAppointmentsPage.GetInstance().mainFrame.Content = DoctorAppointmentsPage.GetInstance();
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            DoctorAppointmentsPage.GetInstance().mainFrame.Content = DoctorAppointmentsPage.GetInstance();
        }

        private void RemoveAppointmentFromPatient(string appointmentID)
        {
            int index = 0;
            foreach (string id in patient.appointmentIDs)
            {
                if (id.Equals(appointmentID))
                {
                    patient.appointmentIDs.RemoveAt(index);
                    patientController.CreateOrUpdate(patient);
                    return;
                }
                index++;
            }
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }


    }
}
