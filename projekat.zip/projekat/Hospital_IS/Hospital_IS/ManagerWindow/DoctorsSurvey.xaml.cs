﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for DoctorsSurvey.xaml
    /// </summary>
    public partial class DoctorsSurvey : Window
    {
        private DoctorController doctorController = new DoctorController();
        public static BindingList<Doctor> doctorsList { get; set; }
        public DoctorsSurvey()
        {
            InitializeComponent();
            doctorsList = new BindingList<Doctor>(doctorController.GetAllDoctors());
            DataContext = this;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            Doctor SelectedDoctor = doctorsTable.SelectedItem as Doctor;

            if (SelectedDoctor == null)
            {
                MessageBox.Show("Izabrati lekara.");
                return;
            }

            DoctorGradesGraph doctorGradesGraph = new DoctorGradesGraph(SelectedDoctor);
            doctorGradesGraph.Show();
        }
    }
}
