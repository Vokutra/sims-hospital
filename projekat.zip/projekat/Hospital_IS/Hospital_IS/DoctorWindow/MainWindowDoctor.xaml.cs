﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for MainWindowDoctor.xaml
    /// </summary>
    public partial class MainWindowDoctor : Window
    {
        public static MainWindowDoctor instance;

        public static Doctor loggedDoctor { get; set; }

        public static MainWindowDoctor GetInstance(Doctor doctor)
        {
            if (instance == null)
            {
                loggedDoctor = doctor;
                instance = new MainWindowDoctor();
            }

            loggedDoctor = doctor;
            instance.MainFrame.Content = new DoctorHomePage(doctor, instance.MainFrame);

            return instance;
        }

        public static MainWindowDoctor GetInstance()
        {

            return instance;
        }

        public MainWindowDoctor()
        {
            InitializeComponent();
        }

        public Doctor getLoggedDoctor()
        {
            return loggedDoctor;
        }

        public void setInstanceToNull()
        {
            instance = null;
        }
    }
}
