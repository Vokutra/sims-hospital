﻿using Hospital_IS.Model;

namespace Hospital_IS.DTO
{
    public class AppointmentDoctorDTO
    {
        public string patient { get; set; }
        public string doctor { get; set; }
        public string date { get; set; }
        public string time { get; set; }
        public string room { get; set; }
        public string appointmentType { get; set; }
        public string diagnosis { get; set; }
        public string duration { get; set; }

        public string id { get; set; }

        public AppointmentDoctorDTO(string patient, string date, string time, string room, string appointmentType, string id)
        {
            this.patient = patient;
            this.date = date;
            this.time = time;
            this.room = room;
            this.appointmentType = appointmentType;
            this.id = id;
        }

        public AppointmentDoctorDTO(string patient, string date, string time, string room, string appointmentType, string id, string duration)
        {
            this.patient = patient;
            this.date = date;
            this.time = time;
            this.room = room;
            this.appointmentType = appointmentType;
            this.duration = duration;
            this.id = id;
        }

        public AppointmentDoctorDTO(Doctor doctor, string date, string time, string duration, string type, string diagnosis, string id)
        {
            this.doctor = doctor.name + " " + doctor.surname;
            this.date = date;
            this.time = time;
            this.appointmentType = type;
            this.duration = duration;
            this.id = id;
            this.diagnosis = diagnosis;
        }

        public AppointmentDoctorDTO(Doctor doctor, string date, string time, string duration, string type, string id)

        {
            this.doctor = doctor.name + " " + doctor.surname;
            this.date = date;
            this.time = time;
            this.appointmentType = type;
            this.duration = duration;
            this.id = id;
        }
    }
}
