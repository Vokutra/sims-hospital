﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class LoggedAppointmentFileStorage : GenericFileStorage<string, LoggedAppointment, LoggedAppointmentFileStorage>
    {
        protected override string GetKey(LoggedAppointment entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\loggedAppointments.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(LoggedAppointment entity)
        {
            entity.serialize = true;
            entity.patient.serialize = false;
            entity.doctor.serialize = false;
            entity.room.serialize = false;
        }
    }
}
