﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class PrescriptionDTO
    {
        public Doctor doctor { get; set; }
        public Patient patient { get; set; }
        public string issueDate { get; set; }
        public string description { get; set; }
        public string medicationNameAndDosage { get; set; }
        public string id { get; set; }

        public PrescriptionDTO(Prescription prescription)
        {
            this.doctor = prescription.doctor;
            this.patient = prescription.patient;
            this.issueDate = prescription.issueDate.ToShortDateString();
            this.description = prescription.description;
            this.medicationNameAndDosage = prescription.medicationNameAndDosage;
            this.id = prescription.id;
        }
    }
}
