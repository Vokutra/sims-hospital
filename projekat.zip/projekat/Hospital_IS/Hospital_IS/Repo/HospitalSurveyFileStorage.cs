﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public class HospitalSurveyFileStorage : GenericFileStorage<string, HospitalSurvey, HospitalSurveyFileStorage>
    {
        protected override string GetKey(HospitalSurvey entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\JSONData\hospitalSurveys.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(HospitalSurvey entity)
        {
            entity.patient.serialize = false;
        }
    }
}
