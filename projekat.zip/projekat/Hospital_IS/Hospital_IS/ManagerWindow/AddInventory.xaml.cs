﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for AddInventory.xaml
    /// </summary>
    public partial class AddInventory : Window
    {
        private Inventory inventory;
        private InventoryContoller inventoryController = new InventoryContoller();
        private List<Inventory> allInventories = new List<Inventory>();
        private Inventory inventoryForUpdate;
        private int amount;
        public AddInventory()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
          
           Int32.TryParse(txtAmount.Text, out int amount);

            inventory = new Inventory();

            bool inventoryExist = false;
            allInventories = inventoryController.GetEntityList();

            foreach (Inventory item in allInventories)
            {
                if (item.name.Equals(txtInventoryName.Text))
                {
                    inventoryExist = true;
                    inventoryForUpdate = item;
                }
            }

            if (inventoryExist == true)
            {
                inventoryForUpdate.amount += Int32.Parse(txtAmount.Text);
                inventoryController.UpdateInventory(inventoryForUpdate);
            }

            else
            {
                inventory.inventoryID = txtInventoryID.Text;
                inventory.name = txtInventoryName.Text;
                inventory.amount = amount;
                inventory.inventoryType = StringToInventoryType(cbInventoryType.Text);

                foreach (var i in inventoryController.GetEntityList())
                {
                    if (inventory.inventoryID == i.inventoryID)
                    {
                        MessageBox.Show("Stavka sa ovom sifrom vec postoji!");
                        return;
                    }
                }

                if (txtInventoryID.Text == "" || txtInventoryName.Text == "" || txtAmount.Text == "" || cbInventoryType.Text == "")
                {
                    MessageBox.Show("Sva polja moraju biti popunjena!");
                    return;
                }

                inventoryController.AddInventory(inventory);
                InventoryViewModel.inventories.Add(inventory);
            }

            this.Close();

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public static InventoryType StringToInventoryType(string str)
        {

            return str switch
            {
                "Potrosna" => InventoryType.dynamical,
                "Nepotrosna" => InventoryType.statical,
                _ => InventoryType.statical
            };
        }
    }
}
