﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class RenovationFileStorage : GenericFileStorage<string, Renovation, RenovationFileStorage>, IRenovationFileStorage
    {
        protected override string GetKey(Renovation entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\renovation.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Renovation entity)
        {
            entity.room.serialize = false;
            entity.serialize = true;
        }
    }
}
