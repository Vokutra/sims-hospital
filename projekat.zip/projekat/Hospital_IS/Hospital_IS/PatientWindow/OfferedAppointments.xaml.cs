﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.PatientWindow.Toasts;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for OfferedAppointments.xaml
    /// </summary>
    public partial class OfferedAppointments : Page
    {
        private AppointmentController appointmentController = new AppointmentController();
        private PatientController patientController = new PatientController();
        private DoctorController doctorController = new DoctorController();
        public List<Appointment> availableAppointments { get; set; }
        public List<AppointmentDTO> availableAppointmentsDTO { get; set; }
        private Thread thread;
        public OfferedAppointments(List<AppointmentDTO> availableAppointmentsDTO, List<Appointment> availableAppointments)
        {
            this.availableAppointmentsDTO = availableAppointmentsDTO;
            this.availableAppointments = availableAppointments;
            InitializeComponent();
            DataContext = this;
        }

        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {

            AppointmentDTO selectedAppointmentDTO = (AppointmentDTO)dgOfferedAppointments.SelectedItem;
            foreach (Appointment appointment in availableAppointments)
            {
                if (selectedAppointmentDTO.id.Equals(appointment.id))
                {
                    appointmentController.CreateAppointment(appointment);
                    LoginPatient.patient.appointmentIDs.Add(appointment.id);
                    patientController.UpdatePatient(LoginPatient.patient);
                    ScheduledAppointments.scheduledAppointmentsDTO.Add(new AppointmentDTO(appointment.startTime.ToShortDateString(), appointment.startTime.ToString("HH:mm"), doctorController.FindDoctorById(appointment.doctor.userID).ToString(), appointment.id, appointment.room.roomName));
                    break;
                }
            }

            MainWindowPatient.getInstance().SetContent(new StartPage());
            thread = new Thread(new ConfirmationToast().ShowConfirmationToast);
            thread.Start("Uspešno ste zakazali pregled!");

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            MainWindowPatient.getInstance().SetContent(new MakeAppointment());
        }
    }
}
