﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    
    public partial class EditRoom : Window
    {
        private Room selectedRoom;
        private RoomController roomController = new RoomController();
        private RoomInventoryPage inventar;


        public EditRoom(Room room)
        {
        selectedRoom = RoomFileStorage.Instance.FindById(room.roomName);

            InitializeComponent();
            this.DataContext = this;

            txtRoomName.Content = selectedRoom.roomName;
            cbFloor.Text = FloorToString(selectedRoom.floorNumber);
            cbType.Text = RoomTypeToString(selectedRoom.roomType);
            cbAvailability.Text = AvailabilityToString(selectedRoom.isAvailable);

            inventar = new RoomInventoryPage(selectedRoom);
        }

        public static RoomType StringToRoomType(string str)
        {

            return str switch
            {
                "Prijemna ambulanta" => RoomType.examinationRoom,
                "Operaciona sala" => RoomType.operationRoom,
                "Stacionar" => RoomType.accommodationRoom,
                _ => RoomType.accommodationRoom,
            };
        }

        public static int StringToFloor(string str)
        {
            return str switch
            {
                "Prvi" => 1,
                "Drugi" => 2,
                "Treci" => 3,
                _ => 1,
            };
        }

        public static string FloorToString(int number)
        {
            return number switch
            {
                1 => "Prvi",
                2 => "Drugi",
                3 => "Treci",
                _ => "Prvi",
            };
        }

        public string RoomTypeToString( RoomType type)
        {
           
                return type switch
                {
                    RoomType.examinationRoom => "Prijemna ambulanta",
                    RoomType.operationRoom => "Operaciona sala",
                    RoomType.accommodationRoom => "Stacionar",
                    _ => "",
                };
            
        }

        public string AvailabilityToString( bool dostupna) 
        {
            if (dostupna == true) 
            {
                return "Dostupna";
            }
            return "Nedostupna";
        }


        public static bool StringToRoomAvailability(string dostupnost)
        {
            return dostupnost.Equals("Dostupna");
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            //           selectedRoom.roomName = txtRoomName.Text;

            int i;
            for(i=0; i< RoomsViewModel.rooms.Count; i++)
            {
                if (RoomsViewModel.rooms[i].roomName.Equals(selectedRoom.roomName))
                {
                    RoomsViewModel.rooms.RemoveAt(i);
                    break;
                }
                    
            }

            selectedRoom.roomType = StringToRoomType(cbType.Text);
            selectedRoom.isAvailable = StringToRoomAvailability(cbAvailability.Text);
            selectedRoom.floorNumber = StringToFloor(cbFloor.Text);

            roomController.UpdateRoom(selectedRoom);

            RoomsViewModel.rooms.Insert(i, selectedRoom);

            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInventory_Click(object sender, RoutedEventArgs e)
        {
            RoomInventoryWindow roomInventoryWindow = new RoomInventoryWindow(selectedRoom);
            roomInventoryWindow.Show();
            
            //this.Content = inventar;
            //this.Title = "Inventar prostorije " + selectedRoom.roomName;
        }
    }
}
