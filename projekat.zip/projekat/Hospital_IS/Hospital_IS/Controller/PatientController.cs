using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Controller
{
    public class PatientController
    {
        private PatientService patientService = new PatientService();
        public List<Patient> GetAllPatients()
        {
            return patientService.GetAllPatients();
        }

        public Patient GetPatient(String username)
        {
            return patientService.GetPatient(username);
        }

        public Patient GetPatientById(string id)
        {
            return patientService.GetPatientById(id);
        }

        public void UpdatePatient(String username)
        {
            throw new NotImplementedException();
        }

        public void UpdatePatient(Patient patient)
        {
            patientService.UpdatePatient(patient);
        }

        public void AddPatient(Model.Patient patient)
        {
            patientService.AddPatient(patient);
        }

        public void DeletePatient(Model.Patient patient)
        {
            patientService.DeletePatient(patient);
        }

        public List<Patient> GetAllBannedPatients()
        {
            throw new NotImplementedException();
        }
        public void CreateOrUpdate(Patient patient)
        {
            patientService.UpdatePatient(patient);
        }

        public bool ShouldBeBanned(Patient patient)
        {
            return patientService.ShouldBeBanned(patient);
        }

        public List<Patient> SearchPatientsByNameOrSurname(string searchInput)
        {
            return patientService.SearchPatientsByNameOrSurname(searchInput);
        }

    }
}