﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for UpdateAppointmentPage.xaml
    /// </summary>
    public partial class UpdateAppointmentPage : Page
    {
        public List<Doctor> doctors { get; set; }

        public List<Patient> patients { get; set; }

        public List<Room> rooms { get; set; }

        public BindingList<string> allTimes { get; set; }
        public BindingList<string> times { get; set; }
        public BindingList<string> durations { get; set; }

        public BindingList<string> allDurations { get; set; }

        public string appointmentID { get; set; }

        private DoctorController doctorController = new DoctorController();
        private PatientController patientController = new PatientController();
        private AppointmentController appointmentController = new AppointmentController();
        private RoomController roomController = new RoomController();

        private List<Appointment> allAppointments = new List<Appointment>();

        public UpdateAppointmentPage(string id)
        {
            InitializeComponent();

            doctors = doctorController.GetAllDoctors();
            if (doctors == null)
                doctors = new List<Doctor>();

            patients = patientController.GetAllPatients();
            if (patients == null)
                patients = new List<Patient>();

            rooms = roomController.GetAllRooms();
            if (rooms == null)
                rooms = new List<Room>();

            allTimes = new BindingList<string> { "00:00", "00:10" , "00:20", "00:30", "00:40", "00:50", "01:00",
                "01:10" , "01:20", "01:30", "01:40", "01:50", "02:00", "02:10" , "02:20", "02:30", "02:40", "02:50", "03:00", "03:10" , "03:20", "03:30", "03:40",
                "03:50", "04:00", "04:10" , "04:20", "04:30", "04:40", "04:50", "05:00", "05:10" , "05:20", "05:30", "05:40", "05:50", "06:00","06:10" , "06:20",
                "06:30", "06:40", "06:50", "7:00", "7:10", "7:20", "7:30", "7:40", "7:50", "8:00", "8:10", "8:20", "8:30", "8:40", "8:50", "9:00", "9:10", "9:20",
                "9:30", "9:40", "9:50", "10:00", "10:10", "10:20", "10:30", "10:40", "10:50", "11:00", "11:10", "11:20", "11:30", "11:40", "11:50", "12:00",
                "12:10", "12:20", "12:30", "12:40", "12:50", "13:00", "13:10", "13:20", "13:30", "13:40", "13:50", "14:00", "14:10", "14:20", "14:30", "14:40",
                "14:50", "15:00", "15:10", "15:20", "15:30", "15:40", "15:50", "16:00", "16:10", "16:20", "16:30", "16:40", "16:50", "17:00", "17:10", "17:20",
                "17:30", "17:40", "17:50", "18:00", "18:10", "18:20", "18:30", "18:40", "18:50", "19:00", "19:10", "19:20", "19:30", "19:40", "19:50",  "20:00" ,
                "20:10" , "20:20" , "20:30", "20:40", "20:50", "21:00", "21:10", "21:20", "21:30", "21:40", "21:50", "22:00", "22:10", "22:20", "22:30", "22:40",
                "22:50", "23:00", "23:10", "23:20", "23:30", "23:40", "23:50"};

            times = new BindingList<string>();

            durations = new BindingList<string> { "5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60", "65", "70", "75", "80", "85", "90", "105", "120", "135", "150", "165", "180", "240" };

            allDurations = new BindingList<string> { "5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60", "65", "70", "75", "80", "85", "90", "105", "120", "135", "150", "165", "180", "240" };

            appointmentID = id;

            DataContext = this;

            InitializeComboboxes();

        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            Doctor doctor = (Doctor)doctorCombox.SelectedItem;
            Patient patient = (Patient)patientCombobox.SelectedItem;
            Room room = (Room)roomCombox.SelectedItem;


            DateTime examDate = (DateTime)datePicker.SelectedDate;
            string startTime = timeCombobox.Text;
            int startHour = int.Parse(startTime.Split(":")[0]);
            int startMinutes = int.Parse(startTime.Split(":")[1]);
            int duration = int.Parse(durationCombobox.SelectedItem.ToString());

            allAppointments = appointmentController.GetAppointmentsByDoctor(doctor);

            bool isAvailable = true;
            foreach (Appointment appointment in allAppointments)
            {
                if (appointment.startTime.Equals(examDate.Add(new TimeSpan(startHour, startMinutes, 0))))
                {
                    isAvailable = false;
                }
            }

            if (isAvailable)
            {
                foreach (Appointment a in appointmentController.GetAllAppointments())
                {
                    if (a.id.Equals(appointmentID))
                    {

                        a.doctor.userID = doctor.userID;
                        a.patient.userID = patient.userID;
                        a.startTime = examDate.Add(new TimeSpan(startHour, startMinutes, 0));
                        a.room.roomName = room.roomName;
                        a.durationInMinutes = duration;

                        appointmentController.CreateOrUpdate(a);

                        break;
                    }
                }
                DoctorAppointmentsPage.GetInstance().refreshAppointments();

                DoctorAppointmentsPage.GetInstance().mainFrame.Content = DoctorAppointmentsPage.GetInstance();
            }
            else
            {
                MessageBox.Show("Doktor vec ima zakazan termin u to vrijeme");
            }
        }

        public void InitializeComboboxes()
        {
            Appointment appointment = appointmentController.GetAppointment(appointmentID);

            //Doctor
            int index = 0;
            foreach (Doctor doctor in doctors)
            {
                if (doctor.userID.Equals(appointment.doctor.userID))
                {
                    break;
                }
                index++;
            }
            doctorCombox.SelectedIndex = index;


            //Patient
            index = 0;
            foreach (Patient patient in patients)
            {
                if (patient.userID.Equals(appointment.patient.userID))
                {
                    break;
                }
                index++;
            }
            patientCombobox.SelectedIndex = index;


            //Room
            index = 0;
            foreach (Room room in rooms)
            {
                if (room.roomName.Equals(appointment.room.roomName))
                {
                    break;
                }
                index++;
            }
            roomCombox.SelectedIndex = index;

            //Durations
            index = 0;
            int duration = appointment.durationInMinutes;
            foreach (string d in durations)
            {
                if (int.Parse(d) == duration)
                {
                    break;
                }
                index++;
            }
            durationCombobox.SelectedIndex = index;

            //Date
            datePicker.SelectedDate = appointment.startTime;
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            DoctorAppointmentsPage.GetInstance().mainFrame.Content = DoctorAppointmentsPage.GetInstance();
        }

        private void datePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            times.Clear();
            if (doctorCombox.SelectedIndex == -1 || patientCombobox.SelectedIndex == -1 || roomCombox.SelectedIndex == -1)
            {
                if (datePicker.SelectedDate == null)
                    datePicker.SelectedDate = DateTime.Now;
                return;
            }
            else
                checkAvailability();
        }

        private void patientDoctorRoomCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            times.Clear();
            if (doctorCombox.SelectedIndex == -1 || patientCombobox.SelectedIndex == -1 || roomCombox.SelectedIndex == -1)
            {
                if (datePicker.SelectedDate == null)
                    datePicker.SelectedDate = DateTime.Now;
                return;
            }
            else
                checkAvailability();
        }

        private void checkAvailability()
        {

            times.Clear();

            Doctor doctor = (Doctor)doctorCombox.SelectedItem;
            Patient patient = (Patient)patientCombobox.SelectedItem;
            Room room = (Room)roomCombox.SelectedItem;
            DateTime day = (DateTime)datePicker.SelectedDate;
            DoctorsShift shift = doctorController.GetShiftForSpecificDate(doctor, day);

            TimeSpan shiftStart = shift.shift.startTime;
            TimeSpan shiftEnd = shift.shift.endTime;

            // leave only the times which are in doctors shift that day

            for (int i = 0; i < allTimes.Count; i++)
            {
                if (TimeSpan.Parse(allTimes[i]) >= shiftStart && TimeSpan.Parse(allTimes[i]) <= shiftEnd)
                {
                    times.Add(allTimes[i]);
                }
            }

            //remove all times at which another doctors appointment starts and while it lasts
            List<Appointment> appointmentsForDay = appointmentController.getAppointmentsByDoctorPatientRoom(doctor, patient, room, day);
            for (int i = 0; i < times.Count - 1; i++)
            {
                foreach (Appointment a in appointmentsForDay)
                {
                    DateTime compare = a.startTime.Date;
                    compare = compare.AddHours(int.Parse(times[i].Split(":")[0]));
                    compare = compare.AddMinutes(int.Parse(times[i].Split(":")[1]));
                    if (a.startTime == compare)
                    {
                        if(!a.id.Equals(appointmentID))
                        {
                            times.RemoveAt(i);
                            int duration = a.durationInMinutes;
                            DateTime appointmentEndTime = a.startTime.AddMinutes(duration);
                            while (appointmentEndTime > compare)
                            {
                                times.RemoveAt(i);
                                compare = a.startTime.Date;
                                compare = compare.AddHours(int.Parse(times[i].Split(":")[0]));
                                compare = compare.AddMinutes(int.Parse(times[i].Split(":")[1]));
                            }
                        }
                        
                    }
                }
            }

        }

        //when time is selected check when the next appointment starts and adjust available durations accordingly
        private void timeCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (times.Count == 0)
            {
                durations.Clear();
                return;
            }

            resetDurations();

            DateTime day = (DateTime)datePicker.SelectedDate;
            int hoursToAdd = int.Parse(timeCombobox.SelectedItem.ToString().Split(":")[0]);
            int minutesToAdd = int.Parse(timeCombobox.SelectedItem.ToString().Split(":")[1]);
            day = day.AddHours(hoursToAdd);
            day = day.AddMinutes(minutesToAdd);

            Doctor doctor = (Doctor)doctorCombox.SelectedItem;
            Patient patient = (Patient)patientCombobox.SelectedItem;
            Room room = (Room)roomCombox.SelectedItem;

            if (appointmentController.existsAppointmentAfter(day, doctor, patient, room) == false)
                return;

            else
            {
                Appointment nextAppointment = appointmentController.getNearestNextAppointment(day, doctor, patient, room);

                int i = durations.Count - 1;
                while (day.AddMinutes(int.Parse(durations[i])) > nextAppointment.startTime)
                {
                    durations.RemoveAt(i);
                    i--;
                }
            }
        }

        private void resetDurations()
        {
            durations.Clear();
            durations.Add("5"); durations.Add("10"); durations.Add("15"); durations.Add("20"); durations.Add("25"); durations.Add("30"); durations.Add("35"); durations.Add("40"); durations.Add("45"); durations.Add("50"); durations.Add("55"); durations.Add("60"); durations.Add("65"); durations.Add("70"); durations.Add("75"); durations.Add("80"); durations.Add("80"); durations.Add("85"); durations.Add("90"); durations.Add("105"); durations.Add("120"); durations.Add("135"); durations.Add("150"); durations.Add("165"); durations.Add("180"); durations.Add("240");
        }
    }
}
