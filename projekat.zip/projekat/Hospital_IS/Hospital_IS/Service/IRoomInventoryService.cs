﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface IRoomInventoryService
    {
        public void AddRoomInventory(RoomInventory inventory);

        public List<RoomInventory> GetAllRoomInventories();

        public List<RoomInventory> GetInventoriesByRoom(Room room);

        public void UpdateInventory(RoomInventory inventory);

        public void MoveInventory(Room secondRoom, Room newRoom, DateTime? endDate);

        public string GetNameByInventory(RoomInventory roomInventory);

        public void DeleteRoomInventory(RoomInventory inventory);

        public void RelocateOnDate(object state);

    }
}
