﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hospital_IS.Service
{
    public class HospitalSurveyService
    {
        private HospitalSurveyFileStorage hospitalSurveyFileStorage = new HospitalSurveyFileStorage();
        private LoggedAppointmentService loggedAppointmentService = new LoggedAppointmentService();
        public void SaveSurvey(HospitalSurvey hospitalSurvey)
        {
            hospitalSurveyFileStorage.CreateOrUpdate(hospitalSurvey);
        }

        public List<HospitalSurvey> GetAllHospitalSurveysByPatient(Patient patient)
        {
            List<HospitalSurvey> hospitalSurveys = new List<HospitalSurvey>();
            foreach (HospitalSurvey hospitalSurvey in hospitalSurveyFileStorage.GetEntityList())
            {
                if (hospitalSurvey.patient.userID.Equals(patient.userID))
                {
                    hospitalSurveys.Add(hospitalSurvey);
                }
            }

            return hospitalSurveys;
        }

        public List<HospitalSurvey> GetAllHospitalSurveysByGrade(int grade)
        {
            List<HospitalSurvey> hospitalSurveys = new List<HospitalSurvey>();
            foreach (HospitalSurvey hospitalSurvey in hospitalSurveyFileStorage.GetEntityList())
            {
                foreach (int value in hospitalSurvey.answers.Values)
                {
                    if (grade == value)
                    {
                        hospitalSurveys.Add(hospitalSurvey);
                    }
                }
            }

            return hospitalSurveys;
        }

        public double GetAverageGradeByQuestion(string question)
        {
            List<HospitalSurvey> hospitalSurveys = new List<HospitalSurvey>();
            int sum = 0;
            foreach (HospitalSurvey hospitalSurvey in hospitalSurveyFileStorage.GetEntityList())
            {
                foreach (string answer in hospitalSurvey.answers.Keys)
                {
                    if (question.Equals(answer))
                    {
                        hospitalSurveys.Add(hospitalSurvey);
                        sum += hospitalSurvey.answers[question];
                        
                    }
                }
            }
            return (Double)sum / hospitalSurveys.Count();
        }

        public DateTime GetTimeOfLastSubmission(Patient patient)
        {
            DateTime timeOfLastSubmission = DateTime.MinValue;
            List<HospitalSurvey> hospitalSurveys = GetAllHospitalSurveysByPatient(patient);
            if (hospitalSurveys.Count > 0)
                timeOfLastSubmission = hospitalSurveys.Last().submissionTime;

            return timeOfLastSubmission;
        }

        public bool IsHospitalSurveyActive(Patient patient)
        {
            bool isActive = false;
            if (loggedAppointmentService.GetLoggedAppointmentsByPatient(patient).Count > 0)
            {
                if (GetTimeOfLastSubmission(patient) < loggedAppointmentService.GetLoggedAppointmentsByPatient(patient).Last().startTime)
                    isActive = true;
            }

            return isActive;
        }

    }
}
