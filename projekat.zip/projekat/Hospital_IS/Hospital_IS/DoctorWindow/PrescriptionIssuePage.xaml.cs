﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for PrescriptionIssuePage.xaml
    /// </summary>
    public partial class PrescriptionIssuePage : Page
    {
        public Patient patient { get; set; }
        public BindingList<Prescription> precriptions { get; set; }
        public BindingList<PrescriptionDTO> prescriptionsDTO { get; set; }

        private PatientController patientController = new PatientController();
        private PrescriptionController prescriptionController = new PrescriptionController();
        public PrescriptionIssuePage(Patient patient)
        {
            InitializeComponent();

            this.patient = patient;
            precriptions = new BindingList<Prescription>();
            prescriptionsDTO = new BindingList<PrescriptionDTO>();

            patientNameTextBlock.Text = "Pacijent: " + patient.name + " " + patient.surname;

            DataContext = this;
        }
        private void addPrescriptionButton_Click(object sender, RoutedEventArgs e)
        {
            Doctor doctor = MainWindowDoctor.GetInstance().getLoggedDoctor();
            DateTime issueDate = DateTime.Now.Date;
            string description = therapyDescriptionTextBox.Text;
            string medicationNameAndDosage = medicationNameTextBox.Text;

            Prescription prescription = new Prescription(doctor, patient, issueDate, description, medicationNameAndDosage);
            PrescriptionDTO prescriptionDTO = new PrescriptionDTO(prescription);

            precriptions.Add(prescription);
            prescriptionsDTO.Add(prescriptionDTO);
        }

        private void removePrescrptionButton_Click(object sender, RoutedEventArgs e)
        {
            PrescriptionDTO prescriptionDTO = (PrescriptionDTO)dgTherapies.SelectedItem;
            string idToRemove = prescriptionDTO.id;

            foreach (PrescriptionDTO dto in prescriptionsDTO)
            {
                if (dto.id.Equals(idToRemove))
                {
                    prescriptionsDTO.Remove(dto);
                    break;
                }
            }

            foreach (Prescription p  in precriptions)
            {
                if (p.id.Equals(idToRemove))
                {
                    precriptions.Remove(p);
                    break;
                }
            }
        }

        private void issuePrescriptionsButton_Click(object sender, RoutedEventArgs e)
        {
            foreach(Prescription p in precriptions)
            {
                prescriptionController.CreateOrUpdate(p);
            }

            MainWindowDoctor.GetInstance().MainFrame.Content = new PatientFilePage(patient.userID, "PatientsPage");
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = new PatientFilePage(patient.userID, "PatientsPage");
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }
    }
}
