﻿using Hospital_IS.Commands;
using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace Hospital_IS.ManagerWindow.ViewModel
{
    class InventoryViewModel
    {
        private Inventory selectedItem;
        public static ObservableCollection<Inventory> inventories { get; set; }
        private InventoryContoller inventoryController = new InventoryContoller();
        private string type;
        public RelayCommand PurchaseCommand { get; set; }
        public RelayCommand RelocateCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }

        public Inventory SelectedItem
        {
            get { return selectedItem; }
            set { selectedItem = value; }
        }
        public InventoryViewModel()
        {
            inventories = new ObservableCollection<Inventory>(InventoryFileStorage.Instance.GetEntityList());
            PurchaseCommand = new RelayCommand(param => ExecutePurchase(), param => CanExecutePurchase());
            RelocateCommand = new RelayCommand(param => ExecuteRelocate(), param => CanExecuteRelocate());
            DeleteCommand = new RelayCommand(param => ExecuteDelete(), param => CanExecuteDelete());
        }

        private bool CanExecutePurchase()
        {
            return true;
        }

        private bool CanExecuteDelete()
        {
            if (selectedItem == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteDelete()
        {
            inventoryController.DeleteInventory(selectedItem);
            inventories.Remove(selectedItem);
        }

        private bool CanExecuteRelocate()
        {
            if (selectedItem == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteRelocate()
        {
            RelocateInventory relocateInventory = new RelocateInventory(selectedItem);
            relocateInventory.Show();
        }

        private void ExecutePurchase()
        {
            AddInventory addInventory = new AddInventory();
            addInventory.Show();
        }
    }

}
