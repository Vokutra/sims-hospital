﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Repo
{
    interface IInventoryFileStorage : IGenericFileStorage<Inventory, string>
    {
    }
}
