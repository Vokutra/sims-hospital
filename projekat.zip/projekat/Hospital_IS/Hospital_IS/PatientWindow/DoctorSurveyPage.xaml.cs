﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.PatientWindow.Toasts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for DoctorSurveyPage.xaml
    /// </summary>
    public partial class DoctorSurveyPage : Page
    {
        private DoctorSurveyController doctorSurveyController = new DoctorSurveyController();
        private DoctorController doctorController = new DoctorController();
        private Thread thread;
        public Doctor doctor { get; set; }
        public LoggedAppointment loggedAppointment { get; set; }
        public DoctorSurveyPage(Doctor doctor, LoggedAppointment loggedAppointment)
        {
            InitializeComponent();
            this.doctor = doctor;
            this.loggedAppointment = loggedAppointment;
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            DoctorSurvey doctorSurvey = new DoctorSurvey(txtComment.Text, LoginPatient.patient, doctor, loggedAppointment, loggedAppointment.id);
            doctorSurvey.answers.Add((string)question1.Content, answer1.Value);
            doctorSurvey.answers.Add((string)question2.Content, answer2.Value);
            doctorSurvey.answers.Add((string)question3.Content, answer3.Value);
            doctorSurvey.answers.Add((string)question4.Content, answer4.Value);
            doctorSurvey.answers.Add((string)question5.Content, answer5.Value);

            doctorSurvey.averageGrade = (double)(answer1.Value + answer2.Value + answer3.Value + answer4.Value + answer5.Value) / 5;

            doctorSurveyController.SaveSurvey(doctorSurvey);
            doctorController.ModifyAverageGrade(doctor);
            doctorController.UpdateDoctor(doctor);

            MainWindowPatient.getInstance().SetContent(new StartPage());
            thread = new Thread(new ConfirmationToast().ShowConfirmationToast);
            thread.Start("Ocena je dodata!");
        }
    }
}
