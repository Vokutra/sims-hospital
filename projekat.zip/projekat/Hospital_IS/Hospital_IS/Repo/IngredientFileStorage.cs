﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class IngredientFileStorage : GenericFileStorage<string, Ingredient, IngredientFileStorage>
    {
        protected override string GetKey(Ingredient entity)
        {
            return entity.ingredientId;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\JSONData\ingredients.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Ingredient entity)
        {
            entity.serialize = true;
        }

        public Ingredient GetIngredientByName(String ingredientName)
        {
            Ingredient retVal = new Ingredient();

            foreach (Ingredient ingredient in this.GetEntityList())
            {
                if (ingredient.ingredientName.Equals(ingredientName))
                {
                    retVal = ingredient;
                    break;
                }
            }
            return retVal;
        }
    }
}
