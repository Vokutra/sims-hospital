﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class AllergenController
    {
        private AllergenService allergenService = new AllergenService();
        public List<Allergen> GetAllAllergens()
        {
            return allergenService.GetAllAllergens();
        }

        public Allergen GetAllergen(String allergenName)
        {
            return allergenService.GetAllergen(allergenName);
        }

        public Allergen GetAllergenById(string id)
        {
            return allergenService.GetAllergenById(id);
        }

        public void UpdateAllergen(String allergenName)
        {
            throw new NotImplementedException();
        }

        public void UpdateAllergen(Allergen allergen)
        {
            allergenService.UpdateAllergen(allergen);
        }

        public void AddAllergen(Model.Allergen allergen)
        {
            allergenService.AddAllergen(allergen);
        }

        public void DeleteAllergen(Model.Allergen allergen)
        {
            allergenService.DeleteAllergen(allergen);
        }

        

    }
}

