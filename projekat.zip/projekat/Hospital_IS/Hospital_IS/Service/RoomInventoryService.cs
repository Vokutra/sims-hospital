﻿using Hospital_IS.DTO;
using Hospital_IS.ManagerWindow;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    class RoomInventoryService : IRoomInventoryService
    {
        private IRoomInventoryFileStorage roomInventoryFileStorage = new RoomInventoryFileStorage();
        private IRoomFileStorage roomFileStorage = new RoomFileStorage();
        private IInventoryFileStorage inventoryFileStorage = new InventoryFileStorage();
        private IInventoryService inventoryService = new InventoryService();


        public List<RoomInventory> dtos = new List<RoomInventory>();

        public void AddRoomInventory(RoomInventory inventory)
        {
            roomInventoryFileStorage.CreateOrUpdate(inventory);
        }


        public List<RoomInventory> GetAllRoomInventories()
        {
            return roomInventoryFileStorage.GetEntityList();
        }

        public List<RoomInventory> GetInventoriesByRoom(Room room) 
        {
            List<RoomInventory> roomInventory = new List<RoomInventory>();

            foreach (RoomInventory r in roomInventoryFileStorage.GetEntityList()) 
            { 
                if(r.room.roomName.Equals(room.roomName))
                {
                    roomInventory.Add(r);
                }
            }

            return roomInventory;
        }

        public void UpdateInventory(RoomInventory inventory)
        {
            roomInventoryFileStorage.CreateOrUpdate(inventory);
        }

        public void MoveInventory(Room secondRoom, Room newRoom, DateTime? endDate)
        {
            
            foreach (RoomInventory inventory in GetInventoriesByRoom(secondRoom))
                {
                    FindInventoryInNewRoom(newRoom, inventory, endDate);
                }
        }

        public string GetNameByInventory(RoomInventory roomInventory)
        {
            string name = "";
            foreach (Inventory equipment in inventoryService.GetEntityList()) 
            {
                if (roomInventory.inventory.inventoryID.Equals(equipment.inventoryID))
                {
                    name = equipment.name;
                }
            }
            return name;
        }

        private void FindInventoryInNewRoom(Room newRoom, RoomInventory equipment, DateTime? endDate)
        {
            bool exists = RoomInventoryExists(equipment, newRoom);
            RoomInventory roomInventory = new RoomInventory(newRoom, new Inventory(GetNameByInventory(equipment), equipment.inventory.inventoryID), equipment.amount, endDate);
            
            if (exists)
            {
                UpdatateNewRoomInventory(roomInventory);
            }
            else 
            {
                AddRoomInventory(roomInventory);
            }
            DeleteRoomInventory(equipment);     
        }

        private void UpdatateNewRoomInventory(RoomInventory roomInventory)
        {
            foreach( RoomInventory equipment in GetInventoriesByRoom(roomInventory.room))
            {
                if(equipment.inventory.inventoryID.Equals( roomInventory.inventory.inventoryID))
                {
                    equipment.amount += roomInventory.amount;
                    UpdateInventory(equipment);
                }
            }
        }

        private bool RoomInventoryExists(RoomInventory roomInventory, Room newRoom)
        {
            bool exists = false;
            foreach (RoomInventory newRoomInventory in GetInventoriesByRoom(newRoom))
            {
                if (newRoomInventory.inventory.inventoryID == roomInventory.inventory.inventoryID)
                {
                    exists = true;
                }
            }
            return exists;
        }
    

        
        public void DeleteRoomInventory(RoomInventory inventory)
        {
            roomInventoryFileStorage.DeleteByReference(inventory);
        }

        public void RelocateOnDate(object state)
        {
            List<RoomInventory> roomInventories = GetAllRoomInventories();
            foreach (RoomInventory r in roomInventories)
            {
                if (DateTime.Compare(DateTime.Today, (DateTime)r.date) == -1 )
                {
                    App.Current.Dispatcher.Invoke((Action)delegate
                    {
                        RoomInventoryPage.currentInventories.Remove(new RoomInventoryDTO(r.room.roomName, r.inventory.name, r.inventory.inventoryID, r.amount, r.inventory.inventoryType, r.date, r.id));
                    });
                }
            }
        }
    }
}
