﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Model
{
    public class VacationRequest
    {
        public Doctor Doctor { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public VacationRequestStatus Status { get; set; }
        public string ReasonForVacation { get; set; }
        public string Id { get; set; }

        public VacationRequest(Doctor doctor, DateTime startDate, DateTime endDate, VacationRequestStatus status, string reasonForVacation)
        {
            this.Doctor = doctor;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.Status = status;
            this.ReasonForVacation = reasonForVacation;
            this.Id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }
    }
}
