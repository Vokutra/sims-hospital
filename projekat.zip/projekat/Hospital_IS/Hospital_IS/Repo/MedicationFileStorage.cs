﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class MedicationFileStorage : GenericFileStorage<string, Medication, MedicationFileStorage>, IMedicationFileStorage
    {
        protected override string GetKey(Medication entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\JSONData\medications.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Medication entity)
        {
            entity.serialize = true;
            entity.alternative.serialize = false;
        }
        public Medication GetMedicationByName(String medicationName)
        {
            Medication retVal = new Medication();

            foreach (Medication medication in this.GetEntityList())
            {
                if (medication.name.Equals(medicationName))
                {
                    retVal = medication;
                    break;
                }
            }
            return retVal;
        }

        public List<string> GetAllMedicationNames()
        {
            List<string> keys = new List<string>();

            List<Medication> medications = GetEntityList();
            foreach (Medication m in medications)
            {
                keys.Add(m.name);
            }
            return keys;
        }
    }
}
