﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class InventoryContoller
    {
        private IInventoryService inventoryService = new InventoryService();
        
        public void AddInventory(Inventory inventory)
        {
            inventoryService.AddInventory(inventory);
        }

        public void DeleteInventory(Inventory inventory)
        {
            inventoryService.DeleteInventory(inventory);
        }

        public List<Inventory> GetEntityList()
        {
            return inventoryService.GetEntityList();
        }

        public void UpdateInventory(Inventory inventory) 
        {
            inventoryService.UpdateInventory(inventory);
        }

        public Inventory GetInventoryById(String id)
        {
            return inventoryService.GetInventoryById(id);
        }

        public List<Inventory> GetInventoriesByType(InventoryType type)
        {
            return inventoryService.GetInventoriesByType(type);
        }
    }
}
