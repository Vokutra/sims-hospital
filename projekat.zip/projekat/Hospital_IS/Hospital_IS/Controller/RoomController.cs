using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Controller
{
    public class RoomController
    {
        private IRoomService roomService = new RoomService();

        public Model.Room GetRoomByNumber(int roomNumber)
        {
            throw new NotImplementedException();
        }

        public List<Room> GetAllRooms()
        {
            return roomService.GetAllRooms();
        }

        public List<string> GetAllRoomNames()
        {
            return roomService.GetAllRoomNames();
        }

        public List<Room> GetRoomsByType(Model.RoomType roomType)
        {
            throw new NotImplementedException();
        }

        public List<Room> GetAvailableRooms(Model.RoomType type)
        {
            throw new NotImplementedException();
        }

        public void AddRoom(Model.Room room)
        {
            roomService.AddRoom(room);
        }

        public void UpdateRoom(Model.Room room)
        {
            roomService.UpdateRoom(room);
        }

        public void DeleteRoom(Model.Room room)
        {
            roomService.DeleteRoom(room);
        }

        public void TakeRoom(Model.Room room)
        {
            throw new NotImplementedException();
        }

        public void FreeRoom(Model.Room room)
        {
            throw new NotImplementedException();
        }

        public Room getRoomById(string id)
        {
            return roomService.GetRoomByName(id);
        }

        public Room GetByName(string name)
        {
            return roomService.GetRoomByName(name);
        }

    }
}