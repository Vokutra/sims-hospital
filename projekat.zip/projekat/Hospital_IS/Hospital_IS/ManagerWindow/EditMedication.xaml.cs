﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for EditMedication.xaml
    /// </summary>
    public partial class EditMedication : Window
    {
        private Medication selectedMedication;
        private IngredientController ingredientController = new IngredientController();
        private MedicationController medicationController = new MedicationController();
        public List<Ingredient> medicationIngredient { get; set; }

        public List<string> allMedications { get; set; }
        private ObservableCollection<Ingredient> allIngredients;
        public EditMedication(Medication medication)
        {
            selectedMedication = medicationController.GetMedicationById(medication.id);
            medicationIngredient = new List<Ingredient>();

            InitializeComponent();
            DataContext = this;

            allMedications = new List<string>(medicationController.GetAllMedicationNames());
            if (allMedications == null)
                allMedications = new List<string>();

            allIngredients = new ObservableCollection<Ingredient>(ingredientController.GetAllIngredients());
            ingredientsListView.ItemsSource = allIngredients;

            
            txtMedicationID.Content = medication.id;
            txtMedicationName.Text = medication.name;
            Medication alternative = medication.alternative;
            cbMedicationAlternative.Text = alternative.name;
            txtComment.Text = medication.doctorsApprovalComment;
            txtMedicationStatus.Content = MedicationStatusToString(medication.status);

            foreach (Ingredient a in allIngredients)
            {
                foreach (Ingredient ingredient in medication.ingredients)
                {
                    if (a.ingredientId.Equals(ingredient.ingredientId))
                    {
                        ingredientsListView.SelectedItems.Add(a);
                    }
                }
            }
            

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            int i;
            for (i = 0; i < MedicationViewModel.medications.Count; i++)
            {
                if (MedicationViewModel.medications[i].id.Equals(selectedMedication.id))
                {
                    MedicationViewModel.medications.RemoveAt(i);
                    break;
                }

            }


            selectedMedication.name = txtMedicationName.Text;
            string alternativeName = cbMedicationAlternative.Text;
            selectedMedication.alternative = medicationController.GetMedication(alternativeName);
            selectedMedication.status = MedicationStatus.waitingForApproval;
            selectedMedication.doctorsApprovalComment = txtComment.Text;

            var selectedItems = ingredientsListView.SelectedItems;
            foreach (Ingredient selectedItem in selectedItems)
            {
                Ingredient ingredient = (Ingredient)selectedItem;
                medicationIngredient.Add(ingredient);
            }
            selectedMedication.ingredients = medicationIngredient;

            medicationController.CreateOrUpdateMedication(selectedMedication);
            MedicationViewModel.medications.Add(selectedMedication);
            this.Close();

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public string MedicationStatusToString(MedicationStatus status)
        {

            return status switch
            {
                MedicationStatus.approved => "Odobren",
                MedicationStatus.waitingForApproval => "Na cekanju",
                MedicationStatus.denied => "Odbijen",
                _ => "",
            };

        }
    }
}
