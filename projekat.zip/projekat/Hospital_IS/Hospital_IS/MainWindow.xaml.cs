﻿using Hospital_IS.DoctorWindow;
using Hospital_IS.ManagerWindow;
using Hospital_IS.PatientWindow;
using Hospital_IS.SecretaryWindow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CenterWindowOnScreen();
        }

        private void btnPatient_Click(object sender, RoutedEventArgs e)
        {
            LoginPatient login = new LoginPatient();
            login.Show();
            this.Close();

        }

        private void CenterWindowOnScreen()
        {
            double screenWidth = System.Windows.SystemParameters.PrimaryScreenWidth;
            double screenHeight = System.Windows.SystemParameters.PrimaryScreenHeight;
            double windowWidth = this.Width;
            double windowHeight = this.Height;
            this.Left = (screenWidth / 2) - (windowWidth / 2);
            this.Top = (screenHeight / 2) - (windowHeight / 2);
        }

        private void btnDoctor_Click(object sender, RoutedEventArgs e)
        {
            LoginDoctor login = new LoginDoctor();
            login.Show();
            this.Close();
        }

        private void btnManager_Click(object sender, RoutedEventArgs e)
        {
            LoginManager login = new LoginManager();
            login.Show();
            this.Close();
        }

        private void btnSecretary_Click(object sender, RoutedEventArgs e)
        {
            LoginSecretary login = new LoginSecretary();
            login.Show();
            this.Close();
        }
    }
}
