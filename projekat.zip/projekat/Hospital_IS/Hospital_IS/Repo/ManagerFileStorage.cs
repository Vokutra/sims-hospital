﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class ManagerFileStorage : GenericFileStorage<string, Manager, ManagerFileStorage>
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        protected override string GetKey(Manager entity)
        {
            return entity.userID;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\manager.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Manager entity)
        {
            entity.serialize = true;
        }

        public Manager ReadUser(String username)
        {
            foreach (Manager m in this.GetEntityList())
            {
                if (m.username.Equals(username))
                    return m;
            }

            return null;
        }
    }
}
