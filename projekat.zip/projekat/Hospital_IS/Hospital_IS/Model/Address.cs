using System;

namespace Hospital_IS.Model
{
   public class Address
   {
      public string state;
      public string city;
      public string street;
      public string streetNumber;

        public Address(string state, string city, string street, string streetNumber)
        {
            this.state = state;
            this.city = city;
            this.street = street;
            this.streetNumber = streetNumber;
        }
    }
}