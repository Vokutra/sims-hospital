﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public class DoctorsShiftFileStorage : GenericFileStorage<string, DoctorsShift, DoctorsShiftFileStorage>
    {
        protected override string GetKey(DoctorsShift entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\JSONData\doctorsShifts.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(DoctorsShift entity)
        {
            entity.doctor.serialize = false;
        }
    }
}
