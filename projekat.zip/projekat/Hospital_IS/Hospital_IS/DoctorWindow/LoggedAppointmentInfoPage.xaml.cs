﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for LoggedAppointmentInfoPage.xaml
    /// </summary>
    public partial class LoggedAppointmentInfoPage : Page
    {
        public LoggedAppointment loggedAppointment { get; set; }
        public Patient patient { get; set; }
        public Doctor doctor { get; set; }
        private PatientController patientController = new PatientController();
        private DoctorController doctorController = new DoctorController();
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();

        public string previousPage { get; set; }

        public LoggedAppointmentInfoPage(string id, string previousPage)
        {
            InitializeComponent();

            this.loggedAppointment = loggedAppointmentController.GetById(id);
            this.patient = patientController.GetPatientById(loggedAppointment.patient.userID);
            this.doctor = doctorController.FindDoctorById(loggedAppointment.doctor.userID);
            this.previousPage = previousPage;

            InitializeTextBlocks();
        }

        public void InitializeTextBlocks()
        {
            patientNameTextBlock.Text = "Pacijent: " + patient.name + " " + patient.surname;
            doctorNameTextBlock.Text = "Doktor: " + doctor.name + " " + doctor.surname;
            dateTextBlock.Text = "Datum: " + loggedAppointment.startTime.ToShortDateString();
            if (loggedAppointment.appointmentType == AppointmentType.Examination)
                appointmentTypeTextBlock.Text = "Tip termina: Pregled";
            else
                appointmentTypeTextBlock.Text = "Tip termina: Operacija";
            appointmentTimeTextBlock.Text = "Vrijeme: " + loggedAppointment.startTime.TimeOfDay.ToString();
            descriptionTextBox.Text = loggedAppointment.description;
            diagnosisTextBox.Text = loggedAppointment.diagnosis;
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            if (previousPage.Equals("DoctorsLoggedAppointmentsPage"))
                MainWindowDoctor.GetInstance().MainFrame.Content = DoctorsLoggedAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
            else if (previousPage.Equals("PatientHistoryPage"))
                MainWindowDoctor.GetInstance().MainFrame.Content = new PatientHistoryPage(patient);
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }
    }
}
