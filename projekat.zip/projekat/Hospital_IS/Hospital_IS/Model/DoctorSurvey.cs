﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class DoctorSurvey
    {
        [DataMember]
        public Dictionary<string, int> answers { get; set; }
        [DataMember]
        public string comment { get; set; }
        [DataMember]
        public DateTime submissionTime { get; set; }
        [DataMember]
        public Patient patient { get; set; }
        [DataMember]
        public Doctor doctor { get; set; }
        [DataMember]
        public LoggedAppointment loggedAppointment { get; set; }
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public double averageGrade { get; set; }

        public DoctorSurvey(string comment, Patient patient, Doctor doctor, LoggedAppointment loggedAppointment, string surveyId)
        {
            this.answers = new Dictionary<string, int>();
            this.comment = comment;
            this.submissionTime = DateTime.Now;
            this.patient = patient;
            this.doctor = doctor;
            this.loggedAppointment = loggedAppointment;
            this.id = surveyId;
        }
    }
}
