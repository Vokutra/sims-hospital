﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class TherapyDTO
    {
        public Doctor doctor { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        public string description { get; set; }
        public int dailyFrequency { get; set; }
        public string medicationNameAndDosage { get; set; }
        public string id { get; set; }

        public TherapyDTO(Therapy therapy)
        {
            this.doctor = therapy.doctor;
            this.startDate = therapy.startDate.ToShortDateString();
            this.endDate = therapy.endDate.ToShortDateString();
            this.description = therapy.description;
            this.dailyFrequency = therapy.dailyFrequency;
            this.medicationNameAndDosage = therapy.medicationNameAndDosage;
            this.id = therapy.id;
        }

    }
}
