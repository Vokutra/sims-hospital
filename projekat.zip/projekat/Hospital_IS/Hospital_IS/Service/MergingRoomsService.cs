﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    
    class MergingRoomsService : IMergingRoomsService
    {
        public IMergingRoomsFileStorage mergingRoomsFileStorage = new MergingRoomsFileStorage();
        private IRoomService roomService = new RoomService();
        public RoomInventoryService roomInventoryService = new RoomInventoryService();
        public void AddMergingRooms(MergingRooms mergingRooms)
        {
            mergingRoomsFileStorage.CreateOrUpdate(mergingRooms);
        }


        public List<MergingRooms> GetAllMergingRooms()
        {
            return mergingRoomsFileStorage.GetEntityList();
        }



        public void UpdateMergingRooms(MergingRooms mergingRooms)
        {
            mergingRoomsFileStorage.CreateOrUpdate(mergingRooms);
        }

        public void DeleteMergingRooms(MergingRooms mergingRooms)
        {
            mergingRoomsFileStorage.DeleteByReference(mergingRooms);
        }

        public void MergeRooms(MergingRooms mergingRooms)
        {
            Room newRoom = mergingRooms.roomOne;
            //newRoom.roomType = mergingRooms.roomType;
            DateTime? endDate = mergingRooms.endDateRenovation;
            roomService.UpdateRoom(newRoom);

            Room secondRoom = mergingRooms.roomTwo;
            roomService.DeleteRoom(secondRoom);

            roomInventoryService.MoveInventory(secondRoom, newRoom, endDate);
        }

        public void MergeOnDate(object state)
        {
            List<MergingRooms> mergingRooms = new List<MergingRooms>();
            mergingRooms = GetAllMergingRooms();
            foreach (var merging in mergingRooms)
            {
                if (DateTime.Compare(DateTime.Today,(DateTime)merging.endDateRenovation) == -1)
                {
                    App.Current.Dispatcher.Invoke((Action)delegate
                    {
                        MergeRooms(merging);
                        MergingRoomsFileStorage.Instance.DeleteById(merging.id);
                    });
                }
            }
        }
    }
}
