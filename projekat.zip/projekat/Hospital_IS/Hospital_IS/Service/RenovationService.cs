﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    class RenovationService : IRenovationService
    {
        public IRenovationFileStorage renovationFileStorage = new RenovationFileStorage();
        private RoomController roomController = new RoomController();

        public void AddRenovation(Renovation renovation)
        {
            renovationFileStorage.CreateOrUpdate(renovation);
        }


        public List<Renovation> GetAllRenovations()
        {
            return renovationFileStorage.GetEntityList();

        }

        public void UpdateRenovation(Renovation renovation)
        {
            renovationFileStorage.CreateOrUpdate(renovation);
        }

        public void DeleteRenovation(Renovation renovation)
        {
            renovationFileStorage.DeleteByReference(renovation);
        }

        
        public void RenovateOnDate(object state)
        {
            List<Renovation> renovations = new List<Renovation>();
            renovations = GetAllRenovations();
            foreach (var renovating in renovations)
            {
                if (((DateTime.Compare((DateTime)renovating.startDateRenovation, DateTime.Today) < 0) && (DateTime.Compare(DateTime.Today, (DateTime)renovating.endDateRenovation) < 0) || (DateTime.Compare((DateTime)renovating.startDateRenovation, DateTime.Today) < 0)) && (DateTime.Compare(DateTime.Today, (DateTime)renovating.endDateRenovation) == 0))
                {
                    App.Current.Dispatcher.Invoke((Action)delegate
                    {
                        renovating.room.isAvailable = false;
                        roomController.UpdateRoom(renovating.room);

                        AddRenovation(renovating);
                    });
                }
            }
        }
    }
}
