﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class LoginDoctor : Window
    {
        public DoctorController doctorController = new DoctorController();
        public static Doctor doctor { get; set; }

        public LoginDoctor()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtBoxUsername.Text.Trim();
            string password = txtBoxPassword.Password.Trim();

            doctor = DoctorFileStorage.Instance.ReadUser(username);


            if (doctor != null && password.Equals(doctor.password))
            {
                MainWindowDoctor mainWindow = MainWindowDoctor.GetInstance(doctor);
                mainWindow.Show();
                this.Close();
            }

            else
            {
                MessageBox.Show("Pogresan username i/ili password!");
            }


        }
    }
}
