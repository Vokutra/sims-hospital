﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class HospitalSurvey
    {
        [DataMember]
        public Dictionary<string, int> answers { get; set; }
        [DataMember]
        public string comment { get; set; }
        [DataMember]
        public DateTime submissionTime { get; set; }
        [DataMember]
        public Patient patient { get; set; }
        [DataMember]
        public string id { get; set; }

        public HospitalSurvey(string comment, Patient patient, string surveyId)
        {
            this.comment = comment;
            this.submissionTime = DateTime.Now;
            this.patient = patient;
            this.id = surveyId;
            this.answers = new Dictionary<string, int>();
        }
    }
}
