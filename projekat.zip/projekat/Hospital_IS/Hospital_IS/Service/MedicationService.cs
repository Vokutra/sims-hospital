﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    class MedicationService : IMedicationService
    {
        private IMedicationFileStorage medicationFileStorage = new MedicationFileStorage();
        public List<string> GetAllMedicationNames()
        {
            return medicationFileStorage.GetAllMedicationNames();
        }

        public List<Medication> GetAllMedications()
        {
            return medicationFileStorage.GetEntityList();
        }

        public List<Medication> GetAllWaitingMedications()
        {
            List<Medication> medicationsOnWaiting = new List<Medication>();
            foreach(Medication med in GetAllMedications())
            {
                if(med.status == MedicationStatus.waitingForApproval)
                {
                    medicationsOnWaiting.Add(med);
                }
            }
            return medicationsOnWaiting;
        }

        public Medication GetMedication(String medicationName)
        {
            return medicationFileStorage.GetMedicationByName(medicationName);
        }

        public Medication GetMedicationById(string id)
        {
            return medicationFileStorage.FindById(id);
        }

        public void CreateOrUpdateMedication(Medication medication)
        {
            medicationFileStorage.CreateOrUpdate(medication);
        }

        public void DeleteMedication(Medication medication)
        {
            medicationFileStorage.DeleteByReference(medication);
        }
    }
}
