﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for MedicationInfoPage.xaml
    /// </summary>
    public partial class MedicationInfoPage : Page
    {
        private MedicationController medicationController = new MedicationController();
        public Medication medication { get; set; }

        public MedicationInfoPage(string medicationID)
        {
            InitializeComponent();

            this.medication = medicationController.GetMedicationById(medicationID);

            if(medication.status == MedicationStatus.approved)
            {
                approveButton.IsEnabled = false;
                doctorsCommentTextBox.IsReadOnly = true;
            }
            if(medication.status == MedicationStatus.denied || medication.status == MedicationStatus.approved)
            {
                denyButton.IsEnabled = false;
            }

            initializeInfo();
        }

        public void initializeInfo()
        {
            medicationNameTextBlock.Text = "Naziv lijeka: " + medication.name;
            Medication alternative = medicationController.GetMedicationById(medication.alternative.id);
            alternativeTextBlock.Text = "Zamjenski lijek: " + alternative.name;
            string ingredients = "";
            foreach(Ingredient i in medication.ingredients)
            {
                ingredients += i.ingredientName + ", ";
            }
            if(ingredients.Length != 0)
                ingredientsTextBlock.Text = "Sastojci: " + ingredients.Substring(0, ingredients.Length - 2);

            string status = medication.status switch
            {
                MedicationStatus.approved => "Odobren",
                MedicationStatus.waitingForApproval => "Na cekanju",
                MedicationStatus.denied => "Odbijen",
                _ => "",
            };
            statusTextBlock.Text = "Status: " + status;

            doctorsCommentTextBox.Text = medication.doctorsApprovalComment;
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = MedicationPage.getInstance();
        }

        private void approveButton_Click(object sender, RoutedEventArgs e)
        {
            medication.status = MedicationStatus.approved;
            medication.doctorsApprovalComment = doctorsCommentTextBox.Text;
            medicationController.CreateOrUpdateMedication(medication);

            MainWindowDoctor.GetInstance().MainFrame.Content = MedicationPage.getInstance();
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void denyButton_Click(object sender, RoutedEventArgs e)
        {
            medication.status = MedicationStatus.denied;
            medication.doctorsApprovalComment = doctorsCommentTextBox.Text;
            medicationController.CreateOrUpdateMedication(medication);

            MainWindowDoctor.GetInstance().MainFrame.Content = MedicationPage.getInstance();
        }
    }
}
