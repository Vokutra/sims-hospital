﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    public class PrescriptionService
    {
        public PrescriptionFileStorage prescriptionFileStorage = new PrescriptionFileStorage();

        public void CreateOrUpdate(Prescription prescription)
        {
            prescriptionFileStorage.CreateOrUpdate(prescription);
        }
    }
}
