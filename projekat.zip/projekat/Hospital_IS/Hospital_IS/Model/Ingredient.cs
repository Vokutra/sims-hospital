﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Ingredient
    {
        [DataMember]
        public string ingredientName { get; set; }
        [DataMember]
        public string ingredientId { get; set; }
        [DataMember]
        public bool serialize { get; set; }

        [JsonConstructor]
        public Ingredient(string ingredientName)
        {
            this.ingredientName = ingredientName;
            this.ingredientId = DateTime.Now.ToString("yyMMddhhmmssffffff");


        }

        public Ingredient()
        {
            this.ingredientName = "";
            this.ingredientId = "";
        }

        public bool ShouldSerializeingredientName()
        {
            return serialize;
        }

        public override string ToString()
        {
            return ingredientName;
        }
    }
}
