﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.SecretaryWindow
{
    /// <summary>
    /// Interaction logic for Accounts1.xaml
    /// </summary>
    public partial class Accounts1 : Window


    {
        public List<Allergen> allergens { get; set; }

        private ObservableCollection<Patient> patients;
        private ObservableCollection<Allergen> allAllergens;


        private PatientController patientController = new PatientController();



        private AllergenController allergenController = new AllergenController();
        private PatientFileStorage pfs = new PatientFileStorage();
        public Accounts1()
        {
            InitializeComponent();
            this.DataContext = this;
          

            patients = new ObservableCollection<Patient>(PatientFileStorage.Instance.GetEntityList());
            PatientTable.ItemsSource = patients;

            allAllergens = new ObservableCollection<Allergen>(AllergenFileStorage.Instance.GetEntityList());
            allergensListView.ItemsSource = allAllergens;


            allergens = new List<Allergen>();


        }
        private void dg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Patient SelectedPatient = PatientTable.SelectedItem as Patient;

            if (SelectedPatient == null)
            {
                MessageBox.Show("Izabrati pacijenta.");
                return;
            }
            EditPatient windowToOpen = new EditPatient(SelectedPatient);

            windowToOpen.Show();
        }
        public static Gender StringToGender(string str)
        {

            return str switch
            {
                "Muski" => Gender.male,
                "Zenski" => Gender.female,
                _ => Gender.female,
            };
        }
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnCreateDoctor_Click_1(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnCreatePatient_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string surname = txtSurname.Text;
            string userID = txtID.Text;
            string phoneNum = txtPhone.Text;
            string email = txtEmail.Text;
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            DateTime doB = (DateTime)dateField.SelectedDate;
            Gender gender = StringToGender(cbPatientGender.Text);
            string city = txtCity.Text;
            string state = txtState.Text;
            string streetNumber = txtNumber.Text;
            string street = txtStreet.Text;
            BloodType bloodType = StringToBloodType(cbBloodType.Text);
            
            var selectedItems = allergensListView.SelectedItems;
            foreach (Allergen selectedItem in selectedItems)
            {
                Allergen allergen = (Allergen)selectedItem;
                allergens.Add(allergen);
            }
           


            Address address = new Address(state, city, street, streetNumber);

            Patient patient = new Patient(name, surname, username, password, userID, phoneNum, email, address, doB, gender, bloodType, allergens);
           
            patientController.AddPatient(patient);

            this.Close();

            MainWindowSecretary mws = new MainWindowSecretary();
            mws.Show();

        }


        private void btnCreateEmergency_Click_1(object sender, RoutedEventArgs e)
        {

        }

     

        //private void btnAddAllergen_Click(object sender, RoutedEventArgs e)
        //{
        //    AddAllergen addAllergen = new AddAllergen();
        //    addAllergen.Show();
        //    this.Close();

        //}
        private void AddAllergenToPatient(string allergenId, string patientId)
        {
            Patient p = patientController.GetPatientById(patientId);
            Allergen a = allergenController.GetAllergenById(allergenId);
            p.allergens.Add(a);
            pfs.CreateOrUpdate(p);
        }
        public static BloodType StringToBloodType(string str)
        {

            return str switch
            {
                "A+" => BloodType.aPositive,
                "A-" => BloodType.aNegative,
                "B+" => BloodType.bPositive,
                "B-" => BloodType.bNegative,
                "AB+" => BloodType.aBPositive,
                "AB-" => BloodType.aBNegative,
                "0+" => BloodType.oPositive,
                "0-" => BloodType.oNegative,
                _ => BloodType.oNegative,
            };
        }

        private void btnEditAllergen_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDeleteAllergen_Click(object sender, RoutedEventArgs e)
        {

        }

        //private void AllergensTable_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        //{
        //    Allergen SelectedAllergen = AllergensTable.SelectedItem as Allergen;

        //    if (SelectedAllergen == null)
        //    {
        //        MessageBox.Show("Izabrati alergen.");
        //        return;
        //    }
        //    EditAllergen windowToOpen = new EditAllergen(SelectedAllergen);

        //    windowToOpen.Show();
        //}
    }
}
