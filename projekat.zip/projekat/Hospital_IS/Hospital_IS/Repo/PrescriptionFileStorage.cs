﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public class PrescriptionFileStorage : GenericFileStorage<string, Prescription, PrescriptionFileStorage>
    {
        protected override string GetKey(Prescription entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\prescriptions.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Prescription entity)
        {
            entity.doctor.serialize = false;
            entity.patient.serialize = false;
        }
    }
}
