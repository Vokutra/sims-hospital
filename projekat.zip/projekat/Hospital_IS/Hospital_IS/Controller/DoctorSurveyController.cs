﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;
    
namespace Hospital_IS.Controller
{
    public class DoctorSurveyController
    {
        private DoctorSurveyService doctorSurveyService = new DoctorSurveyService();

        public void SaveSurvey(DoctorSurvey doctorSurvey)
        {
            doctorSurveyService.SaveSurvey(doctorSurvey);
        }

        public DoctorSurvey GetDoctorSurveyById(string id)
        {
            return doctorSurveyService.GetDoctorSurveyById(id);
        }
        public List<DoctorSurvey> GetAllDoctorSurveysByDoctor(Doctor doctor)
        {
            return doctorSurveyService.GetAllDoctorSurveysByDoctor(doctor);
        }

        public List<DoctorSurvey> GetAllDoctorSurveysByGrade(int grade)
        {
            return doctorSurveyService.GetAllDoctorSurveysByGrade(grade);
        }

        public List<DoctorSurvey> GetGradeFromSurveyByGrade(int grade, DoctorSurvey doctorSurvey)
        {
           return doctorSurveyService.GetGradeFromSurveyByGrade(grade, doctorSurvey);
        }
    }
}
