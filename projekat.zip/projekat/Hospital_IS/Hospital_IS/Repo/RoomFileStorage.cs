using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Hospital_IS.Repo
{
    public class RoomFileStorage : GenericFileStorage<string, Room, RoomFileStorage>, IRoomFileStorage
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }


        protected override string GetKey(Room entity)
        {
            return entity.roomName;
        }

        public List<string> GetAllRoomNames()
        {
            List<string> keys = new List<string>();
            
            List<Room> rooms = this.ReadFile().Values.ToList();
            foreach (Room r in rooms) {
                keys = rooms.Select(r => r.roomName).ToList();
            }
            return keys;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\rooms.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Room entity)
        {
            entity.serialize = true;
        }

    }
}