﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class ReferralFileStorage : GenericFileStorage<string, Referral, ReferralFileStorage>
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        protected override string GetKey(Referral entity)
        {
            return entity.Id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\referrals.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Referral entity)
        {
            entity.Doctor.serialize = false;
            entity.Patient.serialize = false;
        }
    }
}
