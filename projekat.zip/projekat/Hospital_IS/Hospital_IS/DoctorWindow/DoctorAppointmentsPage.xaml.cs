﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for DoctorAppointmentsPage.xaml
    /// </summary>
    public partial class DoctorAppointmentsPage : Page
    {
        public static DoctorAppointmentsPage instance;
        public static Doctor loggedDoctor;
        private DoctorController doctorController = new DoctorController();
        private PatientController patientController = new PatientController();
        private AppointmentController appointmentController = new AppointmentController();
        private RoomController roomController = new RoomController();
        public BindingList<AppointmentDoctorDTO> appointmentsDTO { get; set; }

        public List<Appointment> appointments;

        public Frame mainFrame { get; set; }

        public DoctorAppointmentsPage(Doctor doctor)
        {
            InitializeComponent();

            loggedDoctor = doctor;

            appointmentsDTO = new BindingList<AppointmentDoctorDTO>();

            DataContext = this;
        }

        public static DoctorAppointmentsPage GetInstance(Doctor doctor, Frame mainFrame)
        {
            if (instance == null)
            {
                loggedDoctor = doctor;
                instance = new DoctorAppointmentsPage(loggedDoctor);
                instance.mainFrame = mainFrame;
                instance.refreshAppointments();
            }

            instance.refreshAppointments();
            return instance;
        }

        public static DoctorAppointmentsPage GetInstance()
        {
            //instance.refreshAppointments();
            return instance;
        }

        public void refreshAppointments()
        {

            appointments = appointmentController.GetAppointmentsByDoctor(loggedDoctor);

            appointmentsDTO.Clear();

            foreach (Appointment a in appointments)
            {
                if (a.appointmentType == AppointmentType.Examination)
                    appointmentsDTO.Add(new AppointmentDoctorDTO(patientController.GetPatientById(a.patient.userID).ToString(), a.startTime.ToShortDateString(), a.startTime.ToString("HH:mm"), roomController.getRoomById(a.room.roomName).ToString(), "Pregled", a.id));
                else
                    appointmentsDTO.Add(new AppointmentDoctorDTO(patientController.GetPatientById(a.patient.userID).ToString(), a.startTime.ToShortDateString(), a.startTime.ToString("HH:mm"), roomController.getRoomById(a.room.roomName).ToString(), "Operacija", a.id));
            }
        }

        private void Button_Add_Exam_Click(object sender, RoutedEventArgs e)
        {
            this.mainFrame.Content = new CreateExaminationPage();
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = new DoctorHomePage(loggedDoctor, mainFrame);
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            if (dgAppointments.SelectedItem != null)
            {
                if (MessageBox.Show("Jeste li sigurni da zelite da otkazete odabrani termin?",
                "Otkazivanje termina", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    AppointmentDoctorDTO a = (AppointmentDoctorDTO)dgAppointments.SelectedItem;

                    Appointment appointment = appointmentController.GetAppointment(a.id);

                    RemoveAppointmentFromPatient(a.id, appointment);

                    appointmentController.DeleteAppointment(a.id);

                    DoctorAppointmentsPage.GetInstance().refreshAppointments();

                    MessageBox.Show("Termin je uspjesno otkazan.");


                }
            }
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            if (dgAppointments.SelectedItem != null)
            {
                AppointmentDoctorDTO a = (AppointmentDoctorDTO)dgAppointments.SelectedItem;

                string appointmentID = a.id;

                DoctorAppointmentsPage.GetInstance().mainFrame.Content = new UpdateAppointmentPage(appointmentID);
            }

        }

        private void RemoveAppointmentFromPatient(string appointmentID, Appointment a)
        {
            string patientID = a.patient.userID;
            Patient patient = patientController.GetPatientById(patientID);

            int index = 0;
            foreach (string id in patient.appointmentIDs)
            {
                if (id.Equals(appointmentID))
                {
                    patient.appointmentIDs.RemoveAt(index);
                    patientController.CreateOrUpdate(patient);
                    return;
                }
                index++;
            }
        }

        private void Button_Add_Operation_Click(object sender, RoutedEventArgs e)
        {
            this.mainFrame.Content = new CreateOperationPage();
        }

        private void logAppointmentButton_Click(object sender, RoutedEventArgs e)
        {
            AppointmentDoctorDTO a = (AppointmentDoctorDTO)dgAppointments.SelectedItem;

            string appointmentID = a.id;

            DoctorAppointmentsPage.GetInstance().mainFrame.Content = new LogAnAppointmentPage(appointmentID);
        }

        private void patientFileButton_Click(object sender, RoutedEventArgs e)
        {
            AppointmentDoctorDTO a = (AppointmentDoctorDTO)dgAppointments.SelectedItem;

            string appointmentID = a.id;

            Appointment appointment = appointmentController.GetAppointment(appointmentID);
            Patient p = patientController.GetPatientById(appointment.patient.userID);

            DoctorAppointmentsPage.GetInstance().mainFrame.Content = new PatientFilePage(p.userID, "DoctorAppointmentsPage");
        }

        public void setInstanceToNull()
        {
            instance = null;
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

    }
}
