﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for PatientsPage.xaml
    /// </summary>
    public partial class PatientsPage : Page
    {
        public static PatientsPage instance;
        private PatientController patientController = new PatientController();

        public BindingList<PatientDTO> patientsDTO { get; set; }
        public List<Patient> patients { get; set; }

        public Doctor loggedDoctor { get; set; }

        public Frame mainFrame { get; set; }

        public PatientsPage()
        {
            InitializeComponent();

            patientsDTO = new BindingList<PatientDTO>();

            DataContext = this;
        }

        public static PatientsPage getInstance(Frame mainFrame, Doctor doctor)
        {
            if (instance == null)
            {
                instance = new PatientsPage();
                instance.loggedDoctor = doctor;
                instance.mainFrame = mainFrame;
                instance.refreshPatients();
            }

            instance.refreshPatients();
            return instance;
        }

        public void refreshPatients()
        {
            patients = patientController.GetAllPatients();
            patientsDTO.Clear();

            foreach(Patient patient in patients)
            {
                patientsDTO.Add(new PatientDTO(patient.name, patient.surname, patient.doB.ToShortDateString(), patient.userID));
            }
        }

        private void therapyButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = new DoctorHomePage(loggedDoctor, mainFrame);
        }

        private void patientFileButton_Click(object sender, RoutedEventArgs e)
        {
            PatientDTO patient = (PatientDTO)dgPatients.SelectedItem;

            string patientID = patient.userID;
            MainWindowDoctor.GetInstance().MainFrame.Content = new PatientFilePage(patientID, "PatientsPage");
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchInput = patientSearchTextBox.Text;

            if (searchInput.Equals(""))
            {
                refreshPatients();
                return;
            }
                

            List<Patient> filteredPatients = patientController.SearchPatientsByNameOrSurname(searchInput);
            patientsDTO.Clear();

            foreach(Patient patient in filteredPatients)
            {
                patientsDTO.Add(new PatientDTO(patient.name, patient.surname, patient.doB.ToShortDateString(), patient.userID));
            }
        }
    }
}
