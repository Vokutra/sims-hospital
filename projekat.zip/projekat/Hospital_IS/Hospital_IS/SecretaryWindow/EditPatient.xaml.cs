﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.SecretaryWindow
{
    /// <summary>
    /// Interaction logic for EditPatient.xaml
    /// </summary>
    public partial class EditPatient : Window
    {
        private ObservableCollection<Allergen> allAllergens;
        private ObservableCollection<Patient> patients;
        private Patient selectedPatient = new Patient();
        private Allergen selectedAllergen = new Allergen();
        private PatientController patientController = new PatientController();
        private AllergenController allergenController = new AllergenController();

        public List<Allergen> patientsAllergens { get; set; }

        public static Gender StringToGender(string str)
        {

            return str switch
            {
                "Muski" => Gender.male,
                "Zenski" => Gender.female,
                _ => Gender.female,
            };
        }
        public string GenderToString(Gender gender)
        {

            return gender switch
            {
                Gender.male => "Muski",
                Gender.female => "Zenski",
                _ => "",
            };

        }

        public string BloodTypeToString (BloodType bloodType)
        {
            return bloodType switch
            { 
                BloodType.aPositive => "A+",
                BloodType.aNegative => "A-",
                BloodType.bPositive => "B+",
                BloodType.bNegative => "B-",
                BloodType.aBPositive => "AB+",
                BloodType.aBNegative => "AB-",
                BloodType.oPositive => "0+",
                BloodType.oNegative => "0-",

                _ =>"",
            };
        }
        public static BloodType StringToBloodType(string str)
        {

            return str switch
            {
                "A+" => BloodType.aPositive,
                "A-" => BloodType.aNegative,
                "B+" => BloodType.bPositive,
                "B-" => BloodType.bNegative,
                "AB+" => BloodType.aBPositive,
                "AB-" => BloodType.aBNegative,
                "0+" => BloodType.oPositive,
                "0-" => BloodType.oNegative,
                _ => BloodType.oNegative,
            };
        }

        public EditPatient(Patient patient)
        {
            selectedPatient = PatientFileStorage.Instance.FindById(patient.userID);
            InitializeComponent();
            this.DataContext = this;

            allAllergens = new ObservableCollection<Allergen>(AllergenFileStorage.Instance.GetEntityList());
            allergensListView.ItemsSource = allAllergens;

            txtName.Text = selectedPatient.name;
            txtSurname.Text = selectedPatient.surname;
            txtID.Text = selectedPatient.userID;
            txtPhone.Text = selectedPatient.phoneNum;
            txtEmail.Text = selectedPatient.email;
            txtUsername.Text = selectedPatient.username;
            txtPassword.Text = selectedPatient.password;
            dateField.SelectedDate = selectedPatient.doB;
            cbPatientGender.Text = GenderToString(selectedPatient.gender);
            cbPatientBloodType.Text = BloodTypeToString(selectedPatient.bloodType);


            patientsAllergens = selectedPatient.allergens;

            foreach(Allergen a in allAllergens)
            {
                foreach(Allergen pa in patientsAllergens)
                {
                    if(a.allergenId.Equals(pa.allergenId))
                    {
                        allergensListView.SelectedItems.Add(a);
                    }
                }
            }

        }

        private void btnEditPatient_Click(object sender, RoutedEventArgs e)
        {
            selectedPatient.name = txtName.Text;
            selectedPatient.surname = txtSurname.Text;
            //selectedPatient.userID = txtID.Text;
            selectedPatient.phoneNum = txtNumber.Text;
            selectedPatient.email = txtEmail.Text;
            selectedPatient.username = txtUsername.Text;
            selectedPatient.password = txtPassword.Text;
            selectedPatient.doB = (DateTime)dateField.SelectedDate;
            selectedPatient.gender = StringToGender(cbPatientGender.Text);
            selectedPatient.bloodType = StringToBloodType(cbPatientBloodType.Text);

            selectedPatient.allergens.Clear();
            var selectedItems = allergensListView.SelectedItems;
            foreach (Allergen selectedItem in selectedItems)
            {
                Allergen allergen = (Allergen)selectedItem;
                selectedPatient.allergens.Add(allergen);
            }
            

            patientController.UpdatePatient(selectedPatient);
            //Accounts1 accounts = new Accounts1();
            //accounts.Show();

            this.Close();
        }

        private void btnDeletePatient_Click(object sender, RoutedEventArgs e)
        {
            // Patient SelectedPatient = PatientTable.SelectedItem as Patient;
            selectedPatient = PatientFileStorage.Instance.FindById(selectedPatient.userID);
            patientController.DeletePatient(selectedPatient);
            // patients = new ObservableCollection<Patient>(PatientFileStorage.Instance.GetEntityList());
            // PatientTable.ItemsSource = patients;
            this.Close();
        }

        private void txtPhone_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
