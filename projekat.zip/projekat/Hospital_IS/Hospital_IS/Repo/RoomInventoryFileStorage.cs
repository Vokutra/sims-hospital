﻿using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class RoomInventoryFileStorage : GenericFileStorage<string, RoomInventory, RoomInventoryFileStorage>, IRoomInventoryFileStorage
    {
        protected override string GetKey(RoomInventory entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\roomInventory.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(RoomInventory entity)
        {
            entity.room.serialize = false;
            entity.inventory.serialize = false;
            entity.serialize = true;
        }

        public void CreateRoomInventory(RoomInventory entity)
        {
            Dictionary<string, RoomInventory> inventories = ReadFile();
            string key = GetKey(entity);
            inventories[key] = entity;
            WriteFile(inventories);
        }


        public RoomInventory FindByRoomName(string roomName)
        {
            Dictionary<string, RoomInventory> entities = ReadFile();
            RoomInventory retVal;

            if (!entities.TryGetValue(roomName, out retVal))
            {
                return default;
            }

            return retVal;
        }
    }
}
