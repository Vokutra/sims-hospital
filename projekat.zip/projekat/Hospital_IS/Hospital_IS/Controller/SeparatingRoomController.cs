﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    class SeparatingRoomController
    {
        public ISeparatingRoomService separatingRoomService = new SeparatingRoomService();

        public void AddSeparatingRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomService.AddSeparatingRoom(separatingRoom);
        }


        public List<SeparatingRoom> GetAllSeparatingRoom()
        {
            return separatingRoomService.GetAllSeparatingRoom();
        }



        public void UpdateSeparatingRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomService.UpdateSeparatingRoom(separatingRoom);
        }

        public void DeleteSeparatingRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomService.DeleteSeparatingRoom(separatingRoom);
        }

        public void SepatareRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomService.SeparateRoom(separatingRoom);
        }

        public void SeparateOnDate(object state)
        {
            separatingRoomService.SeparateOnDate(state);
        }
    }
}
