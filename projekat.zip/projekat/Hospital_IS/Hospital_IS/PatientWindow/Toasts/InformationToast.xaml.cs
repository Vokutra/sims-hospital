﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow.Toasts
{
    /// <summary>
    /// Interaction logic for InformationToast.xaml
    /// </summary>
    public partial class InformationToast : Window
    {
        public InformationToast()
        {
            InitializeComponent();
        }

        public void ShowInformationToast(object message)
        {
            App.Current.Dispatcher.Invoke((Action)delegate
            {
                this.message.Content = message;
                this.Owner = MainWindowPatient.getInstance();
                this.Left = this.Owner.Left + (this.Owner.Width - this.ActualWidth) / 2 - 160;
                this.Top = this.Owner.Top + 150;
                this.Show();
                Thread.Sleep(1000);
                this.Hide();
            });
        }
    }
}
