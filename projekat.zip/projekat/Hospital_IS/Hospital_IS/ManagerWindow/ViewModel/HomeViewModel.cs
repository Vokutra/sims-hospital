﻿using Hospital_IS.Commands;
using Hospital_IS.Controller;
using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Threading;

namespace Hospital_IS.ManagerWindow.ViewModel
{
    class HomeViewModel
    {
        public static SeriesCollection SeriesCollection { get; set; }
        public string[] BarLabels { get; set; }
        public Func<double, string> Formatter { get; set; }
        public HospitalSurveyController hospitalSurveyController = new HospitalSurveyController();
        
        
        public HomeViewModel()
        {
            int grade1 = hospitalSurveyController.GetAllHospitalSurveysByGrade(1).Count;
            int grade2 = hospitalSurveyController.GetAllHospitalSurveysByGrade(2).Count;
            int grade3 = hospitalSurveyController.GetAllHospitalSurveysByGrade(3).Count;
            int grade4 = hospitalSurveyController.GetAllHospitalSurveysByGrade(4).Count;
            int grade5 = hospitalSurveyController.GetAllHospitalSurveysByGrade(5).Count;
            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title="Broj ocena",
                    Values = new ChartValues<int> {grade1, grade2, grade3, grade4, grade5}
                }
            };

            BarLabels = new[] { "ocena 1", "ocena 2", "ocena 3", "ocena 4", "ocena 5" };
            Formatter = value => value.ToString("N");
        }

       
    }
}
