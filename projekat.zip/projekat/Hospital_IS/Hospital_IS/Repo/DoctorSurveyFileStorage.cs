﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public class DoctorSurveyFileStorage : GenericFileStorage<string, DoctorSurvey, DoctorSurveyFileStorage>
    {
        protected override string GetKey(DoctorSurvey entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
           return @".\..\..\..\JSONData\doctorSurveys.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(DoctorSurvey entity)
        {
            entity.loggedAppointment.serialize = false;
            entity.patient.serialize = false;
            entity.doctor.serialize = false;
        }
    }
}
