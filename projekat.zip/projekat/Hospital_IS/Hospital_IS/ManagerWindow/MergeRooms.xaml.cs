﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for MergeRoom.xaml
    /// </summary>
    public partial class MergeRooms : Window
    {
        private Room selectedRoom;
        private Room secondRoom;
        private MergingRooms mergingRooms;
        private RoomController roomController = new RoomController();
        private AppointmentController appointmentController = new AppointmentController();
        private MergingRoomsController mergingRoomsController = new MergingRoomsController();
        private List<Room> rooms;
        public List<string> roomNames { get; set; }
        public MergeRooms(Room room)
        {
            selectedRoom = roomController.getRoomById(room.roomName);
            InitializeComponent();
            this.DataContext = this;
            txtRoomName.Content = selectedRoom.roomName;
            txtFloor.Content = FloorToString(selectedRoom.floorNumber);
            txtType.Content = RoomTypeToString(selectedRoom.roomType);
            txtAvailability.Content = AvailabilityToString(selectedRoom.isAvailable);
            cbNewRoomType.Text = RoomTypeToString(selectedRoom.roomType);

            rooms = roomController.GetAllRooms();
            roomNames = roomController.GetAllRoomNames();
            if (roomNames == null)
                roomNames = new List<string>();
            else { 
                foreach (Room roomOne in rooms)
                {
                    if (roomOne.roomName.Equals(selectedRoom.roomName))
                    {
                        roomNames.Remove(roomOne.roomName);
                    }
                    
                }
            }

        }

        private void btnMerge_Click(object sender, RoutedEventArgs e)
        {
            string roomForMerging = txtSecondRoomName.Text;
            DateTime? startDate = dateStartRenovation.SelectedDate;
            DateTime? endDate = dateEndRenovation.SelectedDate;

            secondRoom = roomController.GetByName(roomForMerging);
            selectedRoom.roomType = StringToRoomType(cbNewRoomType.Text);
            //RoomType roomType = StringToRoomType(cbNewRoomType.Text);

            if (selectedRoom.floorNumber == secondRoom.floorNumber)
            {
                if (appointmentController.IsRoomFreeForRenovation(selectedRoom, startDate, endDate))
                {
                    if ((DateTime.Compare(DateTime.Today, (DateTime)endDate) == 0 ) || (DateTime.Compare(DateTime.Today, (DateTime)endDate) > 0))
                    {
                        mergingRooms = new MergingRooms(selectedRoom, secondRoom/*, roomType*/, startDate, endDate);
                        mergingRoomsController.AddMergingRooms(mergingRooms);
                        mergingRoomsController.MergeRooms(mergingRooms);

                        appointmentController.CancelAppointmentIfThereIsNoRoomAfterMerge(mergingRooms);

                        RoomsViewModel.rooms.Remove(secondRoom);
                    }
                }
                else
                    MessageBox.Show("U tom vremenskom intervalu soba je zauzeta!");
                
            }
            else
            {
                MessageBox.Show("Sobe nisu na istom spratu!");
            }
            
           
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public static string FloorToString(int number)
        {
            return number switch
            {
                1 => "Prvi",
                2 => "Drugi",
                3 => "Treci",
                _ => "",
            };
        }

        public string RoomTypeToString(RoomType type)
        {

            return type switch
            {
                RoomType.examinationRoom => "Prijemna ambulanta",
                RoomType.operationRoom => "Operaciona sala",
                RoomType.accommodationRoom => "Stacionar",
                _ => "",
            };

        }

        public string AvailabilityToString(bool dostupna)
        {
            if (dostupna == true)
            {
                return "Dostupna";
            }
            return "Nedostupna";
        }

        public static RoomType StringToRoomType(string str)
        {

            return str switch
            {
                "Prijemna ambulanta" => RoomType.examinationRoom,
                "Operaciona sala" => RoomType.operationRoom,
                "Stacionar" => RoomType.accommodationRoom,
                _ => RoomType.accommodationRoom,
            };
        }

    }
}
