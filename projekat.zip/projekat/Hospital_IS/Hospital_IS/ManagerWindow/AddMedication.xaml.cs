﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for AddMedication.xaml
    /// </summary>
    public partial class AddMedication : Window
    {
        private ObservableCollection<Ingredient> allIngredients;
        public List<string> allMedications { get; set; }
        private IngredientController ingredientController = new IngredientController();
        private MedicationController medicationController = new MedicationController();
        public List<Ingredient> medicationIngredient { get; set; }
        public AddMedication()
        {
            InitializeComponent();
       
            allIngredients = new ObservableCollection<Ingredient>(ingredientController.GetAllIngredients());
            ingredientsListView.ItemsSource = allIngredients;
            txtMedicationStatus.Content = MedicationStatusToString( MedicationStatus.waitingForApproval);

            allMedications = new List<string>(medicationController.GetAllMedicationNames());
            if (allMedications == null)
                allMedications = new List<string>();

            medicationIngredient = new List<Ingredient>();

            DataContext = this;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Int32.TryParse(txtAmount.Text, out int amount);

            Medication medication = new Medication();
            medication.id = txtMedicationID.Text;
            medication.name = txtMedicationName.Text;
            medication.amount = amount;
            medication.status = MedicationStatus.waitingForApproval;
            string alternativeName = cbMedicationAlternative.Text;
            medication.alternative = medicationController.GetMedication(alternativeName);
            medication.doctorsApprovalComment = "";

            var selectedItems = ingredientsListView.SelectedItems;
            foreach (Ingredient selectedItem in selectedItems)
            {
                Ingredient ingredient = (Ingredient)selectedItem;
                medicationIngredient.Add(ingredient);
            }
            medication.ingredients = medicationIngredient;

            foreach (var m in medicationController.GetAllMedications())
            {
                if (medication.id == m.id)
                {
                    MessageBox.Show("Lek sa ovom sifrom vec postoji!");
                    return;
                }
            }

            if (txtMedicationID.Text == "" || txtMedicationName.Text == "" || txtAmount.Text == "" || cbMedicationAlternative.Text == "" )
            {
                MessageBox.Show("Sva polja moraju biti popunjena!");
                return;
            }

            medicationController.CreateOrUpdateMedication(medication);
            MedicationViewModel.medications.Add(medication);

            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public string MedicationStatusToString(MedicationStatus status)
        {

            return status switch
            {
                MedicationStatus.approved => "Odobren",
                MedicationStatus.waitingForApproval => "Na cekanju",
                MedicationStatus.denied => "Odbijen",
                _ => "",
            };

        }
        
    }
}
