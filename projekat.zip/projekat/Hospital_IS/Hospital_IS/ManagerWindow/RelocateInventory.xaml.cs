﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    
    public partial class RelocateInventory : Window
    {
        private Inventory selectedInventory;
        private RoomInventory roomInventory;
        private RoomInventoryController roomInventoryController = new RoomInventoryController();
        private InventoryContoller inventoryContoller = new InventoryContoller();
        private RoomController roomController = new RoomController();
        public List<string> rooms { get; set; }
        private List<RoomInventory> allRelocations = new List<RoomInventory>();
        private RoomInventory inventoryRoomForUpdate;

        public RelocateInventory(Inventory inventory)
        {
            selectedInventory = InventoryFileStorage.Instance.FindById(inventory.inventoryID);
            InitializeComponent();

            rooms = roomController.GetAllRoomNames();
            if (rooms == null)
                rooms = new List<string>();

            this.DataContext = this;

            txtInventoryID.Text = selectedInventory.inventoryID;
            txtInventoryName.Text = selectedInventory.name;
            
        }

        private void btnRelocate_Click(object sender, RoutedEventArgs e)
        {
            //roomInventory = new RoomInventoryDTO();

            if (Int32.Parse(txtAmount.Text) <= selectedInventory.amount)
            {
                selectedInventory.amount = selectedInventory.amount - Int32.Parse(txtAmount.Text);

            }
            else
            {
                MessageBox.Show("Izabrali ste vecu kolicinu nego sto postoji.");
            }

            allRelocations = roomInventoryController.GetAllRoomInventories();
            bool inventoryExist = false;
            
            foreach (RoomInventory relocation in allRelocations)
            {
                if (relocation.inventory.inventoryID.Equals(txtInventoryID.Text ) && relocation.room.roomName.Equals(cbRoom.Text))
                {
                    inventoryExist = true;
                    inventoryRoomForUpdate = relocation;
                }
            }

            if (inventoryExist == true)
            {
                inventoryRoomForUpdate.amount += Int32.Parse(txtAmount.Text);
                roomInventoryController.UpdateRoomInventory(inventoryRoomForUpdate);
            }

            else
            {
                //roomInventory.amount = Int32.Parse(txtAmount.Text);
                //roomInventory.room = cbRoom.Text;

                //roomInventory.inventoryID = txtInventoryID.Text;
                //roomInventory.item = txtInventoryName.Text;
                //roomInventory.date = datePicker.SelectedDate;

                roomInventory = new RoomInventory(roomController.GetByName(cbRoom.Text), new Inventory(txtInventoryName.Text, txtInventoryID.Text), Int32.Parse(txtAmount.Text), datePicker.SelectedDate);
                roomInventoryController.AddRoomInventory(roomInventory);
            }

            inventoryContoller.UpdateInventory(selectedInventory);

            int i;
            for (i = 0; i < InventoryViewModel.inventories.Count; i++)
            {
                if (InventoryViewModel.inventories[i].inventoryID.Equals(selectedInventory.inventoryID))
                {
                    InventoryViewModel.inventories.RemoveAt(i);
                    break;
                }

            }

            selectedInventory.inventoryID = txtInventoryID.Text;
            selectedInventory.name = txtInventoryName.Text;


            InventoryViewModel.inventories.Insert(i, selectedInventory);

            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
