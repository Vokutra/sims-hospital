﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for PatientFilePage.xaml
    /// </summary>
    public partial class PatientFilePage : Page
    {
        private PatientController patientController = new PatientController();
        private DoctorController doctorController = new DoctorController();
        public Patient patient { get; set; }
        public Doctor doctor { get; set; }

        public string previousPage { get; set; }
        public PatientFilePage(string patientID, string previousPage)
        {
            InitializeComponent();

            this.patient = patientController.GetPatientById(patientID);
            this.doctor = doctorController.FindDoctorById(patient.doctor.userID);
            this.previousPage = previousPage;

            initializePatientInfo();
        }

        private void initializePatientInfo()
        {
            surnameTextBlock.Text = "Prezime: " + patient.surname;
            nameTextBlock.Text = "Ime: " + patient.name;
            DoBTextBlock.Text = "Datum rodjenja: " + patient.doB.ToShortDateString();
            DoctorTextBlock.Text = "Doktor: " + doctor.name + " " + doctor.surname;
            phoneTextBlock.Text = "Telefon: " + patient.phoneNum;
            emailTextBlock.Text = "Email: " + patient.email;
        }

        private void historyButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = new PatientHistoryPage(patient);
        }

        private void therapyButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = new TherapyIssuePage(patient);
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            if (previousPage.Equals("PatientsPage"))
                MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
            else if (previousPage.Equals("DoctorAppointmentsPage"))
                MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void prescriptionButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = new PrescriptionIssuePage(patient);
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }
    }
}
