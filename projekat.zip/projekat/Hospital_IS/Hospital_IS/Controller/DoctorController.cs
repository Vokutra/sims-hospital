using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Controller
{
    public class DoctorController
    {

        private DoctorService doctorService = new DoctorService();


        public List<Doctor> GetAllDoctors()
        {
            return doctorService.GetAllDoctors();
        }

        public Doctor FindDoctorById(string id)
        {
            return doctorService.FindDoctorById(id);
        }

        public Model.Doctor GetDoctor(String username)
        {
            return doctorService.GetDoctor(username);
        }

        public List<DoctorsShift> GetAllShiftsByDoctor(Doctor doctor)
        {
            return doctorService.GetAllShiftsByDoctor(doctor);
        }

        public TimeSpan GetDoctorsStartWork(Doctor doctor, DateTime date)
        {
            return doctorService.GetDoctorsStartWork(doctor, date);
        }

        public TimeSpan GetDoctorsEndWork(Doctor doctor, DateTime date)
        {
            return doctorService.GetDoctorsEndWork(doctor, date);
        }
        public void UpdateDoctor(String username)
        {
            throw new NotImplementedException();
        }

        public void UpdateDoctor(Doctor doctor)
        {
            doctorService.UpdateDoctor(doctor);
        }

        public Model.Doctor AddDoctor(Model.Doctor doctor)
        {
            throw new NotImplementedException();
        }

        public Boolean DeleteDoctor(Model.Doctor doctor)
        {
            throw new NotImplementedException();
        }

        public void ModifyAverageGrade(Doctor doctor)
        {
            doctorService.ModifyAverageGrade(doctor);
        }

        public Boolean IsOnVacation(Model.Doctor doctor)
        {
            throw new NotImplementedException();
        }

        public List<String> GetAllLicenceNumbers()
        {
            throw new NotImplementedException();
        }

        public DoctorsShift GetShiftForSpecificDate(Doctor doctor, DateTime day)
        {
            return doctorService.GetShiftForSpecificDate(doctor, day);
        }

    }
}