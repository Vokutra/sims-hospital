﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class SeparatingRoomFileStorage : GenericFileStorage<string, SeparatingRoom, SeparatingRoomFileStorage>, ISeparatingRoomFileStorage
    {
        protected override string GetKey(SeparatingRoom entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\separatingRoom.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(SeparatingRoom entity)
        {
            entity.roomOne.serialize = false;
            entity.roomTwo.serialize = false;
            entity.serialize = true;
        }
    }
}
