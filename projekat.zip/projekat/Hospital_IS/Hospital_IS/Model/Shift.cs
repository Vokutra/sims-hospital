﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Model
{
    public class Shift
    {
        public TimeSpan startTime { get; set; }
        public TimeSpan endTime { get; set; }

        public Shift(TimeSpan startTime, TimeSpan endTime)
        {
            this.startTime = startTime;
            this.endTime = endTime;
        }
    }
}
