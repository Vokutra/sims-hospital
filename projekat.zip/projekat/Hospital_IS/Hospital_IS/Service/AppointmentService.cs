﻿
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.PatientWindow;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Service
{
    public class AppointmentService
    {
        private AppointmentFileStorage appointmentFileStorage = new AppointmentFileStorage();
        private DoctorFileStorage doctorFileStorage = new DoctorFileStorage();
        private DoctorService doctorService = new DoctorService();
        private PatientFileStorage patientFileStorage = new PatientFileStorage();
        private IRoomFileStorage roomFileStorage = new RoomFileStorage();

        public List<AppointmentDoctorDTO> dtos = new List<AppointmentDoctorDTO>();


        public List<Appointment> GetAllAppointments()
        {
            return appointmentFileStorage.GetEntityList();
        }

        public Appointment GetAppointment(string appointmentID)
        {
            return appointmentFileStorage.FindById(appointmentID);
        }

        public List<Appointment> GetAppointmentsThatWillBeInProgress(DateTime time)
        {
            List<Appointment> appointments = new List<Appointment>();
            foreach (Appointment a in GetAllAppointments())
            {
                if (DateTime.Compare(a.startTime, time) != 1 && DateTime.Compare(time, a.startTime.AddMinutes(a.durationInMinutes)) == -1)
                {
                    appointments.Add(a);
                }
            }
            return appointments;
        }

        public void UpdateAppointment()
        {
            throw new NotImplementedException();
        }


        public void CreateAppointment(Appointment appointment)
        {
            appointmentFileStorage.CreateAppointment(appointment);
        }



        public void DeleteAppointment(string id)
        {
            appointmentFileStorage.DeleteById(id);
        }

        public void DeleteAppointment(Appointment appointment)
        {
            appointmentFileStorage.DeleteByReference(appointment);
        }

        public List<Room> GetAllExaminationRooms()
        {
            List<Room> examinationRooms = new List<Room>();
            foreach (Room room in roomFileStorage.GetEntityList())
            {
                if (room.roomType == RoomType.examinationRoom)
                    examinationRooms.Add(room);
            }

            return examinationRooms;
        }

        public Room GetRoomForAppointment(DateTime startTime)
        {
            List<Appointment> appointmentsInProgress = GetAppointmentsThatWillBeInProgress(startTime);
            List<Room> rooms = roomFileStorage.GetEntityList();
            Room availableRoom = new Room(default, default, default, "Bićete obavešteni!");
            int flag;
            foreach (Room room in GetAllExaminationRooms())
            {
                flag = 0;
                foreach (Appointment a in appointmentsInProgress)
                {
                    if (a.room.roomName.Equals(room.roomName))
                    {
                        flag++;
                        break;
                    }
                }
                if (flag == 0)
                    availableRoom = room;
            }

            return availableRoom;
            
        }

        public void CancelAppointmentIfThereIsNoRoomAfterMerge(MergingRooms mergingRooms)
        {
            foreach (var app in GetAllAppointments())
            {
                if (mergingRooms.endDateRenovation <= app.startTime && app.room.roomName == mergingRooms.roomTwo.roomName)
                {
                    DeleteAppointment(app);
                }
            }
        }

        public List<Appointment> GetAllDoctorsAppointments(Doctor doctor)
        {
            List<Appointment> doctorAppointments = new List<Appointment>();
            foreach (Appointment appointment in GetAllAppointments())
            {
                if (doctor.userID.Equals(appointment.doctor.userID))
                    doctorAppointments.Add(appointment);
            }

            return doctorAppointments;
        }

        public List<Appointment> GetAppointmentsAtSpecificDoctor(Doctor doctor, Patient patient, DateTime startDate, DateTime endDate, TimeSpan startTime, TimeSpan endTime)
        {
            List<Appointment> appointments = new List<Appointment>();
            List<Appointment> doctorAppointments = GetAllDoctorsAppointments(doctor);
            TimeSpan st;
            int res;
            int flag = DateTime.Compare(startDate, endDate);
            while (flag != 0)
            {
                st = startTime;

                if (TimeSpan.Compare(st, doctorService.GetDoctorsEndWork(doctor, startDate)) != -1)
                {
                    startDate = startDate.AddDays(1);
                    flag = DateTime.Compare(startDate, endDate);
                    continue;
                }
                    

                if (TimeSpan.Compare(endTime, doctorService.GetDoctorsStartWork(doctor, startDate)) != 1)
                {
                    startDate = startDate.AddDays(1);
                    flag = DateTime.Compare(startDate, endDate);
                    continue;
                }

                res = TimeSpan.Compare(doctorService.GetDoctorsStartWork(doctor, startDate), st);
                if (res == 1)
                {
                    st = doctorService.GetDoctorsStartWork(doctor, startDate);
                }

                res = TimeSpan.Compare(doctorService.GetDoctorsEndWork(doctor, startDate), endTime);
                if (res == -1)
                {
                    endTime = doctorService.GetDoctorsEndWork(doctor, startDate);
                }

                res = TimeSpan.Compare(st, endTime);
                while (res == -1)
                {
                    if (DateTime.Compare(DateTime.Now, startDate.Add(st)) == -1 && IsDoctorFreeInNextTenMinutes(startDate.Add(st), doctorAppointments))
                    {
                        Room room = GetRoomForAppointment(startDate.Add(st));
                        if (room == null)
                            appointments.Add(new Appointment(startDate.Add(st), 10, patient, doctor, AppointmentType.Examination));
                        else
                            appointments.Add(new Appointment(startDate.Add(st), 10, patient, doctor, room, AppointmentType.Examination));
                    }

                    st = st.Add(new TimeSpan(0, 10, 0));
                    res = TimeSpan.Compare(st, endTime);
                }

                startDate = startDate.AddDays(1);
                flag = DateTime.Compare(startDate, endDate);
            }

            return appointments;
        }

        public List<Appointment> GetAppointmentsAtSpecificTime(Doctor doctor, Patient patient, DateTime startDate, DateTime endDate, TimeSpan startTime, TimeSpan endTime)
        {
            List<Appointment> appointments = new List<Appointment>();
            
            List<Doctor> doctors = doctorFileStorage.GetEntityList();
            foreach (Doctor d in doctors)
            {
                if (!d.userID.Equals(doctor.userID))
                {
                    appointments.AddRange(GetAppointmentsAtSpecificDoctor(d, patient, startDate, endDate, startTime, endTime));
                }
            }

            return appointments;
        }


        public List<Appointment> GetAppointmentsByDoctor(Doctor doctor)
        {
            List<Appointment> appointments = new List<Appointment>();

            foreach(Appointment a in appointmentFileStorage.GetEntityList())
            {
                if(a.doctor.userID.Equals(doctor.userID))
                {
                    appointments.Add(a);
                }
            }

            return appointments;
        }

        public List<Appointment> getAppointmentsByDoctorPatientRoomForDay(Doctor doctor, Patient patient, Room room, DateTime day)
        {
            List<Appointment> appointments = new List<Appointment>();

            foreach (Appointment a in appointmentFileStorage.GetEntityList())
            {
                if ((a.doctor.userID.Equals(doctor.userID) || a.patient.userID.Equals(patient.userID) || a.room.roomName.Equals(room.roomName)) && a.startTime.ToShortDateString().Equals(day.ToShortDateString()))
                {
                    appointments.Add(a);
                }
            }
            return appointments;
        }

        private bool IsDoctorFreeInNextTenMinutes(DateTime startTime, List<Appointment> doctorsAppointments)
        {
            bool isFree = true;
            foreach (Appointment appointment in doctorsAppointments)
            {
                if (DateTime.Compare(appointment.startTime, startTime) != 1 && DateTime.Compare(startTime, appointment.startTime.AddMinutes(appointment.durationInMinutes)) == -1)
                    isFree = false;    
            }
            
            return isFree;
        }
            
        public void CreateOrUpdate(Appointment a)
        {
            appointmentFileStorage.CreateOrUpdate(a);
        }

        public Appointment getNearestNextAppointment(DateTime selectedDate, Doctor doctor, Patient patient, Room room)
        {
            List<Appointment> allAppointments = this.getAppointmentsByDoctorPatientRoomForDay(doctor, patient, room, selectedDate);
            TimeSpan minDifference = new TimeSpan(100000,0,0);
            Appointment returnValue = new Appointment();
            foreach (Appointment a in allAppointments)
            {
                if(a.startTime - selectedDate > new TimeSpan(0, 0, 0) && a.startTime - selectedDate < minDifference)
                {
                    minDifference = a.startTime - selectedDate;
                    returnValue = a;
                }

            }
            return returnValue;
        }

        public bool existsAppointmentAfter(DateTime selectedDate, Doctor doctor, Patient patient, Room room)
        {
            List<Appointment> allAppointments = this.getAppointmentsByDoctorPatientRoomForDay(doctor, patient, room, selectedDate);
            bool flag = false;
            foreach(Appointment a in allAppointments)
            {
                if(a.startTime > selectedDate)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }
        public bool IsRoomFreeForRenovation(Room room, DateTime? starDate, DateTime? endDate)
        {
            foreach (Appointment appointment in GetAllAppointments())
            {
                if (appointment.room.roomName.Equals(room.roomName) && appointment.startTime.Date >= starDate && appointment.startTime.Date <= endDate)
                {
                    return false;
                }
            }

            return true;
        }

        public void RemovePastAppointments(object state)
        {
            foreach (string id in LoginPatient.patient.appointmentIDs)
            {
                Appointment appointment = GetAppointment(id);
                if (HasAppointmentPassed(appointment))
                {
                    for (int i = 0; i < ScheduledAppointments.scheduledAppointmentsDTO.Count; i++)
                    {
                        if (ScheduledAppointments.scheduledAppointmentsDTO[i].id.Equals(id))
                        {
                            App.Current.Dispatcher.Invoke((Action)delegate
                            {
                                ScheduledAppointments.scheduledAppointmentsDTO.RemoveAt(i);
                            });
                        }
                    }
                }
                    
            }
        }


        public void RemovePastCanceledAppointments(object state)
        {
            for (int i = 0; i < LoginPatient.patient.datesOfCanceledAppointments.Count; i++)
            {
                if (DateTime.Compare(LoginPatient.patient.datesOfCanceledAppointments[i], DateTime.Now) == -1)
                {
                    App.Current.Dispatcher.Invoke((Action)delegate
                    {
                        LoginPatient.patient.datesOfCanceledAppointments.RemoveAt(i);
                    });
                }
            }
            patientFileStorage.CreateOrUpdate(LoginPatient.patient);
            
        }

        public bool CheckIfPatientHasExaminationAppointment(Patient patient)
        {
            bool doesHave = false;
            foreach (string id in patient.appointmentIDs)
            {
                Appointment appointment = GetAppointment(id);
                if (appointment.appointmentType == AppointmentType.Examination && !HasAppointmentPassed(appointment))
                {
                    doesHave = true;
                }
            }
            return doesHave;
        }

        public bool HasAppointmentPassed(Appointment appointment)
        {
            return DateTime.Compare(appointment.startTime.AddMinutes(appointment.durationInMinutes), DateTime.Now) == -1;
        }

    }
}