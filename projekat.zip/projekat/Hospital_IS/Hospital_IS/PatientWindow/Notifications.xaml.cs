﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for Notifications.xaml
    /// </summary>
    public partial class Notifications : Page
    {
        private NotificationController notificationController = new NotificationController();
        public static BindingList<NotificationDTO> notificationsDTO { get; set; }
        public Notifications()
        {
            InitializeComponent();
            notificationsDTO = new BindingList<NotificationDTO>();

            DataContext = this;
        }

        private void dgNotifications_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            NotificationDTO notificationDTO = (NotificationDTO)dgNotifications.SelectedItem;
            Notification notification = notificationController.FindById(notificationDTO.id);
            notification.isRead = true;
            notificationController.CreateNotification(notification);
            NotificationPage notificationPage = new NotificationPage(notification.title, notification.message);
            MainWindowPatient.getInstance().SetContent(notificationPage);
        }
    }
}
