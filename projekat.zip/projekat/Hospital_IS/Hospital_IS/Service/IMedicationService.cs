﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface IMedicationService
    {
        public List<string> GetAllMedicationNames();
       
        public List<Medication> GetAllMedications();
       
        public List<Medication> GetAllWaitingMedications();
     
        public Medication GetMedication(String medicationName);
        
        public Medication GetMedicationById(string id);
       
        public void CreateOrUpdateMedication(Medication medication);
        
        public void DeleteMedication(Medication medication);
        
    }
}
