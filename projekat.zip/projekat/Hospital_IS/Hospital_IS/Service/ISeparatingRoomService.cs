﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface ISeparatingRoomService
    {
        public void AddSeparatingRoom(SeparatingRoom separatingRoom);

        public List<SeparatingRoom> GetAllSeparatingRoom();

        public void UpdateSeparatingRoom(SeparatingRoom separatingRoom);

        public void DeleteSeparatingRoom(SeparatingRoom separatingRoom);

        public void SeparateRoom(SeparatingRoom separatingRoom);
        public void SeparateOnDate(object state);
    }

}
