﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public class AllergenFileStorage : GenericFileStorage<string, Allergen, AllergenFileStorage>
    {
        protected override string GetKey(Allergen entity)
        {
            return entity.allergenId;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\JSONData\allergens.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Allergen entity)
        {
            entity.serialize = true;
            // entity.doctor.serialize = false;
        }

        public Allergen ReadUser(String allergenName)
        {
            foreach (Allergen a in this.GetEntityList())
            {
                if (a.allergenName.Equals(allergenName))
                    return a;
            }

            return null;
        }
    }
   
}
