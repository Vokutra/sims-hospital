﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for RoomInventoryWindow.xaml
    /// </summary>
    public partial class RoomInventoryWindow : Window
    {
        private RoomInventoryController roomInventoryController = new RoomInventoryController();
        private InventoryContoller inventoryContoller = new InventoryContoller();
        // public static ObservableCollection<RoomInventoryDTO> inventories { get; set; }
        private EditRoom edit;
        private Room selectedRoom;
        private static Timer timer;
        public static BindingList<RoomInventoryDTO> currentInventories { get; set; }

        public RoomInventoryWindow(Room room)
        {
            selectedRoom = room;
            timer = new Timer(new TimerCallback(roomInventoryController.RelocateOnDate), null, 1000, 60000);
            currentInventories = new BindingList<RoomInventoryDTO>();
            foreach (RoomInventory r in roomInventoryController.GetInventoriesByRoom(room))
            {
                if (DateTime.Compare((DateTime)r.date, DateTime.Today) == -1 || DateTime.Compare(DateTime.Today, (DateTime)r.date) == 0)
                {
                    Inventory inventory = inventoryContoller.GetInventoryById(r.inventory.inventoryID);
                    currentInventories.Add(new RoomInventoryDTO(r.room.roomName, inventory.name, inventory.inventoryID, r.amount, r.inventory.inventoryType, r.date, r.id));
                }
            }
           
            InitializeComponent();
            DataContext = this;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnRelocate_Click(object sender, RoutedEventArgs e)
        {
            RoomInventoryDTO SelectedInventory = roomInventoryTable.SelectedItem as RoomInventoryDTO;

            if (SelectedInventory == null)
            {
                MessageBox.Show("Izabrati inventar.");
                return;
            }


            RelocateRoomInventory relocateRoomInventory = new RelocateRoomInventory(SelectedInventory);
            relocateRoomInventory.Show();
        }
    }
}
