﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    class NotificationController
    {
        private NotificationService notificationService = new NotificationService();
        public void CreateNotification(Notification notification)
        {
            notificationService.CreateNotification(notification);
        }

        public List<Notification> GetNotificationsForUser(string id)
        {
            return notificationService.GetNotificationsForUser(id);
        }

        public Notification FindById(string id)
        {
            return notificationService.FindById(id);
        }

        public void NotifyPatientAboutTherapies(object state)
        {
            notificationService.NotifyPatientAboutTherapies(state);
        }

        public bool AreAllNotificationsRead()
        {
            return notificationService.AreAllNotificationsRead();
        }
    }
}
