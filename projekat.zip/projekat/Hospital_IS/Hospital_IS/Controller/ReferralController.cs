﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class ReferralController
    {
        private ReferralService referralService = new ReferralService();

        public void CreateOrUpdateReferral(Referral referral)
        {
            referralService.CreateOrUpdateReferral(referral);
        }

    }
}
