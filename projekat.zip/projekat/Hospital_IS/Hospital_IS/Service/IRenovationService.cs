﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface IRenovationService
    {
        public void AddRenovation(Renovation renovation);

        public List<Renovation> GetAllRenovations();

        public void UpdateRenovation(Renovation renovation);

        public void DeleteRenovation(Renovation renovation);
        public void RenovateOnDate(object state);
    }
}
