﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow.View
{
    /// <summary>
    /// Interaction logic for InventoryView.xaml
    /// </summary>
    public partial class InventoryView : Page
    {
        public static ObservableCollection<Inventory> inventories { get; set; }
        private InventoryContoller inventoryController = new InventoryContoller();
        private string type;

        public InventoryView()
        {
            InitializeComponent();
            DataContext = new InventoryViewModel();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            inventories.Clear();

            if (txtSearch.Text.Equals(""))
            {
                foreach (Inventory equipment in inventoryController.GetEntityList())
                {
                    inventories.Add(equipment);
                }
            }
            else
            {
                foreach (Inventory equipment in inventoryController.GetEntityList())
                {
                    if (equipment.name.ToLower().Contains(txtSearch.Text.ToLower()) || equipment.amount.ToString().ToLower().Contains(txtSearch.Text.ToLower()) || equipment.inventoryID.ToLower().Contains(txtSearch.Text.ToLower()) || equipment.InventoryTypeToString.Contains(txtSearch.Text))
                    {
                        inventories.Add(equipment);
                    }
                }
            }

        }

        private void cbInventoryType_DropDownClosed(object sender, EventArgs e)
        {
            type = cbInventoryType.Text;
            if (type.Equals("Potrosna"))
            {
                inventories = new ObservableCollection<Inventory>(inventoryController.GetInventoriesByType(InventoryType.dynamical));
            }
            else if (type.Equals("Nepotrosna"))
            {
                inventories = new ObservableCollection<Inventory>(inventoryController.GetInventoriesByType(InventoryType.statical));
            }
            else
            {
                inventories = new ObservableCollection<Inventory>(InventoryFileStorage.Instance.GetEntityList());
            }

            inventoryTable.ItemsSource = inventories;
        }
    }
}
