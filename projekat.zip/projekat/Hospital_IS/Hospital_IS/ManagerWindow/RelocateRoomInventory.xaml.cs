﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    
    public partial class RelocateRoomInventory : Window
    {
        private RoomInventory selectedInventory;
        private RoomInventoryDTO selectedInventoryDTO;
        private RoomInventory roomInventory;
        private RoomInventoryController roomInventoryController1 = new RoomInventoryController();
        private RoomInventoryController roomInventoryController2  = new RoomInventoryController();
        private RoomController roomController = new RoomController();
        public List<string> rooms { get; set; }
        public static List<RoomInventory> allRelocations = new List<RoomInventory>();
        private RoomInventory inventoryRoomForUpdate;


        public RelocateRoomInventory(RoomInventoryDTO inventory)
        {
            selectedInventoryDTO = inventory;
            selectedInventory = RoomInventoryFileStorage.Instance.FindById(inventory.id);
            InitializeComponent();

            rooms = roomController.GetAllRoomNames();
            if (rooms == null)
                rooms = new List<string>();

            this.DataContext = this;

            txtInventoryID.Text = selectedInventory.inventory.inventoryID;
            txtInventoryName.Text = selectedInventory.inventory.name;

        }

        private void btnRelocate_Click(object sender, RoutedEventArgs e)
        {
           // roomInventory = new RoomInventory();

            if (Int32.Parse(txtAmount.Text) <= selectedInventory.amount)
            {
                selectedInventory.amount = selectedInventory.amount - Int32.Parse(txtAmount.Text);
            }
            else 
            {
                MessageBox.Show("Izabrali ste vecu kolicinu nego sto postoji.");
            }
            

            allRelocations = roomInventoryController1.GetAllRoomInventories();
            bool inventoryRoomExist = false;

            foreach (RoomInventory relocation in allRelocations)
            {
                if (relocation.inventory.inventoryID.Equals(txtInventoryID.Text) && relocation.room.roomName.Equals(cbRoom.Text))
                {
                    inventoryRoomExist = true;
                    inventoryRoomForUpdate = relocation;
                }
            }

            if (inventoryRoomExist == true)
            {
                inventoryRoomForUpdate.amount += Int32.Parse(txtAmount.Text);
                roomInventoryController1.UpdateRoomInventory(inventoryRoomForUpdate);
            }

            else
            {
                //roomInventory.amount = Int32.Parse(txtAmount.Text);
                //roomInventory.room.roomName = cbRoom.Text;

                //roomInventory.inventory.inventoryID = txtInventoryID.Text;
                //roomInventory.inventory.name = txtInventoryName.Text;
                //roomInventory.date = datePicker.SelectedDate;

                roomInventory = new RoomInventory(roomController.GetByName(cbRoom.Text), new Inventory(txtInventoryName.Text, txtInventoryID.Text), Int32.Parse(txtAmount.Text), datePicker.SelectedDate);
                roomInventoryController1.AddRoomInventory(roomInventory);
                
                
            }

            if (selectedInventory.amount == 0)
            {
                roomInventoryController2.DeleteRoomInventory(selectedInventory);

                int i;
                for (i = 0; i < RoomInventoryWindow.currentInventories.Count; i++)
                {
                    if (RoomInventoryWindow.currentInventories[i].inventoryID.Equals(selectedInventoryDTO.inventoryID))
                    {
                        RoomInventoryWindow.currentInventories.RemoveAt(i);
                        break;
                    }

                }
            }
            else 
            {
                roomInventoryController2.UpdateRoomInventory(selectedInventory);

                int i;
                for (i = 0; i < RoomInventoryWindow.currentInventories.Count; i++)
                {
                    if (RoomInventoryWindow.currentInventories[i].inventoryID.Equals(selectedInventoryDTO.inventoryID))
                    {
                        RoomInventoryWindow.currentInventories.RemoveAt(i);
                        break;
                    }

                }

                selectedInventoryDTO.inventoryID= txtInventoryID.Text;
                selectedInventoryDTO.item = txtInventoryName.Text;
                selectedInventoryDTO.amount = selectedInventory.amount;

                RoomInventoryPage.currentInventories.Insert(i, selectedInventoryDTO);
            }

            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
