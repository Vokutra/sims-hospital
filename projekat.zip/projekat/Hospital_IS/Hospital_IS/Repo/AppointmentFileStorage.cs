﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Repo
{
    class AppointmentFileStorage : GenericFileStorage<string, Appointment, AppointmentFileStorage>
    {
        protected override string GetKey(Appointment entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\appointments.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Appointment entity)
        {
            
            entity.patient.serialize = false;
            entity.doctor.serialize = false;
            entity.room.serialize = false;
        }

        public void CreateAppointment(Appointment entity)
        {
            Dictionary<string, Appointment> appointments = ReadFile();
            ShouldSerialize(entity);
            string key = GetKey(entity);
            appointments[key] = entity;
            WriteFile(appointments);
        }
    }
}
