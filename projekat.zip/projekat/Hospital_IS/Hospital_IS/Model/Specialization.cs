using System;

namespace Hospital_IS.Model
{
   public class Specialization
   {
      public string SpecializationName { get; set; }
      public string Id { get; set; }
      public bool Serialize { get; set; }

        public Specialization(string specializationName)
        {
            this.SpecializationName = specializationName;
            this.Id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }
    }
}