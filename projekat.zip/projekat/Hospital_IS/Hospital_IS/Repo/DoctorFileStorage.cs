using Hospital_IS.Model;
using System;

namespace Hospital_IS.Repo
{
    public class DoctorFileStorage : GenericFileStorage<string, Doctor, DoctorFileStorage>
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        protected override string GetKey(Doctor entity)
        {
            return entity.userID;
        }

        protected override string GetPath()
        {
           return  @".\..\..\..\jsondata\doctors.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }


        protected override void ShouldSerialize(Doctor entity)
        {
            entity.serialize = true;
        }

        public Doctor ReadUser(String username)
        {
            foreach (Doctor d in this.GetEntityList())
            {
                if (d.username.Equals(username))
                    return d;
            }

            return null;
        }

        //public Doctor FindDoctorById(string id)
        //{
        //    foreach (Doctor d in this.GetEntityList())
        //    {
        //        if (d.userID.Equals(id))
        //            return d;
        //    }

        //    return null;
        //}


    }
}