﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class MedicationController
    {
        private IMedicationService medicationService = new MedicationService();
        public List<string> GetAllMedicationNames()
        {
            return medicationService.GetAllMedicationNames();
        }

        public List<Medication> GetAllMedications()
        {
            return medicationService.GetAllMedications();
        }
        public List<Medication> GetAllWaitingMedications()
        {
            return medicationService.GetAllWaitingMedications();
        }

        public Medication GetMedication(String medicationName)
        {
            return medicationService.GetMedication(medicationName);
        }

        public Medication GetMedicationById(string id)
        {
            return medicationService.GetMedicationById(id);
        }

        public void CreateOrUpdateMedication(Medication medication)
        {
            medicationService.CreateOrUpdateMedication(medication);
        }

        public void DeleteMedication(Medication medication)
        {
            medicationService.DeleteMedication(medication);
        }
    }
}
