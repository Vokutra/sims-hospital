﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class VacationRequestFileStorage : GenericFileStorage<string, VacationRequest, VacationRequestFileStorage>
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        protected override string GetKey(VacationRequest entity)
        {
            return entity.Id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\vacationRequests.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(VacationRequest entity)
        {
            entity.Doctor.serialize = false;
        }
    }
}
