using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Doctor : UserAccount
    {
        [DataMember]
        public string licenceNumber { get; set; }
        [DataMember]
        public double averageGrade { get; set; }
        [DataMember]
        public Specialization specialization { get; set; }


        [JsonConstructor]
        public Doctor(string name, string lastname, string username, string password, string userID)
        {
            this.name = name;
            this.surname = lastname;
            this.username = username;
            this.password = password;
            this.userID = userID;
            this.averageGrade = 0.0;
        }


        public override string ToString()
        {
            return this.name + " " + this.surname;
        }

        [JsonIgnore]
        public string SpecializationForDTO
        {
            get
            {
                return specialization.SpecializationName;
            }
        }

        public bool ShouldSerializelicenceNumber()
        {
            return serialize;
        }

        public bool ShouldSerializespecialization()
        {
            return serialize;
        }

        public bool ShouldSerializeaverageGrade()
        {
            return serialize;
        }

        //public bool ShouldSerializeusername()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializepassword()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializename()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializesurname()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializedoB()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializephoneNum()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializeemail()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializeisGuest()
        //{
        //    return serialize;
        //}

        //public bool ShouldSerializeaddress()
        //{
        //    return serialize;
        //}

    }
}