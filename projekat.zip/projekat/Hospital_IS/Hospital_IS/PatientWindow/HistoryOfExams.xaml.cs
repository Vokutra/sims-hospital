﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for AppointmentsHistory.xaml
    /// </summary>
    public partial class HistoryOfExams : Page
    {
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();
        private DoctorController doctorController = new DoctorController();
        public static BindingList<AppointmentDTO> pastExams { get; set; }
        public HistoryOfExams()
        {
            InitializeComponent();
            pastExams = new BindingList<AppointmentDTO>();
            DataContext = this;
        }

        private void btnReport_Click(object sender, RoutedEventArgs e)
        {
            AppointmentDTO appointmentDTO = (AppointmentDTO)dgPastExams.SelectedItem;
            LoggedAppointment loggedAppointment = loggedAppointmentController.GetById(appointmentDTO.id);
            MainWindowPatient.getInstance().SetContent(new ExamReport(loggedAppointment.description, doctorController.FindDoctorById(loggedAppointment.doctor.userID), loggedAppointment));
        }
    }
}
