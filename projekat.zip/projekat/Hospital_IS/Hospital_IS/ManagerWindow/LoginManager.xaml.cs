﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for LoginManager.xaml
    /// </summary>
    public partial class LoginManager : Window
    {
        //private RoomInventoryController roomInventoryController = new RoomInventoryController();
        //private static Timer timer;
        private IngredientFileStorage ingredientFileStorage = new IngredientFileStorage();
        private IMedicationFileStorage medicationFileStorage = new MedicationFileStorage();
        
        public LoginManager()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtBoxUsername.Text.Trim();
            string password = txtBoxPassword.Password.Trim();

            //Manager m = new Manager("Katarina", "Artukov", "menadzer", "m1", "1");

            //Dictionary<string, Manager> managers = new Dictionary<string, Manager>();

            //managers.Add(m.userID, m);


            //string filename = @".\..\..\..\jsondata\manager.json";


            //string json = JsonConvert.SerializeObject(managers, Formatting.Indented);

            //File.WriteAllText(@".\..\..\..\jsondata\manager.json", json);

            

            //Ingredient i1 = ingredientFileStorage.GetIngredientByName("celuloza mikrokristalna");
            //Ingredient i2 = ingredientFileStorage.GetIngredientByName("povidon K-30");
            //Ingredient i3 = ingredientFileStorage.GetIngredientByName("jod");

            //List<Ingredient> m1i = new List<Ingredient>();
            //m1i.Add(i1);
            //m1i.Add(i2);
            //m1i.Add(i3);

            //Medication m1 = new Medication("paracetamol", null, MedicationStatus.waitingForApproval, m1i, "");
            //Medication m2 = new Medication("panadol", null, MedicationStatus.waitingForApproval, m1i, "");

            //Dictionary<string, Medication> medications = new Dictionary<string, Medication>();

            //medications.Add(m1.id, m1);
            //medications.Add(m2.id, m2);

            //medicationFileStorage.CreateOrUpdate(m1);
            //medicationFileStorage.CreateOrUpdate(m2);


            //string filename = @".\..\..\..\jsondata\medications.json";


            //string json = JsonConvert.SerializeObject(medications, Formatting.Indented);

            //File.WriteAllText(@".\..\..\..\jsondata\medications.json", json);


            Manager m = ManagerFileStorage.Instance.ReadUser(username);


            if (m != null && password.Equals(m.password))
            {
                //MainWindowManager mainWindow = new MainWindowManager();
                //mainWindow.Show();

                ManagerWindow managerWindow = new ManagerWindow();
                // timer = new Timer(new TimerCallback(roomInventoryController.RelocateOnDate), null, 1000, 60000);
                managerWindow.Show();

                this.Close();
            }
            else
            {
                MessageBox.Show("Pogresan username i/ili password!");
            }
        }
    }
}
