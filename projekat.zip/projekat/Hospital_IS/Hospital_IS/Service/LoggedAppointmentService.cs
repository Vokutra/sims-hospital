﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    public class LoggedAppointmentService
    {
        private LoggedAppointmentFileStorage loggedAppointmentFileStorage = new LoggedAppointmentFileStorage();

        public List<LoggedAppointment> GetAllLoggedAppointments()
        {
            return loggedAppointmentFileStorage.GetEntityList();
        }

        public List<LoggedAppointment> GetLoggedAppointmentsByDoctor(Doctor doctor)
        {
            List<LoggedAppointment> loggedApppointments = new List<LoggedAppointment>();

            foreach (LoggedAppointment la in  loggedAppointmentFileStorage.GetEntityList())
            {
                if (la.doctor.userID.Equals(doctor.userID))
                {
                    loggedApppointments.Add(la);
                }
            }

            return loggedApppointments;
        }

        public List<LoggedAppointment> GetLoggedAppointmentsByPatient(Patient patient)
        {
            List<LoggedAppointment> loggedApppointments = new List<LoggedAppointment>();

            foreach (LoggedAppointment la in loggedAppointmentFileStorage.GetEntityList())
            {
                if (la.patient.userID.Equals(patient.userID))
                {
                    loggedApppointments.Add(la);
                }
            }

            return loggedApppointments;
        }

        public void CreateOrUpdate(LoggedAppointment la)
        {
            loggedAppointmentFileStorage.CreateOrUpdate(la);
        }

        public LoggedAppointment GetById(string id)
        {
            foreach(LoggedAppointment la in loggedAppointmentFileStorage.GetEntityList())
            {
                if(la.id.Equals(id))
                {
                    return la;
                }
            }

            return null;
        }

    }
}
