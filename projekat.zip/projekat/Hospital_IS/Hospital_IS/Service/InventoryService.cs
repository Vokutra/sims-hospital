﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
     public class InventoryService : IInventoryService
    {
        private IInventoryFileStorage inventoryFileStorage = new InventoryFileStorage();

        public void AddInventory(Inventory inventory) 
        {
            inventoryFileStorage.CreateOrUpdate(inventory);
        }

        public void DeleteInventory (Inventory inventory)
        {
            inventoryFileStorage.DeleteByReference(inventory);
        }

        public List<Inventory> GetEntityList()
        {
            return inventoryFileStorage.GetEntityList();
        }

        public void UpdateInventory(Inventory inventory)
        {
            inventoryFileStorage.CreateOrUpdate(inventory);
        }

        public Inventory GetInventoryById(String id)
        {
            return inventoryFileStorage.FindById(id);
        }

        public List<Inventory> GetInventoriesByType(InventoryType type)
        {
            List<Inventory> retVal = new List<Inventory>();

            foreach (Inventory inventory in GetEntityList())
            {
                if (inventory.inventoryType.Equals(type))
                {
                    retVal.Add(inventory);
                }
            }
            return retVal;

        }
    }
}
