﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Allergen
    {
        [DataMember]
        public string allergenName { get; set; }
        [DataMember]
        public string allergenId { get; set; }
        [DataMember]
        public bool serialize { get; set; }

        [JsonConstructor]
        public Allergen(string allergenName)
        {
            this.allergenName = allergenName;
            this.allergenId = DateTime.Now.ToString("yyMMddhhmmssffffff");


        }

        public Allergen()
        {
            this.allergenName = "";
            this.allergenId = "";
        }

        public bool ShouldSerializeallergenName()
        {
            return serialize;
        }

        public override string ToString()
        {
            return allergenName;
        }

    }
}
