﻿using Hospital_IS.Model;
using Hospital_IS.PatientWindow;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    public class NotificationService
    {
        private NotificationFileStorage notificationFileStorage = new NotificationFileStorage();

        public void CreateNotification(Notification notification)
        {
            notificationFileStorage.CreateOrUpdate(notification);
        }

        public List<Notification> GetAllNotifications()
        {
            return notificationFileStorage.GetEntityList();
        }

        public List<Notification> GetNotificationsForUser(string id)
        {
            List<Notification> notifications = new List<Notification>();

            foreach (Notification notification in GetAllNotifications())
            {
                if (notification.receiverId.Equals(id))
                    notifications.Add(notification);
            }

            return notifications;
        }

        public Notification FindById(string id)
        {
            return notificationFileStorage.FindById(id);
        }

        public void NotifyPatientAboutTherapies(object state)
        {
            string now = DateTime.Now.ToString("HH:mm");
            int hours = int.Parse(now.Split(":")[0]);
            int minutes = int.Parse(now.Split(":")[1]);

            foreach (Therapy therapy in LoginPatient.patient.therapies)
            {
                if (IsTherapyInUse(therapy))
                {
                    NotifyPatientAboutTherapy(therapy, hours, minutes);
                }
            }
        }

        public bool IsTherapyInUse(Therapy therapy)
        {
            return DateTime.Compare(therapy.startDate, DateTime.Now) == -1 && DateTime.Compare(DateTime.Now, therapy.endDate) == -1;
        }

        public void NotifyPatientAboutTherapy(Therapy therapy, int hours, int minutes)
        {
            if (therapy.dailyFrequency == 1 && IsTimeForOneDailyFrequencyTherapy(hours, minutes))
            {
                CreateNotification(new Notification("", LoginPatient.patient.userID, "Podsetnik za terapiju", "Vreme je da popijete " + therapy.medicationNameAndDosage + "." + " \nSrdačan pozdrav!", DateTime.Now, false));
            }
            else if (therapy.dailyFrequency == 2 && IsTimeForTwoDailyFrequencyTherapy(hours, minutes))
            {
                CreateNotification(new Notification("", LoginPatient.patient.userID, "Podsetnik za terapiju", "Vreme je da popijete " + therapy.medicationNameAndDosage + "." + " \nSrdačan pozdrav!", DateTime.Now, false));
            }
            else if (therapy.dailyFrequency == 3 && IsTimeForThreeDailyFrequencyTherapy(hours, minutes))
            {
                CreateNotification(new Notification("", LoginPatient.patient.userID, "Podsetnik za terapiju", "Vreme je da popijete " + therapy.medicationNameAndDosage + "." + "\nSrdačan pozdrav!", DateTime.Now, false));
            }
            else if (therapy.dailyFrequency == 4 && IsTimeForFourDailyFrequencyTherapy(hours, minutes))
            {
                    CreateNotification(new Notification("", LoginPatient.patient.userID, "Podsetnik za terapiju", "Vreme je da popijete " + therapy.medicationNameAndDosage + "." + " \nSrdačan pozdrav!", DateTime.Now, false));
            }
        }

        public bool IsTimeForOneDailyFrequencyTherapy(int hours, int minutes)
        {
            return hours == 8 && minutes == 0;
        }

        public bool IsTimeForTwoDailyFrequencyTherapy(int hours, int minutes)
        {
            return (hours == 8 && minutes == 0) || (hours == 20 && minutes == 0);
        }

        public bool IsTimeForThreeDailyFrequencyTherapy(int hours, int minutes)
        {
            return (hours == 8 && minutes == 0) || (hours == 16 && minutes == 0) || (hours == 24 && minutes == 0);
        }

        public bool IsTimeForFourDailyFrequencyTherapy(int hours, int minutes)
        {
            return (hours == 8 && minutes == 0) || (hours == 14 && minutes == 0) || (hours == 20 && minutes == 0) || (hours == 2 && minutes == 0);
        }

        public bool AreAllNotificationsRead()
        {
            bool areAllRead = true;
            foreach (Notification notification in GetNotificationsForUser(LoginPatient.patient.userID))
            {
                if (notification.isRead == false)
                    areAllRead = false;
            }

            return areAllRead;
        }
    }
}
