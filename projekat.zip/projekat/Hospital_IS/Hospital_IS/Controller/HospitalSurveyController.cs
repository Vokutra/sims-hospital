﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class HospitalSurveyController
    {
        private HospitalSurveyService hospitalSurveyService = new HospitalSurveyService();
        public void SaveSurvey(HospitalSurvey hospitalSurvey)
        {
            hospitalSurveyService.SaveSurvey(hospitalSurvey);
        }

        public List<HospitalSurvey> GetAllHospitalSurveysByPatient(Patient patient)
        {
            return hospitalSurveyService.GetAllHospitalSurveysByPatient(patient);
        }

        public List<HospitalSurvey> GetAllHospitalSurveysByGrade(int grade)
        {
            return hospitalSurveyService.GetAllHospitalSurveysByGrade(grade);
        }

        public double GetAverageGradeByQuestion(string question)
        {
            return hospitalSurveyService.GetAverageGradeByQuestion(question);
        }

        public bool IsHospitalSurveyActive(Patient patient)
        {
            return hospitalSurveyService.IsHospitalSurveyActive(patient);
        }
    }
}
