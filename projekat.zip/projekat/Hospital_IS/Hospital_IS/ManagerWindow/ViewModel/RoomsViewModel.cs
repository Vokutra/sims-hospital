﻿using Hospital_IS.Commands;
using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading;

namespace Hospital_IS.ManagerWindow.ViewModel
{
    class RoomsViewModel
    {
        private Room selectedRoom;
        public static ObservableCollection<Room> rooms { get; set; }
        private RoomController roomController = new RoomController();
        private RoomInventoryController roomInventoryController = new RoomInventoryController();
        private MergingRoomsController mergingRoomsController = new MergingRoomsController();
        private SeparatingRoomController separatingRoomController = new SeparatingRoomController();
        private RenovationController renovationController = new RenovationController();

        public static Timer timerMerging;
        public static Timer timerSeparating;
        public static Timer timerRenovation;

        public RelayCommand AddCommand { get; set; }
        public RelayCommand EditCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }
        public RelayCommand RenovateCommand { get; set; }
        public RelayCommand MergeCommand { get; set; }
        public RelayCommand SeparateCommand { get; set; }


        public Room SelectedRoom
        {
            get { return selectedRoom; }
            set { selectedRoom = value; }
        }
        public RoomsViewModel()
        {
            timerRenovation = new Timer(new TimerCallback(renovationController.RenovateOnDate), null, 1000, 60000);
            timerMerging = new Timer(new TimerCallback(mergingRoomsController.MergeOnDate), null, 1000, 60000);
            timerSeparating = new Timer(new TimerCallback(separatingRoomController.SeparateOnDate), null, 1000, 60000);

            rooms = new ObservableCollection<Room>(RoomFileStorage.Instance.GetEntityList());

            AddCommand = new RelayCommand(param => ExecuteAdd());
            EditCommand = new RelayCommand(param => ExecuteEdit(), param => CanExecuteEdit());
            DeleteCommand = new RelayCommand(param => ExecuteDelete(), param => CanExecuteDelete());
            RenovateCommand = new RelayCommand(param => ExecuteRenovate(), param => CanExecuteRenovate());
            MergeCommand = new RelayCommand(param => ExecuteMerge(), param => CanExecuteMerge());
            SeparateCommand = new RelayCommand(param => ExecuteSeparate(), param => CanExecuteSeparate());

        }

        private bool CanExecuteSeparate()
        {
            if (selectedRoom == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteSeparate()
        {

            SeparateRoom separateRoom = new SeparateRoom(selectedRoom);
            separateRoom.Show();
        }

        private bool CanExecuteMerge()
        {
            if (selectedRoom == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteMerge()
        {
            MergeRooms mergeRooms = new MergeRooms(selectedRoom);
            mergeRooms.Show();
        }

        private bool CanExecuteRenovate()
        {
            if (selectedRoom == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteRenovate()
        {
            RenovateRoom renovateRoom = new RenovateRoom(selectedRoom);
            renovateRoom.Show();
        }

        private bool CanExecuteDelete()
        {
            if (selectedRoom == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteDelete()
        {
            roomController.DeleteRoom(selectedRoom);
            rooms.Remove(selectedRoom);
        }

        private bool CanExecuteEdit()
        {
            if (selectedRoom == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteEdit()
        {
            EditRoom editRoom = new EditRoom(selectedRoom);
            editRoom.Show();
        }

        private void ExecuteAdd()
        {
            AddRoom addRoom = new AddRoom();
            addRoom.Show();
        }

    }

}
