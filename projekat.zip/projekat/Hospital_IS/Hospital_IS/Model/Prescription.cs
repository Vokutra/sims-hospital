﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Prescription
    {
        [DataMember]
        public Doctor doctor { get; set; }
        [DataMember]
        public Patient patient { get; set; }
        [DataMember]
        public DateTime issueDate { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public string medicationNameAndDosage { get; set; }
        [DataMember]
        public string id { get; set; }

        public Prescription(Doctor doctor, Patient patient, DateTime issueDate, string description, string medicationNameAndDosage)
        {
            this.doctor = doctor;
            this.patient = patient;
            this.issueDate = issueDate;
            this.description = description;
            this.medicationNameAndDosage = medicationNameAndDosage;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }

    }
}
