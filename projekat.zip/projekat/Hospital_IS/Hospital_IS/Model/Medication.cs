﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Medication
    {
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public string name { get; set; }
        [DataMember]
        public int amount { get; set;  }
        [DataMember]
        public Medication alternative { get; set; }
        [DataMember]
        public MedicationStatus status { get; set; }
        [DataMember]
        public List<Ingredient> ingredients { get; set; }
        [DataMember]
        public string doctorsApprovalComment { get; set; }
        [DataMember]
        public bool serialize { get; set; }

        [JsonConstructor]
        public Medication(string name, int amount, Medication alternative, MedicationStatus status, List<Ingredient> ingredients, string doctorsApprovalComment)
        {
            this.name = name;
            this.amount = amount;
            this.alternative = alternative;
            this.status = status;
            this.ingredients = ingredients;
            this.doctorsApprovalComment = doctorsApprovalComment;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }

        public Medication(string name, Medication alternative, MedicationStatus status)
        {
            this.name = name;
            this.alternative = alternative;
            this.status = status;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }

        public Medication()
        {
            this.name = "";
            this.amount = 0; 
            this.alternative = null;
            this.status = MedicationStatus.waitingForApproval;
            this.ingredients = new List<Ingredient>();
            this.doctorsApprovalComment = doctorsApprovalComment;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");

        }

        //public bool ShouldSerializename()
        //{
        //    return serialize;
        //}

        public bool ShouldSerializeamount()
        {
            return serialize;
        }
        public bool ShouldSerializealternative()
        {
            return serialize;
        }
        public bool ShouldSerializeingredients()
        {
            return serialize;
        }
        public bool ShouldSerializestatus()
        {
            return serialize;
        }
        public bool ShouldSerializedoctorsApprovalComment()
        {
            return serialize;
        }

        public string MedicationStatusToString
        {
            get
            {
                return status switch
                {
                    MedicationStatus.approved => "Odobren",
                    MedicationStatus.waitingForApproval => "Na cekanju",
                    MedicationStatus.denied => "Odbijen",
                    _ => "",
                };
            }

        }

        public string AlternativeName
        {
            get
            {
                string name = alternative.name;
                return name;
            }

        }
    }
}

