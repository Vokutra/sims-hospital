﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.SecretaryWindow
{
    /// <summary>
    /// Interaction logic for DoctorAppTable.xaml
    /// </summary>
    public partial class DoctorAppTable : Window
    {
        private DoctorController doctorController = new DoctorController();
        private PatientController patientController = new PatientController();
        private AppointmentController appointmentController = new AppointmentController();
        private RoomController roomController = new RoomController();
        public BindingList<AppointmentDoctorDTO> appointmentsDTO { get; set; }


        public List<Appointment> appointments;
        public Doctor doctor { get; set; }
        public DoctorAppTable(Doctor doctor)
        {
            InitializeComponent();
            appointmentsDTO = new BindingList<AppointmentDoctorDTO>();
            this.doctor = doctor;
            DataContext = this;

            appointments = appointmentController.GetAppointmentsByDoctor(doctor);

            appointmentsDTO.Clear();

            foreach (Appointment a in appointments)
            {
                if (a.appointmentType == AppointmentType.Operation)
                {
                    Patient p = patientController.GetPatientById(a.patient.userID);
                    appointmentsDTO.Add(new AppointmentDoctorDTO(p.name + " " + p.surname, a.startTime.ToShortDateString(), a.startTime.ToString("HH:mm"), roomController.getRoomById(a.room.roomName).ToString(), "Operacija", a.id));
                }


                else if (a.appointmentType == AppointmentType.Examination)
                {
                    Patient p = patientController.GetPatientById(a.patient.userID);
                    appointmentsDTO.Add(new AppointmentDoctorDTO(p.name + " " + p.surname, a.startTime.ToShortDateString(), a.startTime.ToString("HH:mm"), roomController.getRoomById(a.room.roomName).ToString(), "Pregled", a.id));
                }
            }
        }
        private void RemoveAppointmentFromPatient(string appointmentID, Appointment a)
        {
            string patientID = a.patient.userID;
            Patient patient = patientController.GetPatientById(patientID);

            int index = 0;
            foreach (string id in patient.appointmentIDs)
            {
                if (id.Equals(appointmentID))
                {
                    patient.appointmentIDs.RemoveAt(index);
                    patientController.CreateOrUpdate(patient);
                    return;
                }
                index++;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (DoctorsAppointmentsTable.SelectedItem != null)
            {
                if (MessageBox.Show("Jeste li sigurni da zelite da otkazete odabrani termin?",
                "Otkazivanje termina", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

                    Appointment appointment = appointmentController.GetAppointment(a.id);

                    RemoveAppointmentFromPatient(a.id, appointment);

                    appointmentController.DeleteAppointment(a.id);



                    MessageBox.Show("Termin je uspesno otkazan.");


                }
            }
        }

        private void btnNewApp_Click(object sender, RoutedEventArgs e)
        {
            AddAppointment aa = new AddAppointment(doctor);

            aa.Show();
            this.Close();
        }

        private void btnMove_Click(object sender, RoutedEventArgs e)
        {
            if (DoctorsAppointmentsTable.SelectedItem != null)
            {
                AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

                string appointmentID = a.id;

                EditAppointment ea = new EditAppointment(appointmentID, doctor);

                ea.Show();
                this.Close();
            }

            //private void btnMove_Click(object sender, RoutedEventArgs e)
            //{
            //    if (DoctorsAppointmentsTable.SelectedItem != null)
            //    {
            //        AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

            //        string appointmentID = a.id;

            //        EditAppointment ea = new EditAppointment(appointmentID);

            //        ea.Show();
            //        this.Close();
            //    }
            //}
            //public void refreshAppointments()
            //{

            //    appointments = appointmentController.GetAppointmentsByDoctor(loggedDoctor);

            //    appointmentsDTO.Clear();

            //    foreach (Appointment a in appointments)
            //    {
            //        if (a.appointmentType == AppointmentType.Examination)
            //            appointmentsDTO.Add(new AppointmentDoctorDTO(patientController.GetPatientById(a.patient.userID).ToString(), a.startTime.ToShortDateString(), a.startTime.ToString("HH:mm"), roomController.getRoomById(a.room.roomName).ToString(), "Pregled", a.id));
            //        else
            //            appointmentsDTO.Add(new AppointmentDoctorDTO(patientController.GetPatientById(a.patient.userID).ToString(), a.startTime.ToShortDateString(), a.startTime.ToString("HH:mm"), roomController.getRoomById(a.room.roomName).ToString(), "Operacija", a.id));
            //    }
            //}
            //private void btnCancelAppointment_Click(object sender, RoutedEventArgs e)
            //{
            //    if (DoctorsAppointmentsTable.SelectedItem != null)
            //    {
            //        if (MessageBox.Show("Jeste li sigurni da zelite da otkazete odabrani termin?",
            //        "Otkazivanje termina", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            //        {
            //            AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

            //            Appointment appointment = appointmentController.GetAppointment(a.id);

            //            RemoveAppointmentFromPatient(a.id, appointment);

            //            appointmentController.DeleteAppointment(a.id);



            //            MessageBox.Show("Termin je uspjesno otkazan.");


            //        }
            //    }
            //}

            //private void btnMoveAppointment_Click(object sender, RoutedEventArgs e)
            //{
            //    if (DoctorsAppointmentsTable.SelectedItem != null)
            //    {
            //        AppointmentDoctorDTO a = (AppointmentDoctorDTO)DoctorsAppointmentsTable.SelectedItem;

            //        string appointmentID = a.id;

            //        EditAppointment ea = new EditAppointment();
            //        ea.Show();
            //        this.Close();
            //    }
            //}

            //private void btnMakeAppointment_Click(object sender, RoutedEventArgs e)
            //{
            //    AddAppointment ap = new AddAppointment();
            //    ap.Show();
            //    this.Close();
            //}

            //private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
            //{

            //}
        }
    }
}
