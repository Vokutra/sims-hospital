using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Patient : UserAccount
    {
        [DataMember]
        public bool isBanned { get; set; }
        [DataMember]
        public string theme { get; set; }
        [DataMember]
        public string language { get; set; }
        [DataMember]
        public List<string> appointmentIDs { get; set; }
        [DataMember]
        public List<Allergen> allergens { get; set; }
        [DataMember]
        public BloodType bloodType { get; set; }
        [DataMember]
        public Gender gender { get; set; }
        [DataMember]
        public Doctor doctor { get; set; }
        [DataMember]
        public List<DateTime> datesOfCanceledAppointments { get; set; }
        [DataMember]
        public List<DateTime> appointmentCancellationTimes { get; set; }
        [DataMember]
        public List<Therapy> therapies { get; set; }




        public Patient(bool isBanned, string theme, string language, List<string> appointmentIDs, BloodType bloodType, Gender gender, Doctor doctor) : base()
        {
            this.isBanned = isBanned;
            this.theme = theme;
            this.language = language;
            this.appointmentIDs = appointmentIDs;
            this.bloodType = bloodType;
            this.gender = gender;
            this.doctor = doctor;
            this.appointmentIDs = new List<string>();
            this.appointmentCancellationTimes = new List<DateTime>();
            this.datesOfCanceledAppointments = new List<DateTime>();
            this.therapies = new List<Therapy>();
        }
        public Patient (string name, string surname, string userID, Gender gender, BloodType bloodType)
        {

            this.name = name;
            this.surname = surname;
            this.userID = userID;
            this.gender = gender;
            this.bloodType = bloodType;
        }


        [JsonConstructor]
        public Patient(string name, string lastname, string username, string password, string userID)
        {
            this.name = name;
            this.surname = lastname;
            this.username = username;
            this.password = password;
            this.userID = userID;
            this.appointmentIDs = new List<string>();
            this.appointmentCancellationTimes = new List<DateTime>();
            this.datesOfCanceledAppointments = new List<DateTime>();
            this.therapies = new List<Therapy>();
        }

        
        public override string ToString()
        {
            return this.name + " " + this.surname;
        }

        public Patient()
        {
            this.name = "";
            this.surname = "";
            this.username = "";
            this.password = "";
            this.userID = "";
            this.phoneNum = "";
            this.email = "";
            this.doB = DateTime.MinValue; 
            this.address = null;
            this.gender = Gender.male;
            this.appointmentCancellationTimes = new List<DateTime>();
            this.datesOfCanceledAppointments = new List<DateTime>();
            this.therapies = new List<Therapy>();
        }

        public Patient(string name, string lastname, string username, string password, string userID, string phone, string email, Address address, DateTime dob, Gender gender, BloodType bloodType, List<Allergen> allergens)
        {
            this.name = name;
            this.surname = lastname;
            this.username = username;
            this.password = password;
            this.userID = userID;
            this.phoneNum = phone;
            this.email = email;
            this.address = address;
            this.doB = doB;
            this.gender = gender;
            this.appointmentCancellationTimes = new List<DateTime>();
            this.datesOfCanceledAppointments = new List<DateTime>();
            this.therapies = new List<Therapy>();
            this.bloodType = bloodType;
            this.allergens = allergens;
        }

        public bool ShouldSerializeisBanned()
        {
            return serialize;
        }

        public bool ShouldSerializetheme()
        {
            return serialize;
        }

        public bool ShouldSerializelanguage()
        {
            return serialize;
        }

        public bool ShouldSerializeappointmentIDs()
        {
            return serialize;
        }

        public bool ShouldSerializebloodType()
        {
            return serialize;
        }

        public bool ShouldSerializegender()
        {
            return serialize;
        }

        public bool ShouldSerializedoctor()
        {
            return serialize;
        }
        public bool ShouldSerializeallergens()
        {
            return serialize;
        }

        public bool ShouldSerializetherapies()
        {
            return serialize;
        }

        public bool ShouldSerializedatesOfCanceledAppointments()
        {
            return serialize;
        }

        public bool ShouldSerializeappointmentCancellationTimes()
        {
            return serialize;
        }

    }
}