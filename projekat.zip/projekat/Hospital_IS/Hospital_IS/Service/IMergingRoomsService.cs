﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_IS.Service
{
    interface IMergingRoomsService
    {
        public void AddMergingRooms(MergingRooms mergingRooms);
       
        public List<MergingRooms> GetAllMergingRooms();
       
        public void UpdateMergingRooms(MergingRooms mergingRooms);
        
        public void DeleteMergingRooms(MergingRooms mergingRooms);
        
        public void MergeRooms(MergingRooms mergingRooms);
        public void MergeOnDate(object state);
    }
}
