﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using Hospital_IS.PatientWindow.Toasts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for HospitalSurvey.xaml
    /// </summary>
    public partial class HospitalSurveyPage : Page
    {
        private HospitalSurveyController hospitalSurveyController = new HospitalSurveyController();
        private Thread thread;
        public HospitalSurveyPage()
        {
            InitializeComponent();
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            HospitalSurvey hospitalSurvey = new HospitalSurvey(txtComment.Text, LoginPatient.patient, DateTime.Now + LoginPatient.patient.userID);
            hospitalSurvey.answers.Add((string)question1.Content, answer1.Value);
            hospitalSurvey.answers.Add((string)question2.Content, answer2.Value);
            hospitalSurvey.answers.Add((string)question3.Content, answer3.Value);
            hospitalSurvey.answers.Add((string)question4.Content, answer4.Value);
            hospitalSurvey.answers.Add((string)question5.Content, answer5.Value);

            hospitalSurveyController.SaveSurvey(hospitalSurvey);

            MainWindowPatient.getInstance().btnRateHospital.IsEnabled = false;

            MainWindowPatient.getInstance().SetContent(new StartPage());
            thread = new Thread(new ConfirmationToast().ShowConfirmationToast);
            thread.Start("Uspešno ste popunili anketu!");


        }
    }
}
