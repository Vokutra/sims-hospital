﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class RoomInventoryDTO
    {
        public string room { get; set; }
        public string item { get; set; }
        public string inventoryID { get; set; }
        public int amount { get; set; }
        public string id { get; set; }
        public InventoryType inventoryType { get; set; }
        public DateTime? date { get; set; }

        public RoomInventoryDTO(string room, string item, string inventoryID, int amount, InventoryType inventoryType, DateTime? date, string id)
        {
            this.room = room;
            this.item = item;
            this.inventoryID = inventoryID;
            this.amount = amount;
            this.inventoryType = inventoryType;
            this.date = date;
            this.id = id;
        }

        public RoomInventoryDTO()
        {
            this.room = "";
            this.item = "";
            this.inventoryID = "";
            this.amount = 0;
            this.inventoryType = InventoryType.statical;
            this.date = null;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }

        public string InventoryTypeToString
        {
            get
            {
                return inventoryType switch
                {
                    InventoryType.dynamical => "Potrosna",
                    InventoryType.statical => "Nepotrosna",
                    _ => "",
                };
            }
        }
    }
}
