﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    class SeparatingRoomService : ISeparatingRoomService
    {
        public ISeparatingRoomFileStorage separatingRoomFileStorage = new SeparatingRoomFileStorage();
        private IRoomService roomService = new RoomService();

        public void AddSeparatingRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomFileStorage.CreateOrUpdate(separatingRoom);
        }


        public List<SeparatingRoom> GetAllSeparatingRoom()
        {
            return separatingRoomFileStorage.GetEntityList();
        }



        public void UpdateSeparatingRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomFileStorage.CreateOrUpdate(separatingRoom);
        }

        public void DeleteSeparatingRoom(SeparatingRoom separatingRoom)
        {
            separatingRoomFileStorage.DeleteByReference(separatingRoom);
        }

        public void SeparateRoom(SeparatingRoom separatingRoom)
        {
            Room roomOne = separatingRoom.roomOne;
            Room roomTwo = separatingRoom.roomTwo;
            DateTime? endDate = separatingRoom.endDateRenovation;

            roomService.UpdateRoom(roomOne);
            roomService.AddRoom(roomTwo);

        }

        public void SeparateOnDate(object state)
        {
            List<SeparatingRoom> separatingRoom = new List<SeparatingRoom>();
            separatingRoom = GetAllSeparatingRoom();
            foreach (var separating in separatingRoom)
            {
                if (DateTime.Compare(DateTime.Today, (DateTime)separating.endDateRenovation) == -1)
                {
                    App.Current.Dispatcher.Invoke((Action)delegate
                    {
                        SeparateRoom(separating);
                        SeparatingRoomFileStorage.Instance.DeleteById(separating.id);
                    });
                }
            }

        }
    }
}
