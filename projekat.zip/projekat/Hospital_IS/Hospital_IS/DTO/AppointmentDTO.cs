﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class AppointmentDTO
    {
        public string date { get; set; }
        public string time { get; set; }
        public string doctor { get; set; }
        public string id { get; set; }
        public string room { get; set; }

        public AppointmentDTO(string date, string time, string doctor, string id, string room)
        {
            this.date = date;
            this.time = time;
            this.doctor = doctor;
            this.id = id;
            this.room = room;
        }

        public AppointmentDTO(string date, string time, string doctor, string id)
        {
            this.date = date;
            this.time = time;
            this.doctor = doctor;
            this.id = id;
            this.room = "";
        }
    }
}
