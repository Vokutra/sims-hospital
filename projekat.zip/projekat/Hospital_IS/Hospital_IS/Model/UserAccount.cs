using System;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public abstract class UserAccount
    {
        [DataMember]
        public string username { get; set; }
        [DataMember]
        public string password { get; set; }
        [DataMember]
        public string name { get; set; }
        [DataMember]
        public string surname { get; set; }
        [DataMember]
        public DateTime doB { get; set; }
        [DataMember]
        public string phoneNum { get; set; }
        [DataMember]
        public string email { get; set; }
        [DataMember]
        public string userID { get; set; }
        [DataMember]
        public bool isGuest { get; set; }
        [DataMember]
        public bool serialize { get; set; } 
        [DataMember]
        public Address address { get; set; }

        public bool ShouldSerializeusername()
        {
            return serialize;
        }

        public bool ShouldSerializepassword()
        {
            return serialize;
        }

        public bool ShouldSerializename()
        {
            return serialize;
        }

        public bool ShouldSerializesurname()
        {
            return serialize;
        }

        public bool ShouldSerializedoB()
        {
            return serialize;
        }

        public bool ShouldSerializephoneNum()
        {
            return serialize;
        }

        public bool ShouldSerializeemail()
        {
            return serialize;
        }

        public bool ShouldSerializeisGuest()
        {
            return serialize;
        }

        public bool ShouldSerializeaddress()
        {
            return serialize;
        }

        public bool ShouldSerializeserialize()
        {
            return serialize;
        }

    }

}