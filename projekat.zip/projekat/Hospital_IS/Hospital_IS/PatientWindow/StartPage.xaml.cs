﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System.Windows;
using System.Windows.Controls;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for StartPage.xaml
    /// </summary>
    public partial class StartPage : Page
    {
        private NotificationController notificationController = new NotificationController();
        public StartPage()
        {
            InitializeComponent();
        }

        private void btnMakeAppointment_Click(object sender, RoutedEventArgs e)
        {
            MainWindowPatient.getInstance().SetContent(new MakeAppointment());
        }

        private void btnScheduledAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowPatient.getInstance().SetContent(ScheduledAppointments.getInstance());
        }

        private void btnNotifications_Click(object sender, RoutedEventArgs e)
        {
            Notifications notificationsPage = new Notifications();
            foreach (Notification notification in notificationController.GetNotificationsForUser(LoginPatient.patient.userID))
            {
                Notifications.notificationsDTO.Insert(0, new NotificationDTO(notification.title, notification.sentTime.ToString("MM / dd / yyyy h: mm tt"), notification.id));
            }
            MainWindowPatient.getInstance().SetContent(notificationsPage);
        }
    }
}
