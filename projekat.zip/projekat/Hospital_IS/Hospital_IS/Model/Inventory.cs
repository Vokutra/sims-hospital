﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    public class Inventory
    {
        
        [DataMember]
        public string inventoryID { get; set; }
        [DataMember]
        public string name { get; set; }
       
        [DataMember]
        public int amount { get; set; }
        [DataMember]
        public bool serialize { get; set; }
        [DataMember]
        public InventoryType inventoryType { get; set; }

        // public string roomName { get; set; }


        [JsonConstructor]
        public Inventory( string name, int amount, string inventoryID)
        {
            this.name = name;
            this.amount = amount;
            this.inventoryID = inventoryID;
        }

        public Inventory(string name, string inventoryID)
        {
            this.name = name;
            this.inventoryID = inventoryID;
        }

        public Inventory()
        {
            this.name = "";
            this.amount = 0;
            this.inventoryID = "";
        }

        public bool ShouldSerializeamount()
        {
            return serialize;
        }

        public string InventoryTypeToString
        {
            get
            {
                return inventoryType switch
                {
                    InventoryType.dynamical => "Potrosna",
                    InventoryType.statical => "Nepotrosna",
                    _ => "",
                };
            }
        }
    }
}
