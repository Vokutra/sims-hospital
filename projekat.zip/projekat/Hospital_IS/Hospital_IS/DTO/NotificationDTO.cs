﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.DTO
{
    public class NotificationDTO
    {
        public string title { get; set; }
        public string sentTime { get; set; }
        public string id { get; set; }

        public NotificationDTO(string title, string sentTime, string id)
        {
            this.title = title;
            this.sentTime = sentTime;
            this.id = id;
        }
    }

}
