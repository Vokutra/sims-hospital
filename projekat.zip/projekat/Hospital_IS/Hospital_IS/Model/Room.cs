﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Room
    {
        [DataMember]
        public int floorNumber { get; set; }
        [DataMember]
        public string roomName { get; set; }
        //    [DataMember]
        //     public int areaInSquareMetres { get; set; }
        [DataMember]
        public bool isAvailable { get; set; }
        [DataMember]
        public RoomType roomType { get; set; }
        [DataMember]
        public bool serialize { get; set; }

        [JsonConstructor]
        public Room(RoomType roomType, int floorNumber, bool isAvailable, int areaInSquareMetres, string roomName)
        {
            this.floorNumber = floorNumber;
            this.roomName = roomName;
            //   this.areaInSquareMetres = areaInSquareMetres;
            this.isAvailable = isAvailable;
            this.roomType = roomType;
        }


        public Room(RoomType roomType, int floorNumber, bool isAvailable, string roomName)
        {
            this.floorNumber = floorNumber;
            this.roomName = roomName;
            this.isAvailable = isAvailable;
            this.roomType = roomType;
        }

        public Room()
        {
            this.roomName = "";
            this.roomType = RoomType.examinationRoom;
            this.isAvailable = true;
            this.floorNumber = 1;
            //   this.areaInSquareMetres = 20;
            //serialize = true;
        }




        [JsonIgnore]
        public string RoomAvailabilityToString
        {
            get
            {
                return (isAvailable ? "Dostupna" : "Nedostupna");
            }
        }



        [JsonIgnore]
        public string RoomTypeToString
        {
            get
            {
                return roomType switch
                {
                    RoomType.examinationRoom => "Prijemna ambulanta",
                    RoomType.operationRoom => "Operaciona sala",
                    RoomType.accommodationRoom => "Stacionar",
                    _ => "",
                };
            }
        }



        // [JsonIgnore]
        public static RoomType StringToRoomType(string str)
        {
            return str switch
            {
                "Prostorija za preglede" => RoomType.examinationRoom,
                "Operaciona sala" => RoomType.operationRoom,
                "Stacionar" => RoomType.accommodationRoom,
                _ => RoomType.accommodationRoom,
            };
        }
        public override string ToString()

        {
            return this.roomName;
        }

        public bool ShouldSerializefloorNumber()
        {
            return serialize;
        }

        public bool ShouldSerializeisAvailable()
        {
            return serialize;
        }

        //public bool ShouldSerializeroomType()
        //{
        //    return serialize;
        //}

        public bool ShouldSerializeserialize()
        {
            return serialize;
        }
    }
}