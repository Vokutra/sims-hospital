﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class VacationRequestController
    {
        private VacationRequestService vacationRequestService = new VacationRequestService();

        public List<VacationRequest> getAllVacationRequests()
        {
            return vacationRequestService.getAllVacationRequests();
        }

        public VacationRequest GetVacationRequestById(string id)
        {
            return vacationRequestService.GetVacationRequestById(id);
        }

        public void CreateOrUpdate(VacationRequest vacationRequest)
        {
            vacationRequestService.CreateOrUpdate(vacationRequest);
        }

        public bool SameSpecialistsAreOnVacationDuringPeriod(Doctor doctor, DateTime startDate, DateTime endDate)
        {
            return vacationRequestService.SameSpecialistsAreOnVacationDuringPeriod(doctor, startDate, endDate);
        }

    }
}
