﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class NotificationFileStorage : GenericFileStorage<string, Notification, NotificationFileStorage>
    {
        protected override string GetKey(Notification entity)
        {
            return entity.id;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\notifications.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Notification entity)
        {
            
        }


    }
}
