﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    public class PrescriptionController
    {
        public PrescriptionService prescriptionService = new PrescriptionService();
        public void CreateOrUpdate(Prescription prescription)
        {
             prescriptionService.CreateOrUpdate(prescription);
        }
    }
}
