﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    class Renovation
    {
        [DataMember]
        public Room room { get; set; }
        [DataMember]
        public DateTime? startDateRenovation { get; set; }
        [DataMember]
        public DateTime? endDateRenovation { get; set; }
        [DataMember]
        public bool serialize { get; set; }
        [DataMember]
        public string id { get; set; }

        public Renovation(Room room, DateTime? startDateRenovation, DateTime? endDateRenovation)
        {
            this.room = room;
            this.startDateRenovation = startDateRenovation;
            this.endDateRenovation = endDateRenovation;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");

        }
    }
}
