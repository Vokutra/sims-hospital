﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
     public class IngredientService
    {
        private IngredientFileStorage ingredientFileStorage = new IngredientFileStorage();
        public List<Ingredient> GetAllIngredients()
        {
            return ingredientFileStorage.GetEntityList();
        }

        public Ingredient GetIngredient(String ingredientName)
        {
            return ingredientFileStorage.GetIngredientByName(ingredientName);
        }

        public Ingredient GetIngredientById(string id)
        {
            return ingredientFileStorage.FindById(id);
        }

        public void UpdateIngredient(Ingredient ingredient)
        {
            ingredientFileStorage.CreateOrUpdate(ingredient);
        }

        public void AddIngredient(Ingredient ingredient)
        {
            ingredientFileStorage.CreateOrUpdate(ingredient);
        }

        public void DeleteIngredient(Ingredient ingredient)
        {
            ingredientFileStorage.DeleteByReference(ingredient);
        }

    }
}
