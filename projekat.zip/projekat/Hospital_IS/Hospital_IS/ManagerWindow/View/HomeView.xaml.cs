﻿using Hospital_IS.Controller;
using Hospital_IS.ManagerWindow.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Hospital_IS.ManagerWindow.View
{

    public partial class HomeView : Page
    {
        public MedicationController medicationController = new MedicationController();
        public HomeView()
        {
            InitializeComponent();
            DataContext = new HomeViewModel();
            startclock();
            int total = medicationController.GetAllMedications().Count;
            int waiting = medicationController.GetAllWaitingMedications().Count;

            GraphMedication.To = total;
            GraphMedication.Value = waiting;
        }

        private void startclock()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += tickevent;
            timer.Start();
        }

        private void tickevent(object sender, EventArgs e)
        {
            txtDate.Text = DateTime.Now.ToString(@"M");
        }
    }
}
