﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    class IngredientController
    {
        private IngredientService ingredientService = new IngredientService();
        public List<Ingredient> GetAllIngredients()
        {
            return ingredientService.GetAllIngredients();
        }

        public Ingredient GetIngredient(String ingredientName)
        {
            return ingredientService.GetIngredient(ingredientName);
        }

        public Ingredient GetIngredientById(string id)
        {
            return ingredientService.GetIngredientById(id);
        }

        public void UpdateIngredient(Ingredient ingredient)
        {
            ingredientService.UpdateIngredient(ingredient);
        }

        public void AddIngredient(Ingredient ingredient)
        {
            ingredientService.AddIngredient(ingredient);
        }

        public void DeleteIngredient(Ingredient ingredient)
        {
            ingredientService.DeleteIngredient(ingredient);
        }
    }
}
