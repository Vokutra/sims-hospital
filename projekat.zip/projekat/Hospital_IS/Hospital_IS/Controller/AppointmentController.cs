using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Controller
{
    public class AppointmentController
    {
        private AppointmentService appointmentService = new AppointmentService();
        public List<Appointment> GetAllAppointments()
        {
            return appointmentService.GetAllAppointments();
        }

        public Appointment GetAppointment(string appointmentID)
        {
            return appointmentService.GetAppointment(appointmentID);
        }

        public List<Appointment> GetAppointmentsThatWillBeInProgress(DateTime startTime)
        {
            return appointmentService.GetAppointmentsThatWillBeInProgress(startTime);
        }

        public void UpdateAppointment()
        {
            throw new NotImplementedException();
        }

        public void CreateAppointment(Appointment appointment)
        {
            appointmentService.CreateAppointment(appointment);
        }

        public void DeleteAppointment(string id)
        {
            appointmentService.DeleteAppointment(id);
        }

        public void DeleteAppointment(Appointment appointment)
        {
            appointmentService.DeleteAppointment(appointment);
        }

        public List<Appointment> GetAppointmentsAtSpecificDoctor(Doctor doctor, Patient patient, DateTime startDate, DateTime endDate, TimeSpan startTime, TimeSpan endTime)
        {
            return appointmentService.GetAppointmentsAtSpecificDoctor(doctor, patient, startDate, endDate, startTime, endTime);
        }

        public List<Appointment> GetAppointmentsAtSpecificTime(Doctor doctor, Patient patient, DateTime startDate, DateTime endDate, TimeSpan startTime, TimeSpan endTime)
        {
            return appointmentService.GetAppointmentsAtSpecificTime(doctor, patient, startDate, endDate, startTime, endTime);
        }

        public List<Appointment> GetAppointmentsByDoctor(Doctor doctor)
        {
            return appointmentService.GetAppointmentsByDoctor(doctor);
        }

        public void CreateOrUpdate(Appointment a)
        {
            appointmentService.CreateOrUpdate(a);
        }

        public Appointment getNearestNextAppointment(DateTime selectedDate, Doctor doctor, Patient patient, Room room)
        {
            return appointmentService.getNearestNextAppointment(selectedDate, doctor, patient, room);
        }
        public bool IsRoomFreeForRenovation(Room room, DateTime? starDate, DateTime? endDate)
        {
            return appointmentService.IsRoomFreeForRenovation(room, starDate, endDate);
        }

        public void CancelAppointmentIfThereIsNoRoomAfterMerge(MergingRooms mergingRooms)
        {
            appointmentService.CancelAppointmentIfThereIsNoRoomAfterMerge(mergingRooms);
        }

        public bool existsAppointmentAfter(DateTime selectedDate, Doctor doctor, Patient patient, Room room)
        {
            return appointmentService.existsAppointmentAfter(selectedDate, doctor, patient, room);
        }

        public List<Appointment> getAppointmentsByDoctorPatientRoom(Doctor doctor, Patient patient, Room room, DateTime day)
        {
            return appointmentService.getAppointmentsByDoctorPatientRoomForDay(doctor, patient, room, day);
        }

        public void RemovePastAppointments(object state)
        {
            appointmentService.RemovePastAppointments(state);
        }

        public void RemovePastCanceledAppointments(object state)
        {
            appointmentService.RemovePastCanceledAppointments(state);
        }

        public bool CheckIfPatientHasExaminationAppointment(Patient patient)
        {
            return appointmentService.CheckIfPatientHasExaminationAppointment(patient);
        }

    }
}