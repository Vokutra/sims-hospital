﻿using Hospital_IS.Commands;
using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;

namespace Hospital_IS.ManagerWindow.ViewModel
{
    class MedicationViewModel
    {
        private Medication selectedItem;
        public static BindingList<Medication> medications { get; set; }
        //public static ObservableCollection<MedicationDTO> medicationDTO { get; set; }
        private MedicationController medicationController = new MedicationController();
        public RelayCommand AddCommand { get; set; }
        public RelayCommand EditCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }

        public Medication SelectedItem
        {
           
            get { return selectedItem; }
            set { selectedItem = value; }
        }

        public MedicationViewModel()
        {
            //medicationDTO = new ObservableCollection<MedicationDTO>();

            medications = new BindingList<Medication>(medicationController.GetAllMedications());
            //foreach( Medication medication in medications)
            //{
            //    medicationDTO.Add(new MedicationDTO(medication));
            //}
            AddCommand = new RelayCommand(param => ExecuteAdd());
            EditCommand = new RelayCommand(param => ExecuteEdit(), param => CanExecuteEdit());
            DeleteCommand = new RelayCommand(param => ExecuteDelete(), param => CanExecuteDelete());
        }

        private bool CanExecuteDelete()
        {
            if (selectedItem == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteDelete()
        {
            medicationController.DeleteMedication(selectedItem);

            medications.Remove(selectedItem);
        }

        private void ExecuteEdit()
        {
            EditMedication editMedication = new EditMedication(selectedItem);
            editMedication.Show();
        }

        private bool CanExecuteEdit()
        {
            if (selectedItem == null)
            {
                return false;
            }
            return true;
        }

        private void ExecuteAdd()
        {
            AddMedication addMedication = new AddMedication();
            addMedication.Show();
        }

        //    private void btnAdd_Click(object sender, RoutedEventArgs e)
        //    {
        //        AddMedication addMedication = new AddMedication();
        //        addMedication.Show();
        //    }

        //    private void btnEdit_Click(object sender, RoutedEventArgs e)
        //    {
        //        Medication SelectedMedication = medicationTable.SelectedItem as Medication;

        //        if (SelectedMedication == null)
        //        {
        //            MessageBox.Show("Izabrati lek.");
        //            return;
        //        }

        //        EditMedication editMedication = new EditMedication(SelectedMedication);
        //        editMedication.Show();
        //    }

        //    private void btnDelete_Click(object sender, RoutedEventArgs e)
        //    {
        //        Medication selectedMedication = medicationTable.SelectedItem as Medication;

        //        if (selectedMedication == null)
        //        {
        //            MessageBox.Show("Izabrati lek.");
        //            return;
        //        }

        //        medicationController.DeleteMedication(selectedMedication);

        //        medications = new ObservableCollection<Medication>(medicationController.GetAllMedications());
        //        medicationTable.ItemsSource = medications;
        //    }


        //}
    }
}
