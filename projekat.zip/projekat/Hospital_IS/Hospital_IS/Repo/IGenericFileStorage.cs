﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    public interface IGenericFileStorage<T, ID>
    {
        void Update(T entity);
        void DeleteById(ID key);
        void DeleteByReference(T entity);
        T FindById(ID key);
        List<T> GetEntityList();
        void CreateOrUpdate(T Entity);
    }
}
