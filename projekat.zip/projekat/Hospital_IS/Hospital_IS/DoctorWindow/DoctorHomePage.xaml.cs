﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for DoctorHomePage.xaml
    /// </summary>
    public partial class DoctorHomePage : Page
    {
        public static Doctor loggedDoctor { get; set; }
        public static DoctorHomePage instance { get; set; }

        public Frame mainFrame { get; set; }



        public DoctorHomePage(Doctor doctor, Frame mainFrame)
        {
            loggedDoctor = doctor;

            this.mainFrame = mainFrame;

            InitializeComponent();
        }

        public static DoctorHomePage GetInstance(Doctor doctor, Frame mainFrame)
        {
            if (instance == null)
            {
                loggedDoctor = doctor;
                instance = new DoctorHomePage(loggedDoctor, mainFrame);
                instance.mainFrame = mainFrame;
            }

            return instance;
        }

        public static DoctorHomePage GetInstance()
        {
            return instance;
        }


        private void Button_Appointments_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = DoctorAppointmentsPage.GetInstance(loggedDoctor, mainFrame);
        }

        private void Button_Logged_Appointments_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = DoctorsLoggedAppointmentsPage.GetInstance(loggedDoctor, mainFrame);
        }

        public Doctor getLoggedDoctor()
        {
            return loggedDoctor;
        }

        private void Button_Patients_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = PatientsPage.getInstance(mainFrame, loggedDoctor);
        }

        private void logOutButton_Click(object sender, RoutedEventArgs e)
        {

            LoginDoctor loginDoctor = new LoginDoctor();
            loginDoctor.Show();


            MainWindowDoctor.GetInstance().Close();
            MainWindowDoctor.GetInstance().setInstanceToNull();

            if(DoctorAppointmentsPage.GetInstance() != null)
                DoctorAppointmentsPage.GetInstance().setInstanceToNull();

            if(DoctorsLoggedAppointmentsPage.GetInstance() != null)
                DoctorsLoggedAppointmentsPage.GetInstance().setInstanceToNull();

            instance = null;

        }

        private void medicationButton_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = MedicationPage.getInstance();
        }

        private void vacationDaysButton_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Content = new RequestAVacationPage();
        }
    }
}
