﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.SecretaryWindow
{
    /// <summary>
    /// Interaction logic for LoginSecretary.xaml
    /// </summary>
    public partial class LoginSecretary : Window


    {
        AllergenFileStorage afs = new AllergenFileStorage();
        PatientFileStorage pfs = new PatientFileStorage();
        public LoginSecretary()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {

            string username = txtBoxUsername.Text.Trim();
            string password = txtBoxPassword.Password.Trim();



            //Secretary s = new Secretary("Ana", "Obradovic", "sekretar", "s1", "1");

            //Dictionary<string, Secretary> secretaries = new Dictionary<string, Secretary>();

            //secretaries.Add(s.userID, s);


            //string filename = @".\..\..\..\jsondata\secretary.json";


            //string json = JsonConvert.SerializeObject(secretaries, Formatting.Indented);

            //File.WriteAllText(@".\..\..\..\jsondata\secretary.json", json);

            //Allergen a = new Allergen("med");
            //Dictionary<string, Allergen> allergens = new Dictionary<string, Allergen>();
            //allergens.Add(a.allergenId, a);

            //string filename = @".\..\..\..\jsondata\allergens.json";

            //string json = JsonConvert.SerializeObject(allergens, Formatting.Indented);

            //File.WriteAllText(@".\..\..\..\jsondata\allergens.json", json);

            //Patient p = pfs.FindById("1");
            //Allergen a = afs.FindById("220430081109075460");

            //p.allergens.Add(a);
            //pfs.CreateOrUpdate(p);

            //Allergen a1 = new Allergen("penicilin");
            //afs.CreateOrUpdate(a1);

            //Allergen a2 = new Allergen("brufen");
            //afs.CreateOrUpdate(a2);

            //Allergen a3 = new Allergen("ambrozija");
            //afs.CreateOrUpdate(a3);

            //Allergen a4 = new Allergen("polen");
            //afs.CreateOrUpdate(a4);

            //Allergen a5 = new Allergen("med");
            //afs.CreateOrUpdate(a5);

            Secretary s = SecretaryFileStorage.Instance.ReadUser(username);


            if (s != null && password.Equals(s.password))
            {
                MainWindowSecretary mainWindow = new MainWindowSecretary();
                mainWindow.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Pogresan username i/ili password!");
            }

        }
    }
}
