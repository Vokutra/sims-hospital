using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;

namespace Hospital_IS.Service
{
    public class RoomService: IRoomService
    {
        private IRoomFileStorage roomFileStorage = new RoomFileStorage();
        public Model.Room GetRoomByName(string roomName)
        {
            return roomFileStorage.FindById(roomName);
        }

        public List<Room> GetAllRooms()
        {
            return roomFileStorage.GetEntityList();
        }

        public List<string> GetAllRoomNames()
        {
            return roomFileStorage.GetAllRoomNames();
        }

        public List<Room> GetRoomsByType(Model.RoomType roomType)
        {
            throw new NotImplementedException();
        }

        public List<Room> GetAvailableRooms(Model.RoomType type)
        {
            throw new NotImplementedException();
        }

        public void AddRoom(Model.Room room)
        {
            roomFileStorage.CreateOrUpdate(room);
        }

        public void UpdateRoom(Model.Room room)
        {
            roomFileStorage.Update(room);
        }

        public void DeleteRoom(Model.Room room)
        {
            roomFileStorage.DeleteByReference(room);
        }

        public void TakeRoom(Model.Room room)
        {
            throw new NotImplementedException();
        }

        public void FreeRoom(Model.Room room)
        {
            throw new NotImplementedException();
        }
        //////// vrv zasebna medjuklasa treba da cuva podatke o pocetku i kraju renov
        ///
        //public void RenovationTime(object state) 
        //{
        //    List<Room> renovatingRooms = GetAllRooms();
        //    foreach (Room r in renovatingRooms)
        //    {
        //        if (DateTime.Compare(DateTime.Today, (DateTime)r.endRenovating) == -1 && DateTime.Compare((DateTime)r.startRenovating, DateTime.Today) == -1)
        //        {
        //            App.Current.Dispatcher.Invoke((Action)delegate
        //            {
        //                r.isAvailable = false;
        //                //RoomsPage.rooms
        //            });
        //        }
        //    }
        //}

    }
}