using Hospital_IS.Model;
using System;

namespace Hospital_IS.Repo
{
    public class PatientFileStorage : GenericFileStorage<string, Patient, PatientFileStorage>
    {
        protected override string GetKey(Patient entity)
        {
            return entity.userID;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\JSONData\patients.json";
        }

        protected override void RemoveReferences(string key)
        {
            AppointmentFileStorage appointmentFileStorage = new AppointmentFileStorage();
            foreach (Appointment appointment in appointmentFileStorage.GetEntityList())
            {
                if (appointment.patient.userID.Equals(key))
                    appointmentFileStorage.DeleteById(appointment.id);
            }
        }

        protected override void ShouldSerialize(Patient entity)
        {
            entity.serialize = true;
            entity.doctor.serialize = false;
            foreach(Therapy t in entity.therapies)
            {
                t.doctor.serialize = false;
            }
            foreach(Allergen a in entity.allergens)
            {
                a.serialize = false;
            }
        }

        public Patient ReadUser(String username)
        {
            foreach (Patient p in this.GetEntityList())
            {
                if (p.username.Equals(username))
                    return p;
            }

            return null;
        }
    }
}