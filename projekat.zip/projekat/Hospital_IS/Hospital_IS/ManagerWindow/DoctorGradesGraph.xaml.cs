﻿using Hospital_IS.Controller;
using Hospital_IS.Model;
using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for DoctorGradesGraph.xaml
    /// </summary>
    public partial class DoctorGradesGraph : Window
    {
        public static SeriesCollection SeriesCollection { get; set; }
        public string[] BarLabels { get; set; }
        public Func<double, string> Formatter { get; set; }

        public DoctorSurveyController doctorSurveyController = new DoctorSurveyController();
        public DoctorGradesGraph(Doctor doctor)
        {
            int grade1 = 0;
            int grade2 = 0;
            int grade3 = 0;
            int grade4 = 0;
            int grade5 = 0;

            foreach (DoctorSurvey doctorSurvey in doctorSurveyController.GetAllDoctorSurveysByDoctor(doctor))
            {
                grade1 += doctorSurveyController.GetGradeFromSurveyByGrade(1, doctorSurvey).Count;
                grade2 += doctorSurveyController.GetGradeFromSurveyByGrade(2, doctorSurvey).Count;
                grade3 += doctorSurveyController.GetGradeFromSurveyByGrade(3, doctorSurvey).Count;
                grade4 += doctorSurveyController.GetGradeFromSurveyByGrade(4, doctorSurvey).Count;
                grade5 += doctorSurveyController.GetGradeFromSurveyByGrade(5, doctorSurvey).Count;
            }


            InitializeComponent();
            DataContext = this;

            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title="Broj ocena",
                    Values = new ChartValues<int> {grade1, grade2, grade3, grade4, grade5}
                }
            };

            BarLabels = new[] { "ocena 1", "ocena 2", "ocena 3", "ocena 4", "ocena 5" };
            Formatter = value => value.ToString("N");
        }
    }
}
