using Newtonsoft.Json;
using System;
using System.Runtime.Serialization;

namespace Hospital_IS.Model
{
    [DataContract]
    public class Appointment
    {
        [DataMember]
        public DateTime startTime { get; set; }
        [DataMember]
        public int durationInMinutes { get; set; }
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public Patient patient { get; set; }
        [DataMember]
        public Doctor doctor { get; set; }
        [DataMember]
        public AppointmentType appointmentType { get; set; }
        [DataMember]
        public Room room { get; set; }

        [JsonConstructor]
        public Appointment(DateTime startTime, int durationInMinutes, Patient patient, Doctor doctor, Room room, AppointmentType type)
        {
            this.startTime = startTime;
            this.durationInMinutes = durationInMinutes;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
            this.patient = patient;
            this.doctor = doctor;
            this.room = room;
            this.appointmentType = type;
        }

        public Appointment(DateTime startTime, int durationInMinutes, Patient patient, Doctor doctor, AppointmentType type)
        {
            this.startTime = startTime;
            this.durationInMinutes = durationInMinutes;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
            this.patient = patient;
            this.doctor = doctor;
            this.appointmentType = type;
        }

        public Appointment(Patient patient, DateTime startTime, int durationInMinutes, Room room, AppointmentType appointmentType)
        {
            this.patient = patient;
            this.startTime = startTime;
            this.durationInMinutes = durationInMinutes;
            this.room = room;
            this.appointmentType = appointmentType;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }
        public Appointment()
        {

        }

    }
    
}