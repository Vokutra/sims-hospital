﻿using Hospital_IS.Controller;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    /// <summary>
    /// Interaction logic for HospitalSurvey.xaml
    /// </summary>
    public partial class HospitalSurvey : Window
    {
        public HospitalSurveyController hospitalSurveyController = new HospitalSurveyController();
        public HospitalSurvey()
        {
            InitializeComponent();
            DataContext = this;

            lblProfessionalism.Content = hospitalSurveyController.GetAverageGradeByQuestion("Ocenite profesionalnost našeg osoblja:").ToString("0.00");
            lblHygiene.Content = hospitalSurveyController.GetAverageGradeByQuestion("Ocenite higijenu naše ustanove:").ToString("0.00");
            lblFood.Content = hospitalSurveyController.GetAverageGradeByQuestion("Ocenite kvalitet hrane u našoj ustanovi:").ToString("0.00"); 
            lblOrganisation.Content = hospitalSurveyController.GetAverageGradeByQuestion("Ocenite organizaciju naše ustanove:").ToString("0.00"); 
            lblApp.Content = hospitalSurveyController.GetAverageGradeByQuestion("Ocenite rad naše aplikacije:").ToString("0.00"); 
            
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
