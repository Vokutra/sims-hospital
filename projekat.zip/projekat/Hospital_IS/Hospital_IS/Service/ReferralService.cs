﻿using Hospital_IS.Model;
using Hospital_IS.Repo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Service
{
    public class ReferralService
    {
        private ReferralFileStorage referralFileStorage = new ReferralFileStorage();

        public void CreateOrUpdateReferral(Referral referral)
        {
            referralFileStorage.CreateOrUpdate(referral);
        }
    }
}
