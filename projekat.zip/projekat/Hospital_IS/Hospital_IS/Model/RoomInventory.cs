﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Hospital_IS.Model
{
    public class RoomInventory
    {
        [DataMember]
        public Room room { get; set; }
        [DataMember]
        public Inventory inventory { get; set; }
        [DataMember]
        public int amount { get; set; }
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public DateTime? date { get; set; }
        [DataMember]
        public bool serialize { get; set; }

        public RoomInventory(Room room, Inventory inventory, int amount, DateTime? date)
        {
            this.room = room;
            this.inventory = inventory;
            this.amount = amount;
            this.date = date;
            this.id = DateTime.Now.ToString("yyMMddhhmmssffffff");
        }

        
    }
}
