﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for ExamReport.xaml
    /// </summary>
    public partial class ExamReport : Page
    {
        private LoggedAppointmentController loggedAppointmentController = new LoggedAppointmentController();
        private DoctorController doctorController = new DoctorController();
        private DoctorSurveyController doctorSurveyController = new DoctorSurveyController();
        public Doctor doctor { get; set; }
        public LoggedAppointment loggedAppointment { get; set; }
        public ExamReport(string description, Doctor doctor, LoggedAppointment loggedAppointment)
        {
            InitializeComponent();
            txtBoxDescription.Text = description;
            this.doctor = doctor;
            this.loggedAppointment = loggedAppointment;
            if (doctorSurveyController.GetDoctorSurveyById(loggedAppointment.id) != null)
            {
                btnRateDoctor.IsEnabled = false;
            }
        }

        private void btnRateDoctor_Click(object sender, RoutedEventArgs e)
        {
            MainWindowPatient.getInstance().SetContent(new DoctorSurveyPage(doctor, loggedAppointment));

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            HistoryOfExams historyOfExams = new HistoryOfExams();
            List<LoggedAppointment> performedExams = loggedAppointmentController.GetLoggedAppointmentsByPatient(LoginPatient.patient);
            foreach (LoggedAppointment loggedAppointment in performedExams.AsEnumerable().Reverse())
            {
                HistoryOfExams.pastExams.Add(new AppointmentDTO(loggedAppointment.startTime.ToShortDateString(), loggedAppointment.startTime.ToString("HH:mm"), doctorController.FindDoctorById(loggedAppointment.doctor.userID).ToString(), loggedAppointment.id));
            }

            MainWindowPatient.getInstance().SetContent(historyOfExams);
        }
    }
}
