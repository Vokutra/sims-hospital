﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hospital_IS.DoctorWindow
{
    /// <summary>
    /// Interaction logic for MedicationPage.xaml
    /// </summary>
    public partial class MedicationPage : Page
    {
        public static MedicationPage instance;

        private MedicationController medicationController = new MedicationController();

        public List<Medication> medications { get; set; }
        public BindingList<MedicationDTO> medicationDTO { get; set; }

        public MedicationPage()
        {
            InitializeComponent();

            medicationDTO = new BindingList<MedicationDTO>();

            DataContext = this;
        }

        public static MedicationPage getInstance()
        {
            if(instance == null)
            {
                instance = new MedicationPage();
                instance.refreshMedication();
            }

            instance.refreshMedication();

            return instance;
        }

        public void refreshMedication()
        {
            medications = medicationController.GetAllMedications();
            medicationDTO.Clear();

            foreach(Medication medication in medications)
            {
                medicationDTO.Add(new MedicationDTO(medication));
            }
        }

        private void medicationDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            MedicationDTO selectedDTO = (MedicationDTO)dgMedication.SelectedItem;
            string id = selectedDTO.id;

            MainWindowDoctor.GetInstance().MainFrame.Content = new MedicationInfoPage(id);
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorHomePage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }

        private void buttonPatients_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = PatientsPage.getInstance(MainWindowDoctor.GetInstance().MainFrame, MainWindowDoctor.GetInstance().getLoggedDoctor());
        }

        private void buttonAppointments_Click(object sender, RoutedEventArgs e)
        {
            MainWindowDoctor.GetInstance().MainFrame.Content = DoctorAppointmentsPage.GetInstance(MainWindowDoctor.GetInstance().getLoggedDoctor(), MainWindowDoctor.GetInstance().MainFrame);
        }
    }
}
