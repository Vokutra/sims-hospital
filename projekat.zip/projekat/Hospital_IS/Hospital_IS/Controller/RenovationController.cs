﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    class RenovationController
    {
        public IRenovationService renovationService = new RenovationService();

        public void AddRenovation(Renovation renovation)
        {
            renovationService.AddRenovation(renovation);
        }


        public List<Renovation> GetAllRenovations()
        {
            return renovationService.GetAllRenovations();
        }

        

        public void UpdateRenovation(Renovation renovation)
        {
            renovationService.UpdateRenovation(renovation);
        }

        public void DeleteRenovation(Renovation renovation)
        {
            renovationService.DeleteRenovation(renovation);
        }

        public void RenovateOnDate(object state)
        {
            renovationService.RenovateOnDate(state);
        }
    }
}
