﻿using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    class MergingRoomsController
    {
        public IMergingRoomsService mergingRoomsService = new MergingRoomsService();

        public void AddMergingRooms(MergingRooms mergingRooms)
        {
            mergingRoomsService.AddMergingRooms(mergingRooms);
        }


        public List<MergingRooms> GetAllMergingRooms()
        {
            return mergingRoomsService.GetAllMergingRooms();
        }



        public void UpdateMergingRooms(MergingRooms mergingRooms)
        {
            mergingRoomsService.UpdateMergingRooms(mergingRooms);
        }

        public void DeleteMergingRooms(MergingRooms mergingRooms)
        {
            mergingRoomsService.DeleteMergingRooms(mergingRooms);
        }

        public void MergeRooms(MergingRooms mergingRooms)
        {
            mergingRoomsService.MergeRooms(mergingRooms);
        }

        public void MergeOnDate(object state)
        {
            mergingRoomsService.MergeOnDate(state);
        }
    }
}
