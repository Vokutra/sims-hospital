﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Repo;

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class LoginPatient : Window
    {
        private PatientController patientController = new PatientController();
        private AppointmentController appointmentController = new AppointmentController();
        private DoctorController doctorController = new DoctorController();
        private NotificationController notificationController = new NotificationController();
        public string username { get; set; }
        public string password { get; set; }
        public static Patient patient { get; set; }
        private static Timer removePastAppointmentsTimer;
        private static Timer removePastCanceledAppointmentsTimer;
        private static Timer notifyPatientAboutTherapyTimer;
        private static Timer setNotificationButtonTimer;
        private static Timer setBtnRateHospitalStatusTimer;
        public LoginPatient()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            username = txtBoxUsername.Text.Trim();
            password = txtBoxPassword.Password.Trim();

            //Patient p1 = new Patient("Bogi", "Bogicevic", "pacijent1", "p1", "1");
            //Patient p2 = new Patient("Ogi", "Ogicevic", "pacijent2", "p2", "2");
            //Patient p3 = new Patient("Gogi", "Gogicevic", "pacijent3", "p3", "3");

            //p1.appointmentIDs = new List<string>();
            //p2.appointmentIDs = new List<string>();
            //p3.appointmentIDs = new List<string>();

            //p1.doctor = dfs.ReadUser("doktor4");
            //p2.doctor = dfs.ReadUser("doktor2");
            //p3.doctor = dfs.ReadUser("doktor3");



            //Dictionary<string, Patient> pacijenti = new Dictionary<string, Patient>();
            ////IList<Patient> pacijenti = new List<Patient>();

            //pacijenti.Add(p1.userID, p1);
            //pacijenti.Add(p2.userID, p2);
            //pacijenti.Add(p3.userID, p3);



            //string json = JsonConvert.SerializeObject(pacijenti, Formatting.Indented);

            //File.WriteAllText(@".\..\..\..\JSONData\patients.json", json);
            //Doctor doc1 = dfs.ReadUser("doktor4");
            //Doctor doc2 = dfs.ReadUser("doktor2");
            //Doctor doc3 = dfs.ReadUser("doktor3");

            //DoctorsShift ds1 = new DoctorsShift(new DateTime(2022, 4, 20), new DateTime(2022, 5, 10), new Shift(new TimeSpan(7, 0, 0), new TimeSpan(15, 0, 0)), doc1);
            //DoctorsShift ds2 = new DoctorsShift(new DateTime(2022, 5, 11), new DateTime(2022, 5, 30), new Shift(new TimeSpan(15, 0, 0), new TimeSpan(23, 0, 0)), doc1);
            //DoctorsShift ds3 = new DoctorsShift(new DateTime(2022, 5, 31), new DateTime(2022, 6, 15), new Shift(new TimeSpan(23, 0, 0), new TimeSpan(7, 0, 0)), doc1);
            //DoctorsShift ds4 = new DoctorsShift(new DateTime(2022, 4, 20), new DateTime(2022, 5, 10), new Shift(new TimeSpan(15, 0, 0), new TimeSpan(23, 0, 0)), doc2);
            //DoctorsShift ds5 = new DoctorsShift(new DateTime(2022, 5, 11), new DateTime(2022, 5, 30), new Shift(new TimeSpan(7, 0, 0), new TimeSpan(15, 0, 0)), doc2);
            //DoctorsShift ds6 = new DoctorsShift(new DateTime(2022, 5, 31), new DateTime(2022, 6, 15), new Shift(new TimeSpan(23, 0, 0), new TimeSpan(7, 0, 0)), doc2);
            //DoctorsShift ds7 = new DoctorsShift(new DateTime(2022, 4, 20), new DateTime(2022, 5, 10), new Shift(new TimeSpan(15, 0, 0), new TimeSpan(23, 0, 0)), doc3);
            //DoctorsShift ds8 = new DoctorsShift(new DateTime(2022, 5, 11), new DateTime(2022, 5, 30), new Shift(new TimeSpan(7, 0, 0), new TimeSpan(15, 0, 0)), doc3);
            //DoctorsShift ds9 = new DoctorsShift(new DateTime(2022, 5, 31), new DateTime(2022, 6, 15), new Shift(new TimeSpan(23, 0, 0), new TimeSpan(7, 0, 0)), doc3);


            //dsf.CreateOrUpdate(ds1);
            //dsf.CreateOrUpdate(ds2);
            //dsf.CreateOrUpdate(ds3);
            //dsf.CreateOrUpdate(ds4);
            //dsf.CreateOrUpdate(ds5);
            //dsf.CreateOrUpdate(ds6);
            //dsf.CreateOrUpdate(ds7);
            //dsf.CreateOrUpdate(ds8);
            //dsf.CreateOrUpdate(ds9);

            //Patient p5 = new Patient("Miki", "Mikojla", "pacijent5", "p5", "5");
            //p5.appointmentIDs = new List<string>();
            //p5.doctor = dfs.ReadUser("doktor3");
            //Therapy therapy = new Therapy(dfs.ReadUser("doktor3"), new DateTime(2022, 4, 30), new DateTime(2022, 5, 5), "aaaa", 2, "Brufen 400mg");
            //Therapy therapy2 = new Therapy(dfs.ReadUser("doktor3"), new DateTime(2022, 5, 1), new DateTime(2022, 5, 10), "bbbbbb", 2, "Brufen 200mg");
            //p5.therapies.Add(therapy);
            //p5.therapies.Add(therapy2);
            //pfs.CreateOrUpdate(p5);

            //Notification n1 = new Notification("1", "2", "Podsetnik za terapiju", "Vreme je da popijete lek", DateTime.Now, false);
            //Notification n2 = new Notification("2", "3", "Podsetnik za pregled", "Podsecamo vas da ", DateTime.Now, false);
            //Notification n3 = new Notification("3", "2", "Podsetnik za terapiju", "Vreme je da popijete lek", DateTime.Now, false);
            //Notification n4 = new Notification("1", "1", "Podsetnik za terapiju", "Vreme je da popijete lekkk", DateTime.Now, false);

            //notificationController.CreateNotification(n4);



            //Patient p5 = new Patient("Miki", "Mikojla", "pacijent5", "p5", "5");
            //p5.appointmentIDs = new List<string>();
            //p5.doctor = dfs.ReadUser("doktor3");
            //Therapy therapy = new Therapy(dfs.ReadUser("doktor3"), new DateTime(2022, 4, 30), new DateTime(2022, 5, 5), "aaaa", 2, "Brufen 400mg");
            //Therapy therapy2 = new Therapy(dfs.ReadUser("doktor3"), new DateTime(2022, 5, 1), new DateTime(2022, 5, 10), "bbbbbb", 2, "Brufen 200mg");
            //p5.therapies.Add(therapy);
            //p5.therapies.Add(therapy2);
            //pfs.CreateOrUpdate(p5);

            patient = patientController.GetPatient(username);


            if (patient != null && password.Equals(patient.password))
            {
                if (!patient.isBanned)
                {
                    if (patient.appointmentIDs == null)
                        patient.appointmentIDs = new List<string>();
                    ScheduledAppointments scheduledAppointments = ScheduledAppointments.getInstance();
                    MainWindowPatient mainWindow = MainWindowPatient.getInstance();
                    foreach (string id in LoginPatient.patient.appointmentIDs)
                    {
                        Appointment appointment = appointmentController.GetAppointment(id);
                        if (DateTime.Compare(appointment.startTime.AddMinutes(appointment.durationInMinutes), DateTime.Now) != -1)
                            ScheduledAppointments.scheduledAppointmentsDTO.Add(new AppointmentDTO(appointment.startTime.ToShortDateString(), appointment.startTime.ToString("HH:mm"), doctorController.FindDoctorById(appointment.doctor.userID).ToString(), appointment.id, appointment.room.roomName));
                    }

                    setNotificationButtonTimer = new Timer(new TimerCallback(MainWindowPatient.getInstance().SetNotificationButton), null, 0, 2000);
                    removePastAppointmentsTimer = new Timer(new TimerCallback(appointmentController.RemovePastAppointments), null, 1000, 120000);
                    removePastCanceledAppointmentsTimer = new Timer(new TimerCallback(appointmentController.RemovePastCanceledAppointments), null, 0, 70000);
                    notifyPatientAboutTherapyTimer = new Timer(new TimerCallback(notificationController.NotifyPatientAboutTherapies), null, 1000, 60000);
                   // setBtnRateHospitalStatusTimer = new Timer(new TimerCallback(MainWindowPatient.getInstance().SetBtnRateHospitalStatus), null, 0, 180000);



                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Vaš nalog je deaktiviran zbog toga što ste otkazali pregled 5 puta u roku od 30 dana.");
                }
            }
            else
            {
                MessageBox.Show("Pogresan username i/ili password!");
            }


        }
    }
}
