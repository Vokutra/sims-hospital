﻿using Hospital_IS.Controller;
using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.PatientWindow.Toasts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Hospital_IS.PatientWindow
{
    /// <summary>
    /// Interaction logic for MakeAppointment.xaml
    /// </summary>
    public partial class MakeAppointment : Page
    {
        private DoctorController doctorController = new DoctorController();
        private AppointmentController appointmentController = new AppointmentController();
        public List<Doctor> doctors { get; set; }
        public List<string> times { get; set; }
        public List<Appointment> availableAppointments { get; set; }
        public List<AppointmentDTO> availableAppointmentsDTO { get; set; }
        private Thread thread;

        public MakeAppointment()
        {
            InitializeComponent();
            doctors = doctorController.GetAllDoctors();
            if (doctors == null)
                doctors = new List<Doctor>();
            times = new List<string> { "7:00", "7:10", "7:20", "7:30", "7:40", "7:50", "8:00", "8:10", "8:20", "8:30", "8:40", "8:50", "9:00", "9:10", "9:20", "9:30", "9:40", "9:50", "10:00", "10:10", "10:20", "10:30", "10:40", "10:50", "11:00", "11:10", "11:20", "11:30", "11:40", "11:50", "12:00", "12:10", "12:20", "12:30", "12:40", "12:50", "13:00", "13:10", "13:20", "13:30", "13:40", "13:50", "14:00", "14:10", "14:20", "14:30", "14:40", "14:50", "15:00", "15:10", "15:20", "15:30", "15:40", "15:50", "16:00", "16:10", "16:20", "16:30", "16:40", "16:50", "17:00", "17:10", "17:20", "17:30", "17:40", "17:50", "18:00", "18:10", "18:20", "18:30", "18:40", "18:50", "19:00", "19:10", "19:20", "19:30", "19:40", "19:50", "20:00", "20:10", "20:20", "20:30", "20:40", "20:50", "21:00", "21:10", "21:20", "21:30", "21:40", "21:50", "22:00", "22:10", "22:20", "22:30", "22:40", "22:50", "23:00", "23:10", "23:20", "23:30", "23:40", "23:50" };
            availableAppointmentsDTO = new List<AppointmentDTO>();

            DataContext = this;
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            //foreach (string id in LoginPatient.patient.appointmentIDs)
            //{
            //    Appointment appointment = appointmentController.GetAppointment(id);
            //    if (appointment.appointmentType == AppointmentType.Examination && DateTime.Compare(appointment.startTime.AddMinutes(appointment.durationInMinutes), DateTime.Now) == 1)
            //    {
            //        thread = new Thread(new InformationToast().ShowInformationToast);
            //        thread.Start("Već imate zakazan pregled!");
            //        return;
            //    }
            //}

            if (appointmentController.CheckIfPatientHasExaminationAppointment(LoginPatient.patient))
            {
                thread = new Thread(new InformationToast().ShowInformationToast);
                thread.Start("Već imate zakazan pregled!");
                return;
            }

            Doctor doctor = (Doctor)cbDoctors.SelectedItem;
            DateTime startDate = (DateTime)dpStartDate.SelectedDate;
            DateTime endDate = (DateTime)dpEndDate.SelectedDate;

            

            string startTime = cbStartTime.Text;
            string endTime = cbEndTime.Text;
            int startHour = int.Parse(startTime.Split(":")[0]);
            int startMinutes = int.Parse(startTime.Split(":")[1]);
            int endHour = int.Parse(endTime.Split(":")[0]);
            int endMinutes = int.Parse(endTime.Split(":")[1]);

            if (LoginPatient.patient.datesOfCanceledAppointments.Count == 0)
                availableAppointments = appointmentController.GetAppointmentsAtSpecificDoctor(doctor, LoginPatient.patient, startDate, endDate, new TimeSpan(startHour, startMinutes, 0), new TimeSpan(endHour, endMinutes, 0));
            else
            {
                startDate = LoginPatient.patient.datesOfCanceledAppointments[LoginPatient.patient.datesOfCanceledAppointments.Count - 1];
                availableAppointments = appointmentController.GetAppointmentsAtSpecificDoctor(doctor, LoginPatient.patient, startDate.Date, startDate.AddDays(3).Date, new TimeSpan(startHour, startMinutes, 0), new TimeSpan(endHour, endMinutes, 0));
            }

            if (availableAppointments.Count == 0)
            { 
                if (rbDoctor.IsChecked == true)
                {
                    if (LoginPatient.patient.datesOfCanceledAppointments.Count == 0)
                    {
                        availableAppointments = appointmentController.GetAppointmentsAtSpecificDoctor(doctor, LoginPatient.patient, startDate.AddDays(-5), startDate, new TimeSpan(7, 0, 0), new TimeSpan(24, 0, 0));
                        availableAppointments.AddRange(appointmentController.GetAppointmentsAtSpecificDoctor(doctor, LoginPatient.patient, startDate, endDate.AddDays(5), new TimeSpan(7, 0, 0), new TimeSpan(24, 0, 0)));
                    }
                }
                else
                {
                    if (LoginPatient.patient.datesOfCanceledAppointments.Count == 0)
                        availableAppointments = appointmentController.GetAppointmentsAtSpecificTime(doctor, LoginPatient.patient, startDate, endDate, new TimeSpan(startHour, startMinutes, 0), new TimeSpan(endHour, endMinutes, 0));
                    else
                    {
                        startDate = LoginPatient.patient.datesOfCanceledAppointments[LoginPatient.patient.appointmentCancellationTimes.Count - 1];
                        availableAppointments = appointmentController.GetAppointmentsAtSpecificTime(doctor, LoginPatient.patient, startDate.Date, startDate.AddDays(3).Date, new TimeSpan(startHour, startMinutes, 0), new TimeSpan(endHour, endMinutes, 0));
                    }
                }
            }

            availableAppointmentsDTO.Clear();
            foreach (Appointment appointment in availableAppointments)
            {
                availableAppointmentsDTO.Add(new AppointmentDTO(appointment.startTime.ToShortDateString(), appointment.startTime.ToString("HH:mm"), doctorController.FindDoctorById(appointment.doctor.userID).ToString(), appointment.id, appointment.room.roomName));
            }

            MainWindowPatient.getInstance().SetContent(new OfferedAppointments(availableAppointmentsDTO, availableAppointments));
        }

        private void DatePicker_Loaded(object sender, RoutedEventArgs e)
        {
            DatePicker datePicker = sender as DatePicker;
            if (datePicker != null)
            {
                System.Windows.Controls.Primitives.DatePickerTextBox datePickerTextBox = FindVisualChild<System.Windows.Controls.Primitives.DatePickerTextBox>(datePicker);
                if (datePickerTextBox != null)
                {

                    ContentControl watermark = datePickerTextBox.Template.FindName("PART_Watermark", datePickerTextBox) as ContentControl;
                    if (watermark != null)
                    {
                        watermark.Content = string.Empty;
                        //or set it some value here...
                    }
                }
            }
        }

        private T FindVisualChild<T>(DependencyObject depencencyObject) where T : DependencyObject
        {
            if (depencencyObject != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depencencyObject); ++i)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depencencyObject, i);
                    T result = (child as T) ?? FindVisualChild<T>(child);
                    if (result != null)
                        return result;
                }
            }

            return null;
        }
    }
}
