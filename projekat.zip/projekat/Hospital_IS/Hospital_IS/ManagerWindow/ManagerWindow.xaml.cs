﻿using Hospital_IS.ManagerWindow.View;
using Hospital_IS.PatientWindow;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hospital_IS.ManagerWindow
{
    
    public partial class ManagerWindow : Window
    {

        private static ManagerWindow instance = new ManagerWindow();

        
        public static ManagerWindow Instance
        {
            get
            {
                return instance;
            }
        }

        public void SetContent(Page page)
        {
            WindowContent.Content = page;
        }
        public void SetLabel(string label)
        {
            MainLabel.Content = label;
        }

        public ManagerWindow()
        {
            InitializeComponent();
            SetContent(new HomeView());
            SetLabel("Pocnetni ekran");
            DataContext = this;
        }

        private void btnRooms_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new RoomsView());
            SetLabel("Prostorije");
        }

        private void btnInventory_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new InventoryView());
            SetLabel("Inventar");
        }

        private void btnMedication_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new MedicationView());
            SetLabel("Lekovi");
        }


        private void btnSurveys_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new SurveysView());
            SetLabel("Izvestaji");
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            SetContent(new HomeView());
            SetLabel("Pocnetni ekran");
        }

        private void btnLogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginManager login = new LoginManager();
            login.Show();
            this.Close();
        }
    }
}
