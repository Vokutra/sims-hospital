﻿using Hospital_IS.DTO;
using Hospital_IS.Model;
using Hospital_IS.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Controller
{
    class RoomInventoryController
    {
        public RoomInventoryService roomInventoryService = new RoomInventoryService();

        public void AddRoomInventory(RoomInventory inventory)
        {
            roomInventoryService.AddRoomInventory(inventory);
        }


        public List<RoomInventory> GetAllRoomInventories()
        {
            return roomInventoryService.GetAllRoomInventories();
        }

        public List<RoomInventory> GetInventoriesByRoom(Room room)
        {
            return roomInventoryService.GetInventoriesByRoom(room);
        }

        public void UpdateRoomInventory(RoomInventory inventory)
        {
            roomInventoryService.UpdateInventory(inventory);
        }

        public void DeleteRoomInventory(RoomInventory inventory)
        {
            roomInventoryService.DeleteRoomInventory(inventory);
        }

        public void RelocateOnDate(object state) 
        {
            roomInventoryService.RelocateOnDate(state);
        }
    }
}