﻿using Hospital_IS.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hospital_IS.Repo
{
    class SecretaryFileStorage : GenericFileStorage<string, Secretary, SecretaryFileStorage>
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        protected override string GetKey(Secretary entity)
        {
            return entity.userID;
        }

        protected override string GetPath()
        {
            return @".\..\..\..\jsondata\secretary.json";
        }

        protected override void RemoveReferences(string key)
        {
            throw new NotImplementedException();
        }

        protected override void ShouldSerialize(Secretary entity)
        {
            entity.serialize = true;
        }

        public Secretary ReadUser(String username)
        {
            foreach (Secretary s in this.GetEntityList())
            {
                if (s.username.Equals(username))
                    return s;
            }

            return null;
        }
    }
}
